<?php

declare(strict_types=1);

/**
 * Front controller — the only executable PHP under the web root (§4.1).
 */

use App\Core\Request;
use App\Core\Response;
use App\Core\Router;
use App\Core\Session;
use App\Core\View;
use App\Http\Middleware\SecurityHeaders;
use App\Http\Middleware\SessionTimeout;

// PHP built-in dev server: let it serve real files (css/js/fonts) directly.
if (PHP_SAPI === 'cli-server') {
    $file = __DIR__ . parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH);
    if (is_file($file)) {
        return false;
    }
}

require dirname(__DIR__) . '/src/bootstrap.php';

try {
    Session::start();

    $request = Request::fromGlobals();

    $router = new Router();
    $router->loadFromFile(dirname(__DIR__) . '/config/routes.php');

    // Global middleware wraps every route (outermost first).
    $pipeline = static fn (Request $req): Response => (new SecurityHeaders())->handle(
        $req,
        static fn (Request $r): Response => (new SessionTimeout())->handle(
            $r,
            static fn (Request $r2): Response => $router->dispatch($r2),
        ),
    );

    $pipeline($request)->send();
} catch (Throwable $e) {
    // Last-resort handler (bootstrap's exception handler normally catches first).
    app_log('error', sprintf('Uncaught %s: %s in %s:%d', $e::class, $e->getMessage(), $e->getFile(), $e->getLine()));
    if (!headers_sent()) {
        http_response_code(500);
    }
    if (!config('app.debug')) {
        echo View::render('errors/500', ['title' => t('err_500_title')], ['showNav' => false]);
    }
}
