/**
 * Submit Overtime page behaviour (§9.2).
 * Search + division filter, row rules, day-rule check, counters, button state.
 * Uses textContent only — never innerHTML with data.
 */

import { normalizeText } from '../lib/normalize.js';
import { toLatinDigits, toPersianDigits, parseDecimal } from '../lib/digits.js';
import { toGregorian, isValidJalali, weekdayName, isoWeekday, today, formatJalali } from '../lib/jalali.js';
import { initAll } from '../lib/datepicker.js';

const i18n = JSON.parse(document.getElementById('i18n')?.textContent || '{}');
const WEEKDAY_INDEX = { mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6, sun: 7 };
const weekendSet = new Set((i18n.weekend_days || ['thu', 'fri']).map((d) => WEEKDAY_INDEX[d]).filter(Boolean));
const fmtNum = (n) => (i18n.persian_digits ? toPersianDigits(String(n)) : String(n));

const form = document.getElementById('overtime-form');
const typeSelect = document.getElementById('type_id');
const divisionFilter = document.getElementById('division-filter');
const dateInput = document.getElementById('date');
const hoursInput = document.getElementById('hours');
const searchInput = document.getElementById('personnel-search');
const countEl = document.getElementById('selected-count');
const submitBtn = document.getElementById('submit-btn');
const selectAll = document.getElementById('select-all');
const weekdayLabel = document.getElementById('weekday-label');
const dayRuleMsg = document.getElementById('day-rule-msg');
const rows = Array.from(document.querySelectorAll('#personnel-body tr'));

function selectedType() {
  const opt = typeSelect.selectedOptions[0];
  return {
    usesCycle: opt?.dataset.usesCycle === '1',
    dayRule: opt?.dataset.dayRule || 'any',
  };
}

function parseDate() {
  const m = /^(\d{4})[/-](\d{1,2})[/-](\d{1,2})$/.exec(toLatinDigits(dateInput.value).trim());
  if (!m) return null;
  const jy = parseInt(m[1], 10);
  const jm = parseInt(m[2], 10);
  const jd = parseInt(m[3], 10);
  if (!isValidJalali(jy, jm, jd)) return null;
  return { jy, jm, jd };
}

function inWindow(d) {
  const parse = (v) => {
    const m = /^(\d{4})\/(\d{2})\/(\d{2})$/.exec(v || '');
    return m ? { jy: +m[1], jm: +m[2], jd: +m[3] } : null;
  };
  const cmp = (a, b) => a.jy - b.jy || a.jm - b.jm || a.jd - b.jd;
  const min = parse(dateInput.dataset.min);
  const max = parse(dateInput.dataset.max);
  if (min && cmp(d, min) < 0) return false;
  if (max && cmp(d, max) > 0) return false;
  return true;
}

function hoursValid() {
  const raw = parseDecimal(hoursInput.value);
  if (raw === '' || !/^\d+(\.\d{1,2})?$/.test(raw)) return false;
  const h = parseFloat(raw);
  if (!(h >= i18n.hours_step && h <= i18n.max_hours)) return false;
  const steps = Math.round(h / i18n.hours_step);
  return Math.abs(h - steps * i18n.hours_step) < 1e-9;
}

/** Hide/show rows by division filter + normalised search; hidden state is tracked. */
function applyFilters() {
  const div = divisionFilter.value;
  const q = normalizeText(searchInput.value);
  for (const row of rows) {
    const divOk = div === '' || row.dataset.divisionId === div;
    let qOk = true;
    if (q !== '') {
      const name = normalizeText(row.children[1].textContent);
      const code = normalizeText(row.children[2].textContent);
      qOk = name.includes(q) || code.includes(q);
    }
    const hidden = !(divOk && qOk);
    row.classList.toggle('hidden', hidden);
    row.dataset.hidden = hidden ? '1' : '0';
  }
  updateSelectAll();
  updateCounter();
  updateSubmitState();
}

/** Enable/disable rows for the current type; refresh status text. */
function applyRowStates() {
  const { usesCycle } = selectedType();
  for (const row of rows) {
    const own = row.dataset.own === '1';
    const used = row.dataset.used === '1';
    const checkbox = row.querySelector('input[type="checkbox"]');
    const statusCell = row.querySelector('.status-cell');

    const disabled = !own || (usesCycle && used);
    checkbox.disabled = disabled;
    if (disabled) checkbox.checked = false;
    row.classList.toggle('opacity-50', disabled);

    if (!own) {
      statusCell.textContent = i18n.status_locked;
      checkbox.title = i18n.status_locked;
    } else if (usesCycle) {
      const n = fmtNum(i18n.cycle_numbers?.[row.dataset.divisionId] ?? '');
      statusCell.textContent = used
        ? i18n.status_done_cycle.replace('{n}', n)
        : i18n.status_available;
      checkbox.title = used ? statusCell.textContent : '';
    } else {
      statusCell.textContent = '—';
      checkbox.title = '';
    }
  }
  updateSelectAll();
  updateCounter();
  updateSubmitState();
}

function visibleEnabledCheckboxes() {
  return rows
    .filter((r) => r.dataset.hidden !== '1')
    .map((r) => r.querySelector('input[type="checkbox"]'))
    .filter((c) => !c.disabled);
}

function updateSelectAll() {
  const boxes = visibleEnabledCheckboxes();
  const checked = boxes.filter((c) => c.checked).length;
  selectAll.checked = boxes.length > 0 && checked === boxes.length;
  selectAll.indeterminate = checked > 0 && checked < boxes.length;
}

function updateCounter() {
  let total = 0;
  let hidden = 0;
  for (const row of rows) {
    const c = row.querySelector('input[type="checkbox"]');
    if (c.checked && !c.disabled) {
      total += 1;
      if (row.dataset.hidden === '1') hidden += 1;
    }
  }
  let text = i18n.selected_count.replace('{count}', fmtNum(total));
  if (hidden > 0) text += ' ' + i18n.selected_count_hidden.replace('{count}', fmtNum(hidden));
  countEl.textContent = text;
}

/** Weekday label + day-rule check; returns true when the rule is satisfied. */
function updateDayRule() {
  const d = parseDate();
  const { dayRule } = selectedType();
  weekdayLabel.textContent = '';
  dayRuleMsg.textContent = '';
  if (!d) return false;

  const g = toGregorian(d.jy, d.jm, d.jd);
  const wdName = weekdayName(g);
  weekdayLabel.textContent = wdName;

  const isWeekend = weekendSet.has(isoWeekday(g));
  if (dayRule === 'workday' && isWeekend) {
    dayRuleMsg.textContent = i18n.err_day_workday.replace('{weekday}', wdName);
    return false;
  }
  if (dayRule === 'weekend' && !isWeekend) {
    dayRuleMsg.textContent = i18n.err_day_weekend.replace('{weekday}', wdName);
    return false;
  }
  return true;
}

function updateSubmitState() {
  const anySelected = rows.some((r) => {
    const c = r.querySelector('input[type="checkbox"]');
    return c.checked && !c.disabled;
  });
  const d = parseDate();
  const dateOk = d !== null && inWindow(d);
  const dayOk = updateDayRule(); // false when the date is empty/invalid or mismatched
  submitBtn.disabled = !(anySelected && dateOk && hoursValid() && dayOk);
}

selectAll.addEventListener('change', () => {
  for (const c of visibleEnabledCheckboxes()) c.checked = selectAll.checked;
  updateCounter();
  updateSubmitState();
});

document.getElementById('personnel-body').addEventListener('change', (ev) => {
  if (ev.target.matches('input[type="checkbox"]')) {
    ev.target.closest('tr').classList.toggle('bg-sky-50', ev.target.checked);
    updateSelectAll();
    updateCounter();
    updateSubmitState();
  }
});

typeSelect.addEventListener('change', applyRowStates);
divisionFilter.addEventListener('change', applyFilters);
searchInput.addEventListener('input', applyFilters);
dateInput.addEventListener('change', updateSubmitState);
dateInput.addEventListener('input', updateSubmitState);
hoursInput.addEventListener('input', updateSubmitState);

form.addEventListener('submit', () => {
  submitBtn.disabled = true; // prevent double-submit; the one-time nonce is the server-side guard
});

// Initial state
initAll();
if (dateInput.value.trim() === '') {
  dateInput.value = i18n.persian_digits ? toPersianDigits(formatJalali(today())) : formatJalali(today());
}
applyFilters();
applyRowStates();
