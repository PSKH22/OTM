/**
 * Reports page behaviour (§9.3, §9.4): Jalali From/To pickers with pairing,
 * and the delete confirmation <dialog>. Event delegation; no inline handlers.
 */

import { toLatinDigits } from '../lib/digits.js';
import { initAll } from '../lib/datepicker.js';

const fromInput = document.getElementById('from');
const toInput = document.getElementById('to');

/** From's max = To's value; To's min = From's value. Updated dynamically. */
function syncBounds() {
  const from = toLatinDigits(fromInput.value).trim();
  const to = toLatinDigits(toInput.value).trim();
  if (/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(to)) fromInput.dataset.max = to;
  else delete fromInput.dataset.max;
  if (/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(from)) toInput.dataset.min = from;
  else delete toInput.dataset.min;
  fromInput._jalaliPicker?.refresh();
  toInput._jalaliPicker?.refresh();
}

initAll();
syncBounds();
fromInput.addEventListener('change', syncBounds);
toInput.addEventListener('change', syncBounds);
fromInput.addEventListener('input', syncBounds);
toInput.addEventListener('input', syncBounds);

// ── Delete dialog ──
const dialog = document.getElementById('delete-dialog');
const summaryName = document.getElementById('delete-name');
const summaryDate = document.getElementById('delete-date');
const summaryType = document.getElementById('delete-type');
const summaryHours = document.getElementById('delete-hours');
const entryIdField = document.getElementById('delete-entry-id');
const backField = document.getElementById('delete-back');
const cancelBtn = document.getElementById('delete-cancel');

document.getElementById('report-body')?.addEventListener('click', (ev) => {
  const btn = ev.target.closest('[data-entry-id]');
  if (!btn || !dialog) return;

  summaryName.textContent = btn.dataset.name || '';
  summaryDate.textContent = btn.dataset.date || '';
  summaryType.textContent = btn.dataset.type || '';
  summaryHours.textContent = btn.dataset.hours || '';
  entryIdField.value = btn.dataset.entryId;

  const back = `${window.location.pathname}${window.location.search}`;
  backField.value = back.startsWith('/reports') ? back : '/reports';

  dialog.showModal();
});

cancelBtn?.addEventListener('click', () => dialog.close());
