# Personnel Overtime Management System — MVP Plan (v2)

| | |
|---|---|
| **Status** | Revised after stakeholder answers |
| **Date** | 3 Oct 2026 (۱۱ مهر ۱۴۰۵) |
| **Scope** | MVP: login, submit overtime, reports (with delete + CSV export) |
| **Stack** | PHP 8.5 · MySQL (9.7 LTS / 8.4 LTS) · Tailwind CSS 4 · vanilla JS |
| **UI** | Persian (fa), right-to-left, Solar Hijri dates |

---

## 0. What changed in v2

| Area | Change |
|---|---|
| **Cycles** | Now **per division**. `cycles` gets `division_id` and a per-division `cycle_number`; each division always has exactly one open cycle. |
| **Roles** | Every user is a **division admin**: `users.division_id`. Admins can **submit and delete only for their own division**; they have **read-only** access to everything else (personnel list, cycle status, reports, CSV). Enforced server-side. |
| **Type ↔ date check** | New `overtime_types.day_rule`. *Weekdays* needs a working day, *Weekend* needs a weekend day (Thu/Fri by default), *Out of quota* is unchecked. Mismatch **blocks the submit button** (client) and the request (server). |
| **Hours / description** | Hours cap is **8** (config). Description is **optional**. |
| **Date limits** | Submission window ±366 days; **reports have no date limit**. |
| **Delete** | New: delete button per record in Reports, own division only, confirmation dialog, `audit_log` entry, defined cycle semantics (§5.5). |
| **Personnel import** | **Removed.** Personnel are maintained with a small admin CLI (`bin/personnel.php`). CSV is **export only**. |
| **Language** | **Persian + RTL from day one**: `dir="rtl"`, self-hosted Persian font, string file, Persian digits on screen, Persian-aware search normalisation, Persian month/weekday names. |
| **Time zone** | `Asia/Tehran`. |
| **CSV** | Excel is the target (UTF-8 BOM, Persian headers, Latin digits); *Description* column included. |

---

## 1. Overview

A small internal web app for division admins to record personnel overtime and report on it.

- **Login** — only authorized users reach the panel.
- **Submit Overtime** — pick type, date (Solar Hijri), hours and an optional description, tick personnel from **your own division**, submit. For the *Weekdays* type each person may take **one** overtime per *cycle*; a division's cycle ends when every active person in that division has had theirs, then that division's next cycle begins.
- **Reports** — filterable list of all overtime entries (date, personnel ID, name, division, type, hours, cycle, description) across all divisions, with a delete button on your own division's records and CSV export.

### Design principles

1. **MVP, not a platform.** No framework, no ORM, no SPA, no Composer packages.
2. **Standard library first.** Anything PHP or the browser already does, we use (§3.2).
3. **Rules live on the server and in the database.** The browser only helps; the server re-validates everything and the DB enforces the cycle rule with a unique key.
4. **Secure by default** for authentication, sessions, CSRF, XSS, SQL injection, authorization and CSV injection.
5. **Persian-first.** RTL layout, Persian text, calendar and numerals are built in from the start, not bolted on.

### Non-goals (MVP)

Personnel/user management screens, editing entries (delete + resubmit instead), public-holiday calendar, password reset by email, 2FA, automated tests. See §17.

---

## 2. Decisions & assumptions

### 2.1 Confirmed by stakeholder

| # | Topic | Decision |
|---|---|---|
| C1 | Cycle scope | **One cycle sequence per division.** Divisions rotate independently. |
| C2 | Division dropdown (Submit page) | **Display filter only** — it never changes what is submitted. |
| C3 | Type ↔ date | *Weekdays* follows Jalali weekdays; the date must match the type; mismatch blocks submit. *Out of quota* is never checked. |
| C4 | Description / hours | Description optional. Hours cap ≈ **8** per entry. |
| C5 | Date window | Submission: within ±1 year. Reports: **no limit** on how far back you can view. |
| C6 | Delete | Required in v1, as a button on the records (Reports) page. |
| C7 | CSV | **No import.** Admins only **export** CSV. |
| C8 | Roles | Several admins per division; each may submit/delete only for **their own division** and has read-only access to the rest. |
| C9 | Language | Persian from day one. |
| C10 | Time zone | `Asia/Tehran`. |
| C11 | CSV consumer | Excel; *Description* column included. |

### 2.2 Assumptions made while applying the answers (please confirm — §18)

| # | Topic | Assumption |
|---|---|---|
| A1 | **Weekend days** | **Thursday and Friday** (as proposed in the earlier question); *Weekdays* = Saturday–Wednesday. One config value (`WEEKEND_DAYS`). Official public holidays are **not** modelled — enter them as *Out of quota*. |
| A2 | **Admin ↔ division** | Each admin account belongs to **exactly one division** (`users.division_id`). |
| A3 | **Personnel maintenance** | No UI and no CSV import. A small CLI (`bin/personnel.php`) adds, moves, activates and deactivates personnel. |
| A4 | **Delete semantics** | Hard delete + `audit_log` row. Cycle effects are defined in §5.5. |
| A5 | **Digits** | Persian digits (۰–۹) on screen; **inputs accept Persian or Latin** digits; CSV uses Latin digits. One config toggle. |
| A6 | **Hours step** | 0.25 h minimum step (0.25 – 8). |
| A7 | **Cycle assignment** | By **submission order**, not overtime date. A back-dated Weekdays entry goes into the division's currently open cycle. |
| A8 | **Division on an entry** | The submitting admin's division = the person's division at that time (snapshot kept even if the person later transfers). |
| A9 | **Other divisions on the Submit page** | Their personnel and cycle status are **visible but locked** (checkbox disabled). The division dropdown defaults to your own division. |
| A10 | **Batch submit** | One submission creates one entry per ticked person, all-or-nothing (one transaction). |
| A11 | **Rendering** | Server-rendered pages + small JS enhancements. No JSON API. |
| A12 | **Reports default** | All divisions, all dates, newest first, 50 per page. |

---

## 3. Technology

### 3.1 Stack

| Layer | Choice | Notes |
|---|---|---|
| Language | **PHP 8.5** (latest stable branch, 8.5.x) | `declare(strict_types=1)` everywhere. |
| Database | **MySQL 9.7 LTS** (8.4 LTS also works) | InnoDB, `utf8mb4`. Uses only `CHECK` constraints, a stored generated column and `JSON` (all available since 8.0). |
| Web server | Nginx + PHP-FPM (or Apache) | Document root is `public/` only. HTTPS mandatory in production. |
| CSS | **Tailwind CSS 4.x** via the **standalone CLI** | No Node/npm. Compiled to a single static `app.css`. Logical (RTL-safe) utilities. |
| JS | Vanilla JS, native ES modules | No bundler, no npm packages, no CDN. |
| Font | **Vazirmatn** (SIL Open Font License), self-hosted `woff2` | Only third-party *asset*; fallback stack `Tahoma, system-ui, sans-serif`. |
| Runtime deps | **None** | Autoloading via `spl_autoload_register`. |

**Required PHP extensions:** `pdo_mysql`, `intl` (Solar Hijri, Persian collation), `mbstring`, Argon2 support (`PASSWORD_ARGON2ID` defined). The bootstrap checks for them and fails fast with a clear message.

### 3.2 Standard library instead of libraries

| Need | Use |
|---|---|
| Password hashing | `password_hash` / `password_verify` / `password_needs_rehash` (Argon2id) |
| Random tokens | `random_bytes` + `bin2hex`; compare with `hash_equals` |
| Database | `PDO` (real prepared statements) |
| Jalali ↔ Gregorian, Persian weekday/month names (server) | `ext-intl`: `IntlCalendar`, `IntlDateFormatter` |
| Persian alphabetical sorting | `ext-intl`: `Collator('fa_IR')` |
| Jalali math & names (browser) | `Intl.DateTimeFormat` with the `persian` calendar, `fa-IR` locale |
| Persian digits | `strtr()` (PHP) / `Intl.NumberFormat('fa-IR')` (JS) |
| CSV | `fputcsv` to `php://output` |
| `.env` loading | `parse_ini_file` |
| Autoloading | `spl_autoload_register` (PSR-4-style `App\` → `src/`) |
| Sessions | Native PHP sessions |
| Output escaping | `htmlspecialchars` |
| Delete confirmation | Native `<dialog>` element |
| Date picker | **In-house** (~250 lines JS). `<input type="date">` cannot be relied on to show the Solar Hijri calendar, and existing pickers are third-party dependencies. |

---

## 4. System architecture

### 4.1 Request flow

```
Browser ──HTTPS──► Nginx ──► PHP-FPM ──► public/index.php (front controller)
                                           │
                    bootstrap: autoload, config, error handler, timezone,
                               secure session start, security headers
                                           │
                    Router ──► Middleware pipeline ──► Controller
                               • SessionTimeout        │ (HTTP only: parse, validate, respond)
                               • RequireAuth           │   loads current user (+ division) from DB
                               • CsrfGuard (POST)      ▼
                                                     Service (business rules, authorization checks, transactions)
                                                       ▼
                                                    Repository (PDO, SQL only)
                                                       ▼
                                                     MySQL
                    Response: rendered PHP template │ redirect │ CSV stream
```

### 4.2 Layers

| Layer | Responsibility | Must not |
|---|---|---|
| **Controller** | Read request, build input DTO, call a service, choose view/redirect | Contain SQL or business rules |
| **Service** | Business rules (cycles, day rules, delete semantics), authorization via `AccessPolicy`, transactions | Touch `$_GET`/`$_POST` or echo HTML |
| **Repository** | One class per table group; parameterised SQL | Contain business decisions |
| **Template** | HTML with `e()` escaping and `t()` strings | Run queries |

### 4.3 Routing

Tiny array-based router, exact path matching (no path parameters — ids travel in the POST body). **Default-deny:** every route is behind `RequireAuth` unless explicitly marked public (`/login` only).

---

## 5. Domain rules

### 5.1 Cycles (per division)

- A **cycle** applies only to overtime types with `uses_cycle = 1` (*Weekdays*).
- Every division has its **own** numbered cycles (1, 2, 3 …) and exactly **one open cycle** at a time.
- Within a division's open cycle, each **active** person can have **at most one** Weekdays overtime.
- After a person has one, their checkbox is disabled (for Weekdays) until the division's next cycle.
- When **every active person of that division** has one in the open cycle, the cycle is **closed** and the division's next cycle **opens automatically**. Other divisions are unaffected.
- *Weekend* and *Out of quota* entries are unlimited and have `cycle_id = NULL`.

**Walk-through** (Networking has people A, B, C, D; Hardware Support has its own cycle that stays untouched):

| Step | Action (by a Networking admin) | Result | Networking cycle 1 |
|---|---|---|---|
| 1 | Weekdays for A | Saved with Networking cycle 1 | A disabled · 1/4 |
| 2 | Weekend for A | Saved with `cycle_id = NULL`; A still selectable for Weekend | 1/4 |
| 3 | Weekdays for B and C (one batch) | Saved | 3/4 |
| 4 | Weekdays for A | **Rejected** — A already has one in cycle 1 | 3/4 |
| 5 | Weekdays for D | Saved; 4/4 → cycle 1 closed, **cycle 2 opened** | all enabled · 0/4 |
| 6 | Weekdays for A | Saved in cycle 2 | 1/4 of cycle 2 |

### 5.2 Day rules (type ↔ date)

Each overtime type carries a `day_rule`:

| Type | `uses_cycle` | `day_rule` | Date must be… |
|---|---|---|---|
| Weekdays | 1 | `workday` | **not** a weekend day (default: Saturday–Wednesday) |
| Weekend | 0 | `weekend` | a weekend day (default: Thursday or Friday) |
| Out of quota | 0 | `any` | anything (no check) |

- The weekday of a date is calendar-independent, so the server uses the **Gregorian** date's ISO weekday (`DateTimeImmutable::format('N')`); Jalali is only the input/output format.
- Weekend days come from config (`WEEKEND_DAYS="thu,fri"`), are rendered into the form as a `data-` attribute for the client check, and are re-checked by the server.
- Public holidays that fall on a working day are not in the calendar; such overtime should be entered as *Out of quota*.

### 5.3 Cycle edge cases

| Situation | Behaviour |
|---|---|
| New person added mid-cycle | They are "remaining" in their division's open cycle, so it cannot close until they have one. |
| Person deactivated mid-cycle | No longer counts as "remaining". If they were the last one, the cycle is closed **lazily**: `CycleService::open($divisionId)` (called on page load for your division and at the start of every submit, under the row lock) closes a cycle that has ≥ 1 entries and 0 remaining people, and opens the next. No cron or CLI hook is required. |
| Person moves to another division | Old entries keep their old division snapshot. In the new division they are "remaining" in its open cycle. |
| Person added right after a cycle closed | They belong to the new (empty) cycle. |
| Two admins of the same division submit at once | Serialised by a row lock on the division's open cycle; the unique key is the backstop. |
| Batch includes someone already used | Whole batch rejected, nothing saved, offending names listed. |

### 5.4 Submit algorithm (`OvertimeService::submitBatch`)

The division is **taken from the logged-in user**, never from the form.

```
1.  Validate input (§9.2): fields, window, hours cap, day rule, personnel ids (deduplicated).
2.  BEGIN TRANSACTION
3.  If type.uses_cycle:
      a. cycle = CycleService::open(user.division_id)
         = SELECT id, cycle_number FROM cycles
            WHERE division_id = :div AND closed_at IS NULL FOR UPDATE     -- FIRST statement in the transaction
           (+ lazy close/open if the open cycle has entries and 0 remaining people)
      b. SELECT personnel_id FROM overtime_entries
          WHERE cycle_id = :cycle AND personnel_id IN (:ids)
         → any rows: ROLLBACK, error listing those people
      c. cycle_id = :cycle
    Else: cycle_id = NULL
4.  SELECT id, division_id FROM personnel WHERE id IN (:ids) AND is_active = 1
    → count differs: ROLLBACK, error (unknown/inactive)
    → any division_id != user.division_id: ROLLBACK, 403 + security log   (tampering)
5.  INSERT one row per person (division_id = user.division_id, created_by = user.id)
6.  If type.uses_cycle:
      remaining = COUNT(active personnel of the division with NO entry in :cycle)
      if remaining = 0:
          UPDATE cycles SET closed_at = UTC_TIMESTAMP() WHERE id = :cycle              -- close first
          INSERT INTO cycles (division_id, cycle_number) VALUES (:div, :cycle_number+1) -- then open the next
7.  COMMIT
8.  Duplicate-key error (SQLSTATE 23000 / errno 1062) → treated like 3b (friendly message).
```

The `FOR UPDATE` must be the first statement so that later reads see rows committed by a competing transaction that held the lock before us.

### 5.5 Delete semantics (`OvertimeService::deleteEntry`)

Allowed only for entries whose `division_id` equals the admin's division. Everything runs in one transaction with the **same lock order as submit** (division's open cycle first):

```
1. BEGIN
2. open = SELECT id, cycle_number FROM cycles WHERE division_id = :user_div AND closed_at IS NULL FOR UPDATE
3. entry = SELECT * FROM overtime_entries WHERE id = :id FOR UPDATE
     → not found: ROLLBACK ("record no longer exists")
     → entry.division_id != user.division_id: ROLLBACK, 403 + security log
4. DELETE FROM overtime_entries WHERE id = :id
5. If entry.cycle_id IS NOT NULL AND entry.cycle_id != open.id      -- entry belonged to a CLOSED cycle
      prev = the division's most recent closed cycle
      If entry.cycle_id = prev.id AND the open cycle now has 0 entries:
          DELETE FROM cycles WHERE id = open.id                    -- discard the empty open cycle FIRST
          UPDATE cycles SET closed_at = NULL WHERE id = prev.id    -- then re-open the previous one ("undo close")
      Else: nothing — that historical cycle stays closed with a gap
6. INSERT INTO audit_log (user_id, action='overtime.delete', entity_id, details = JSON snapshot, ip)
7. COMMIT
```

| Deleted entry | Effect |
|---|---|
| Weekend / Out of quota | Row removed. No cycle impact. |
| Weekdays in the **open** cycle | Person becomes available again in this cycle. |
| Weekdays in the **most recent closed** cycle, new cycle still empty | Cycle is **re-opened** (typical case: the last submission of a cycle was a mistake). |
| Weekdays in an older closed cycle, or the new cycle already has entries | Row removed; the old cycle stays closed (history only). The person is unaffected in the current cycle. |

The order in step 5 matters: the unique "one open cycle per division" key forbids two open cycles at the same time.

---

## 6. Database design

Engine InnoDB, charset `utf8mb4`, default collation `utf8mb4_0900_ai_ci`. Persian alphabetical ordering of the personnel list is done in PHP with `Collator('fa_IR')` (the list is small), so no MySQL collation tailoring is needed.

### 6.1 Entity relationships

```mermaid
erDiagram
    DIVISIONS ||--o{ USERS : "has admins"
    DIVISIONS ||--o{ PERSONNEL : "employs"
    DIVISIONS ||--o{ CYCLES : "has own cycles"
    DIVISIONS ||--o{ OVERTIME_ENTRIES : "division at entry time"
    PERSONNEL ||--o{ OVERTIME_ENTRIES : "works"
    OVERTIME_TYPES ||--o{ OVERTIME_ENTRIES : "classifies"
    CYCLES |o--o{ OVERTIME_ENTRIES : "groups (weekdays only)"
    USERS ||--o{ OVERTIME_ENTRIES : "recorded by"
    USERS ||--o{ AUDIT_LOG : "performed"

    USERS {
        int id PK
        varchar username UK
        varchar password_hash
        varchar display_name
        tinyint division_id FK
        tinyint is_active
    }
    LOGIN_ATTEMPTS {
        bigint id PK
        varchar username
        varbinary ip_address
        tinyint was_successful
        datetime attempted_at
    }
    DIVISIONS {
        tinyint id PK
        varchar name UK
    }
    PERSONNEL {
        int id PK
        varchar personnel_code UK
        varchar full_name
        varchar name_search
        tinyint division_id FK
        tinyint is_active
    }
    OVERTIME_TYPES {
        tinyint id PK
        varchar code UK
        varchar name
        tinyint uses_cycle
        enum day_rule
    }
    CYCLES {
        int id PK
        tinyint division_id FK
        int cycle_number
        datetime started_at
        datetime closed_at
    }
    OVERTIME_ENTRIES {
        bigint id PK
        int personnel_id FK
        tinyint division_id FK
        tinyint overtime_type_id FK
        date overtime_date
        decimal hours
        varchar description "nullable"
        int cycle_id FK "NULL unless weekdays"
        int created_by FK
        datetime created_at
    }
    AUDIT_LOG {
        bigint id PK
        int user_id FK
        varchar action
        bigint entity_id
        json details
        datetime created_at
    }
```

### 6.2 Schema (`database/schema.sql`)

```sql
SET NAMES utf8mb4;

-- ── Reference data ────────────────────────────────────────────────────────
CREATE TABLE divisions (
  id    TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name  VARCHAR(100)     NOT NULL,                  -- Persian display name
  PRIMARY KEY (id),
  UNIQUE KEY uq_divisions_name (name)
) ENGINE=InnoDB;

CREATE TABLE overtime_types (
  id          TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  code        VARCHAR(30)      NOT NULL,            -- stable identifier used in code
  name        VARCHAR(60)      NOT NULL,            -- Persian display name
  uses_cycle  TINYINT(1)       NOT NULL DEFAULT 0,
  day_rule    ENUM('workday','weekend','any') NOT NULL DEFAULT 'any',
  sort_order  TINYINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uq_overtime_types_code (code)
) ENGINE=InnoDB;

-- ── Authentication ────────────────────────────────────────────────────────
CREATE TABLE users (
  id             INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  username       VARCHAR(64)      NOT NULL,
  password_hash  VARCHAR(255)     NOT NULL,
  display_name   VARCHAR(120)     NOT NULL,
  division_id    TINYINT UNSIGNED NOT NULL,         -- the division this admin manages
  is_active      TINYINT(1)       NOT NULL DEFAULT 1,
  last_login_at  DATETIME         NULL,
  created_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username),
  CONSTRAINT fk_users_division FOREIGN KEY (division_id) REFERENCES divisions (id)
) ENGINE=InnoDB;

CREATE TABLE login_attempts (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  username        VARCHAR(64)     NOT NULL,         -- as typed, lower-cased, truncated
  ip_address      VARBINARY(16)   NOT NULL,         -- INET6_ATON(); fits IPv4 and IPv6
  was_successful  TINYINT(1)      NOT NULL,
  attempted_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_attempts_user_ip_time (username, ip_address, attempted_at),
  KEY idx_attempts_ip_time (ip_address, attempted_at)
) ENGINE=InnoDB;

-- ── Personnel ─────────────────────────────────────────────────────────────
CREATE TABLE personnel (
  id              INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  personnel_code  VARCHAR(32)      NOT NULL,        -- business "Personnel ID", Latin digits/letters (may start with 0)
  full_name       VARCHAR(120)     NOT NULL,        -- as displayed (Persian)
  name_search     VARCHAR(160)     NOT NULL,        -- normalised copy used for searching (see §7.5)
  division_id     TINYINT UNSIGNED NOT NULL,
  is_active       TINYINT(1)       NOT NULL DEFAULT 1,
  created_at      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_personnel_code (personnel_code),
  KEY idx_personnel_division_active (division_id, is_active),
  CONSTRAINT fk_personnel_division FOREIGN KEY (division_id) REFERENCES divisions (id)
) ENGINE=InnoDB;

-- ── Cycles (per division) ─────────────────────────────────────────────────
CREATE TABLE cycles (
  id            INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  division_id   TINYINT UNSIGNED NOT NULL,
  cycle_number  INT UNSIGNED     NOT NULL,          -- 1, 2, 3 … within the division (shown in the UI)
  started_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  closed_at     DATETIME         NULL,
  -- 1 while open, NULL once closed. UNIQUE (division_id, open_marker) → at most ONE open cycle per division.
  open_marker   TINYINT(1) GENERATED ALWAYS AS (IF(closed_at IS NULL, 1, NULL)) STORED,
  PRIMARY KEY (id),
  UNIQUE KEY uq_cycles_division_number (division_id, cycle_number),
  UNIQUE KEY uq_cycles_one_open_per_division (division_id, open_marker),
  CONSTRAINT fk_cycles_division FOREIGN KEY (division_id) REFERENCES divisions (id)
) ENGINE=InnoDB;

-- ── Overtime entries ──────────────────────────────────────────────────────
CREATE TABLE overtime_entries (
  id                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  personnel_id      INT UNSIGNED     NOT NULL,
  division_id       TINYINT UNSIGNED NOT NULL,      -- snapshot; equals the cycle's division for weekday entries
  overtime_type_id  TINYINT UNSIGNED NOT NULL,
  overtime_date     DATE             NOT NULL,      -- Gregorian; shown as Solar Hijri
  hours             DECIMAL(4,2)     NOT NULL,
  description       VARCHAR(255)     NULL,          -- optional
  cycle_id          INT UNSIGNED     NULL,          -- only for types with uses_cycle = 1
  created_by        INT UNSIGNED     NOT NULL,
  created_at        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  -- One weekday overtime per person per cycle. NULL cycle_id rows never collide in MySQL.
  UNIQUE KEY uq_entries_cycle_personnel (cycle_id, personnel_id),
  KEY idx_entries_date (overtime_date),
  KEY idx_entries_personnel_date (personnel_id, overtime_date),
  -- Hard sanity bound only; the business cap (default 8 h) is configurable in the app.
  CONSTRAINT chk_entries_hours CHECK (hours > 0 AND hours <= 24),
  CONSTRAINT fk_entries_personnel FOREIGN KEY (personnel_id)     REFERENCES personnel (id),
  CONSTRAINT fk_entries_division  FOREIGN KEY (division_id)      REFERENCES divisions (id),
  CONSTRAINT fk_entries_type      FOREIGN KEY (overtime_type_id) REFERENCES overtime_types (id),
  CONSTRAINT fk_entries_cycle     FOREIGN KEY (cycle_id)         REFERENCES cycles (id),
  CONSTRAINT fk_entries_user      FOREIGN KEY (created_by)       REFERENCES users (id)
) ENGINE=InnoDB;

-- ── Audit (deletions) ─────────────────────────────────────────────────────
CREATE TABLE audit_log (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     INT UNSIGNED    NOT NULL,
  action      VARCHAR(40)     NOT NULL,             -- 'overtime.delete'
  entity_id   BIGINT UNSIGNED NULL,
  details     JSON            NOT NULL,             -- full snapshot of the deleted row (+ personnel code/name, Jalali date, type)
  ip_address  VARBINARY(16)   NULL,
  created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_audit_created (created_at),
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB;
```

### 6.3 Seed data (`database/seed.sql`)

```sql
INSERT INTO divisions (name) VALUES
  ('پشتیبانی سخت‌افزار'),                 -- Hardware Support
  ('شبکه و زیرساخت'),                      -- Networking and Infrastructure
  ('پایگاه داده و امنیت اطلاعات');        -- Database and Information Security

INSERT INTO overtime_types (code, name, uses_cycle, day_rule, sort_order) VALUES
  ('weekdays',     'روزهای کاری',  1, 'workday', 1),
  ('weekend',      'آخر هفته',     0, 'weekend', 2),
  ('out_of_quota', 'خارج از سهمیه', 0, 'any',     3);

-- Cycle 1 (open) for every division. Any future division must get one too.
INSERT INTO cycles (division_id, cycle_number) SELECT id, 1 FROM divisions;
```

An optional `database/dev_sample_data.sql` (fake personnel and a dev admin per division) is for local development only.

### 6.4 Design notes

- **Dates as `DATE`.** Range filters, sorting and indexes work natively. Solar Hijri is a presentation concern (§7.2).
- **Behaviour in data, not in `if` chains.** `uses_cycle` and `day_rule` live on `overtime_types`; code reads the flags instead of comparing against `'weekdays'`.
- **Unique `(cycle_id, personnel_id)`** is the hard guarantee for the cycle rule even if two requests race or application code has a bug.
- **Unique `(division_id, open_marker)`** guarantees one open cycle per division (MySQL has no partial indexes).
- **Snapshot `division_id`** keeps history right when someone transfers.
- **`name_search`** is a normalised copy of the name (ZWNJ removed, Arabic `ي`/`ك` → `ی`/`ک`, digits Latin, lower-cased) maintained by `bin/personnel.php`; reports search `name_search` and `personnel_code`. This avoids the classic Persian-search pitfalls without special collations.
- **Hard delete + `audit_log`.** Soft delete would collide with the `(cycle_id, personnel_id)` unique key; the audit row keeps a full snapshot instead.
- **Migrations.** MVP ships `schema.sql` + `seed.sql`. Later changes go in `database/migrations/NNNN_description.sql`, applied manually in order.
- **DB account.** The app connects as `overtime_app` with `SELECT, INSERT, UPDATE, DELETE` on this schema only (no DDL, no `GRANT`).

### 6.5 Key queries

**Personnel list with cycle status** (Submit page; all active personnel, status measured against *their own division's* open cycle):

```sql
SELECT p.id, p.personnel_code, p.full_name, p.division_id,
       EXISTS (SELECT 1
                 FROM overtime_entries e
                 JOIN cycles c ON c.id = e.cycle_id
                              AND c.closed_at IS NULL
                              AND c.division_id = p.division_id
                WHERE e.personnel_id = p.id) AS used_in_open_cycle
  FROM personnel p
 WHERE p.is_active = 1;
-- sorted in PHP: Collator('fa_IR')
```

**Cycle summary strip** (one row per division):

```sql
SELECT d.id AS division_id, d.name, c.id AS cycle_id, c.cycle_number,
       COUNT(p.id) AS total_active,
       COALESCE(SUM(EXISTS (SELECT 1 FROM overtime_entries e
                             WHERE e.cycle_id = c.id AND e.personnel_id = p.id)), 0) AS done
  FROM divisions d
  JOIN cycles c ON c.division_id = d.id AND c.closed_at IS NULL
  LEFT JOIN personnel p ON p.division_id = d.id AND p.is_active = 1
 GROUP BY d.id, d.name, c.id, c.cycle_number;
```

**Report** — the `WHERE` clause is assembled from a whitelist of optional conditions joined with `AND`, all bound as parameters. Viewing is not restricted by division or date:

```sql
SELECT e.id, e.overtime_date, p.personnel_code, p.full_name, d.name AS division, e.division_id,
       t.name AS type, e.hours, c.cycle_number, e.description
  FROM overtime_entries e
  JOIN personnel       p ON p.id = e.personnel_id
  JOIN divisions       d ON d.id = e.division_id
  JOIN overtime_types  t ON t.id = e.overtime_type_id
  LEFT JOIN cycles     c ON c.id = e.cycle_id
 WHERE e.overtime_date >= :from                              -- if from is set
   AND e.overtime_date <= :to                                -- if to is set
   AND e.division_id = :division_id                          -- if set
   AND e.overtime_type_id = :type_id                         -- if set
   AND (p.name_search LIKE :q ESCAPE '\\'
        OR p.personnel_code LIKE :q ESCAPE '\\')             -- if set (q normalised, wildcards escaped)
 ORDER BY e.overtime_date DESC, e.id DESC
 LIMIT :limit OFFSET :offset;                                -- omitted for CSV export
```

`can_delete` for a row is computed in PHP (`row.division_id === user.division_id`), never from the client.

---

## 7. Persian UI, RTL and Solar Hijri dates

### 7.1 Language and layout

- `<html lang="fa" dir="rtl">`. All user-visible text is Persian and comes from **`lang/fa.php`** through `t('key')`. Server messages (validation, flash, errors) use the same file. Strings needed by JS are passed in a `<script type="application/json" id="i18n">` data block (not executable, so the strict CSP allows it).
- Tailwind **logical utilities only** (`ms-*`, `me-*`, `ps-*`, `pe-*`, `start-*`, `end-*`, `text-start`, `border-s`, `rounded-s`), plus `rtl:` variants for icons/arrows that must flip.
- **Font:** Vazirmatn variable `woff2` in `public/assets/fonts/`, declared with `@font-face` (`font-display: swap`) in `input.css`; fallback `Tahoma, system-ui, sans-serif`.
- **Bidi hygiene:** dates, personnel IDs, hours and the date/hours inputs get `dir="ltr"` (right-aligned via `text-end` where needed) so digit/slash sequences never reorder.
- **Digits:** `UI_PERSIAN_DIGITS=1` renders ۰–۹ on screen via helper `num()` (`strtr`) and `Intl.NumberFormat('fa-IR')` in JS. Inputs accept Persian **or** Latin digits (and `٫` / `,` as decimal separators); the server normalises before validating. CSV and DB always use Latin digits.
- **Sorting:** the personnel list is sorted with `Collator('fa_IR')`.
- Wireframes in this document are drawn left-to-right with English labels for readability; the real UI is mirrored and labelled per the glossary in §7.6.

### 7.2 Server dates (`App\Support\JalaliDate`, `ext-intl`)

**Rule: the server is the only converter for persisted data.** The browser sends a Jalali string; PHP converts it.

| Method | Purpose |
|---|---|
| `normalizeDigits(string)` | Persian `۰-۹` and Arabic-Indic `٠-٩` → Latin `0-9` |
| `toGregorian(string $jalali): ?string` | `'1405/07/11'` → `'2026-10-03'`, or `null` if invalid |
| `fromGregorian(string $iso, bool $persianDigits = false): string` | `'2026-10-03'` → `'1405/07/11'` (or `۱۴۰۵/۰۷/۱۱`) |
| `weekdayName(string $iso): string` | `'پنجشنبه'` (Persian weekday via `IntlDateFormatter`, pattern `EEEE`) |
| `isWeekendDay(string $iso, array $weekendDays): bool` | ISO weekday (`format('N')`) in config list |
| `today(): string` | Today as Jalali in `Asia/Tehran` |

```php
// Gregorian → Jalali. IntlDateFormatter::TRADITIONAL is REQUIRED, otherwise the
// '@calendar=persian' part of the locale is ignored and the Gregorian calendar is used.
$fmt = new IntlDateFormatter(
    'en_US@calendar=persian', IntlDateFormatter::NONE, IntlDateFormatter::NONE,
    'UTC', IntlDateFormatter::TRADITIONAL, 'yyyy/MM/dd'          // Latin digits
);

// Jalali → Gregorian (month is 0-based in IntlCalendar)
$cal = IntlCalendar::createInstance('UTC', 'en_US@calendar=persian');
$cal->clear();
$cal->set($year, $month - 1, $day);
$iso = $cal->toDateTime()->format('Y-m-d');
```

**Strict validation.** `IntlCalendar` is lenient (month 7 day 31 rolls into month 8). After converting, convert **back** to Jalali and require an exact match with the input. This rejects `1405/07/31`, `1404/12/30` (non-leap) and similar.

Accepted input: `^\d{4}[/-]\d{1,2}[/-]\d{1,2}$` after digit normalisation.

### 7.3 Browser (`assets/js/lib/jalali.js`)

- **Gregorian → Jalali:** `Intl.DateTimeFormat('en-u-ca-persian-nu-latn', {year:'numeric', month:'numeric', day:'numeric', timeZone:'UTC'}).formatToParts(date)`; read `year`/`month`/`day`, ignore `era`.
- **Jalali → Gregorian:** anchor on 1 Farvardin (always 19–22 March of year + 621; probe those days with the function above), then add day offsets. Month lengths: months 1–6 = 31, 7–11 = 30, month 12 = 29 (30 in leap years; leap ⇔ next Nowruz is 366 days away).
- **Names:** `Intl.DateTimeFormat('fa-IR-u-ca-persian', {month:'long'})` → فروردین … اسفند; `{weekday:'long'}` → شنبه … جمعه; `{weekday:'narrow'}` for the calendar header.
- **Weekday of a picked date:** `Date.UTC(...)` of the converted Gregorian date → `getUTCDay()`; used for the day-rule check and the weekday label.
- The week **starts on Saturday**.

### 7.4 Date picker (`datepicker.js`)

Markup: `<input type="text" name="date" data-jalali-datepicker dir="ltr" autocomplete="off" inputmode="numeric">`

- Click/focus opens a popup calendar (RTL grid, Saturday at the right edge); typing a date is also allowed.
- Previous/next month (arrows flip under RTL), year selector, "Today" button, Esc closes, arrow keys move the focused day. Weekend-day columns are tinted (Friday always; Thursday per config).
- Selecting a day writes `YYYY/MM/DD` (Persian digits if enabled) into the input. There is no hidden Gregorian field — the server converts.
- Optional `data-min` / `data-max` (Jalali) for the report's From/To pairing.
- Emits a `change` event; the Submit page uses it to refresh the weekday label and the day-rule check.
- Accessible: `role="dialog"`, labelled day buttons, focus returns to the input on close.

### 7.5 Text normalisation (`TextNormalizer.php` ↔ `normalize.js`, identical rules)

1. Arabic `ي` (U+064A) → `ی` (U+06CC); Arabic `ك` (U+0643) → `ک` (U+06A9).
2. Persian/Arabic-Indic digits → Latin.
3. Remove ZWNJ (U+200C), tatweel (U+0640) and Arabic diacritics (harakat).
4. Collapse whitespace, trim, lower-case Latin letters.

Used for: client-side personnel search, the report `q` filter, populating `personnel.name_search`, and normalising personnel codes on write.

### 7.6 UI glossary (`lang/fa.php` seed — wording to be reviewed by a native speaker)

| Key | English | Persian |
|---|---|---|
| app_name | Overtime Manager | مدیریت اضافه‌کاری |
| login / logout | Sign in / Sign out | ورود / خروج |
| username / password | Username / Password | نام کاربری / گذرواژه |
| nav_submit | Submit Overtime | ثبت اضافه‌کاری |
| nav_reports | Reports | گزارش‌ها |
| type | Overtime type | نوع اضافه‌کاری |
| division / all_divisions | Division / All divisions | واحد / همه واحدها |
| date | Date | تاریخ |
| hours | Hours | ساعت |
| description | Description | توضیحات |
| personnel | Personnel | پرسنل |
| personnel_id | Personnel ID | کد پرسنلی |
| name | Name | نام و نام خانوادگی |
| cycle | Cycle | دور |
| status | Status | وضعیت |
| search_placeholder | Search by name or ID | جستجوی نام یا کد پرسنلی |
| selected_count | N selected | N نفر انتخاب شده |
| submit | Submit | ثبت |
| delete / cancel | Delete / Cancel | حذف / انصراف |
| export_csv | Export CSV | خروجی CSV |
| from_date / to_date | From / To date | از تاریخ / تا تاریخ |
| apply / reset | Apply / Reset | اعمال / بازنشانی |
| status_available | Available | آزاد |
| status_done_cycle | Done in cycle N | انجام‌شده در دور N |
| read_only | Read-only | فقط مشاهده |
| type: weekdays | Weekdays | روزهای کاری |
| type: weekend | Weekend | آخر هفته |
| type: out_of_quota | Out of quota | خارج از سهمیه |
| division: hardware | Hardware Support | پشتیبانی سخت‌افزار |
| division: network | Networking and Infrastructure | شبکه و زیرساخت |
| division: database | Database and Information Security | پایگاه داده و امنیت اطلاعات |
| err_login | Invalid username or password | نام کاربری یا گذرواژه نادرست است. |
| err_throttle | Too many attempts | تعداد تلاش‌ها از حد مجاز گذشته است؛ چند دقیقه بعد دوباره تلاش کنید. |
| err_day_workday | Selected day is not a working day | روز انتخاب‌شده (پنجشنبه) روز کاری نیست. *(weekday name interpolated)* |
| err_day_weekend | Selected day is not a weekend day | روز انتخاب‌شده (شنبه) جزو آخر هفته نیست. *(weekday name interpolated)* |
| err_hours_max | Hours exceed the limit | حداکثر ساعت مجاز برای هر ثبت ۸ ساعت است. |
| confirm_delete | Delete this record? | آیا از حذف این رکورد اضافه‌کاری مطمئن هستید؟ |

---

## 8. Authentication, authorization & security

### 8.1 Login flow

1. `GET /login` shows the form (with CSRF token). If already authenticated → redirect to `/overtime/new`.
2. `POST /login`:
   1. Verify CSRF token.
   2. **Throttle check** (§8.3). If blocked → generic "too many attempts" message.
   3. Look up the user by lower-cased username. If missing or inactive, still run `password_verify` against a **dummy hash** so response time does not reveal whether the account exists.
   4. `password_verify` against the stored hash.
   5. On failure: record the attempt and show the **same generic message** for every failure.
   6. On success: `session_regenerate_id(true)` (prevents session fixation), store `user_id`, `created_at`, `last_activity` in the session, `password_needs_rehash` → re-hash if parameters changed, update `last_login_at`, clear that user+IP's failed attempts, redirect to the originally requested page (local paths only — must start with a single `/`, never `//` or a scheme) or `/overtime/new`.
3. `POST /logout` (CSRF-protected): clear `$_SESSION`, expire the cookie, `session_destroy()`.

### 8.2 Passwords

- `password_hash($pw, PASSWORD_ARGON2ID, ['memory_cost' => 19456, 'time_cost' => 2, 'threads' => 1])` (OWASP minimum profile; tune upward to the server). Fall back to `PASSWORD_DEFAULT` only if Argon2id is unavailable.
- Minimum **12** characters, no composition rules, any characters allowed, max 128.
- Passwords are set with `bin/create-user.php` using a hidden prompt (never as a command-line argument, never logged).
- Passwords and hashes never appear in logs or error pages.

### 8.3 Brute-force protection

Using `login_attempts`:

- Block when **≥ 5** failures for the same *(username, IP)* in the last **15 min**, or **≥ 20** failures from the same IP in that window.
- Keyed on *(username, IP)*, not the account alone, so an attacker cannot lock real users out.
- Thresholds come from `.env`. Old rows are pruned by `bin/prune-login-attempts.php` (daily cron).

### 8.4 Sessions

| Setting | Value |
|---|---|
| Cookie flags | `HttpOnly`, `Secure` (production), `SameSite=Lax`, `Path=/` |
| Cookie name | `__Host-ot_sid` in production (requires HTTPS, `Path=/`, no `Domain`) |
| `use_strict_mode` / `use_only_cookies` | on |
| Storage | Native file sessions in `storage/sessions/` (mode 0700, outside web root) |
| Idle timeout | 30 min (`SessionTimeout` middleware) |
| Absolute timeout | 8 h |
| ID regeneration | At login |
| Per-request user load | `RequireAuth` re-loads the user (id from session) on **every** request and rejects inactive users, so deactivation and division changes take effect immediately. The division is **never** cached in the session or trusted from the client. |

### 8.5 CSRF

- Per-session token: `bin2hex(random_bytes(32))`.
- Hidden field on every POST form (`csrf_field()`), verified with `hash_equals` in `CsrfGuard` for **all** `POST` requests including login, logout, submit and delete.
- `SameSite=Lax` cookies are defence in depth.
- Failure → HTTP 403 with a friendly Persian "session expired — reload and try again" page.
- **Double-submit guard** on the overtime form: a one-time `form_nonce` is generated per page render, stored in the session and consumed by `POST /overtime`. Replays (browser back + resubmit, double clicks) are rejected. This matters because Weekend/Out-of-quota entries have no unique key to catch duplicates.

### 8.6 Authorization (division-scoped)

| Action | Own division | Other divisions |
|---|---|---|
| See personnel list and cycle status (Submit page) | ✔ | ✔ read-only (checkboxes locked) |
| Submit overtime | ✔ | ✗ (403) |
| View Reports / export CSV | ✔ | ✔ |
| Delete an entry | ✔ | ✗ (button hidden, server returns 403) |

Enforcement rules:

- `App\Services\AccessPolicy` is the single place that decides: `canSubmitFor(user, divisionId)` and `canDelete(user, entry)`. Both compare against `user.division_id` loaded from the DB in the current request.
- The UI hides/disables controls for convenience only. **Every** write path re-checks on the server: submit verifies each selected person's division (step 4 of §5.4); delete verifies the entry's division **after** loading it by id (§5.5) — this prevents ID-guessing (IDOR) attacks.
- The division of a new entry is **never** read from the form. The Submit page's division dropdown has no `name` attribute and is not submitted.
- Authorization failures return 403 and are written to the app log as security events (user, IP, route, target id).

### 8.7 Threat → mitigation checklist

| Threat | Mitigation |
|---|---|
| SQL injection | PDO prepared statements only, `ATTR_EMULATE_PREPARES => false`; dynamic parts come from whitelists; `IN (…)` lists built from placeholders |
| XSS | All output through `e()` = `htmlspecialchars($s, ENT_QUOTES \| ENT_SUBSTITUTE, 'UTF-8')`; JS uses `textContent`, never `innerHTML` with data; strict CSP |
| CSRF | §8.5 |
| Broken access control / IDOR | §8.6; per-request user load; server-side division checks |
| Session fixation / hijack | Regenerate ID on login, `HttpOnly` + `Secure` + `SameSite`, timeouts, HTTPS only |
| Credential stuffing / brute force | Argon2id, throttling, generic errors, timing equalisation |
| User enumeration | Same message and similar timing for unknown user vs wrong password |
| Clickjacking | CSP `frame-ancestors 'none'` + `X-Frame-Options: DENY` |
| Open redirect | Post-login and post-delete redirects restricted to local paths (delete: must start with `/reports`) |
| CSV / formula injection | Cells starting with `=`, `+`, `-`, `@`, tab or CR are prefixed with `'` on export (§9.5) |
| Mass assignment / tampering | Controllers read an explicit field list; server re-validates everything the UI "disables" (day rule, cap, cycle, division) |
| Accidental data loss | Delete requires confirmation + CSRF + audit snapshot |
| Information leakage | `display_errors=0`, generic 500 page, details only in `storage/logs/` |
| Secrets in repo | `.env` outside web root and git-ignored; `.env.example` committed |

**Response headers** (global `SecurityHeaders` middleware):

```
Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:;
                         font-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Referrer-Policy: same-origin
Strict-Transport-Security: max-age=31536000          (HTTPS only)
Cache-Control: no-store                               (all authenticated pages and the CSV)
```

The strict CSP works because the app has **no inline scripts or styles**: Tailwind is compiled to a file, JS lives in files, server data reaches JS via `data-*` attributes and a JSON data block.

---

## 9. Pages

Common layout (`templates/layout.php`, RTL): top bar with app name, nav (**ثبت اضافه‌کاری**, **گزارش‌ها**), current user + their division, Logout button (a small POST form). Flash messages render under the nav (`role="status"` / `role="alert"`). Wireframes below are LTR with English labels (see §7.1).

### 9.1 Login (`GET/POST /login`)

| Element | Details |
|---|---|
| Fields | Username (`autocomplete="username"`), Password (`autocomplete="current-password"`) |
| Actions | "ورود" button; CSRF hidden field |
| Errors | Single generic message; throttle message when blocked |
| Layout | Centered card, no nav bar |

### 9.2 Submit Overtime (`GET /overtime/new`, `POST /overtime`)

**Wireframe**

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│ Overtime Manager     Submit Overtime │ Reports            Ali Karimi · Networking [Out] │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│ Type            Division (filter)      Date                 Hours     Description        │
│ [Weekdays    ▾] [Networking       ▾]   [1405/07/11 📅] Sat  [ 2.5 ]    [(optional)_____] │
│                                         ⚠ message shown here if type/date do not match   │
│                                                                                         │
│ Hardware Support: C4 · 12/20   ▌Networking: C2 · 3/9▐   Database & Security: C7 · 5/6    │
│                                                                                         │
│ [🔍 Search by name or ID…]                              3 selected    [Submit]          │
│ ┌───┬───────────────────┬──────────────┬─────────────────────────────┬────────────────┐ │
│ │ ☐ │ Name              │ Personnel ID │ Division                    │ Status         │ │
│ ├───┼───────────────────┼──────────────┼─────────────────────────────┼────────────────┤ │
│ │ ☑ │ Ali Rezaei        │ 10234        │ Networking and Infra…       │ Available      │ │
│ │ ☐ │ Sara Ahmadi       │ 10311        │ Networking and Infra…       │ Done · C2      │ │ ← greyed, disabled (cycle)
│ │ ☐ │ Reza Moradi       │ 20045        │ Hardware Support            │ 🔒 Read-only    │ │ ← disabled (other division)
│ └───┴───────────────────┴──────────────┴─────────────────────────────┴────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

On narrow screens the form row wraps to a single column and the table scrolls horizontally inside its container.

**Form fields**

| Field | Control | Name | Server validation |
|---|---|---|---|
| Overtime type | `<select>`; options carry `data-uses-cycle` and `data-day-rule` | `type_id` | Required; must exist |
| Division | `<select>` "همه واحدها" + 3 divisions; **defaults to the admin's own division** | *(none — display filter only, C2)* | n/a |
| Date | Jalali picker + weekday label | `date` | Required; valid Jalali date; within ±366 days of today; **must satisfy the type's day rule (§5.2)** |
| Hours | `<input type="text" inputmode="decimal" dir="ltr">` | `hours` | Required; numeric (Persian/Latin digits, `.`/`٫`/`,`); 0.25 ≤ h ≤ cap (8); multiple of 0.25 |
| Description | `<input type="text" maxlength="255">` | `description` | **Optional**; trimmed; ≤ 255 chars (`mb_strlen`); control characters stripped; empty → `NULL` |
| Personnel | Checkbox per row | `personnel_ids[]` | 1–500 ids; integers; de-duplicated; each exists and is active; each in **the user's division** (else 403); if the type uses a cycle, none already used in the open cycle |
| — | Hidden | `csrf_token`, `form_nonce` | §8.5 |

*Why not `type="number"` for hours?* Browsers handle Persian digits and Persian keyboard layouts inconsistently in number inputs; a text input with `inputmode="decimal"` plus normalisation behaves the same everywhere. Visually and functionally it is still a numeric field.

**Client behaviour (`pages/submit-overtime.js`)**

| Feature | Behaviour |
|---|---|
| **Cycle summary strip** | Server-rendered chips for all three divisions: name · cycle number · done/total. The admin's own division is highlighted. |
| **Row state** | Each row carries `data-own`, `data-used` (already has an entry in its division's open cycle), `data-division-id`. |
| **Disabling rule** | A row's checkbox is disabled if `!own` **or** (type uses cycle **and** `used`). Disabled rows are un-ticked and muted. Status column: "فقط مشاهده" for other divisions' rows (plus their cycle state), "انجام‌شده در دور N" / "آزاد" for own rows when the type uses a cycle, "—" otherwise. Re-evaluated on every type change. |
| **Division filter** | Hides rows whose `data-division-id` does not match; "همه واحدها" shows all. |
| **Search** | Case-insensitive substring match on name **or** personnel ID after §7.5 normalisation of both sides (so `۱۰۲۳۴` and `10234` match the same row; `ی/ي`, ZWNJ and spacing differences don't matter). Combines with the division filter. |
| **Selection** | Hidden rows keep their ticked state. Counter shows total selected, e.g. "۷ نفر انتخاب شده (۲ مخفی)". Header checkbox = "select all visible, enabled rows" with an indeterminate state. |
| **Weekday label** | Shows the Persian weekday of the chosen date (e.g. "پنجشنبه") next to the date field. |
| **Day-rule check** | On type or date change: if the type's `day_rule` is `workday` and the date is a weekend day, or `weekend` and it is not, show the message (§7.6) under the date field. `any` is never checked. |
| **Submit button** | **Disabled** while any of these holds: nothing selected · date empty/invalid/out of window · hours empty/invalid/over cap · **type/date mismatch**. Also disabled after click to prevent double submits. |
| **Default date** | Today (Jalali) if empty. |

**Server behaviour (`POST /overtime`)**

1. `CsrfGuard` → consume `form_nonce` → build input DTO → validate (including the day rule — the button state is advisory).
2. Validation error → re-render with HTTP 422, field errors, **old input preserved** (including ticked personnel).
3. `OvertimeService::submitBatch()` (§5.4).
4. Business error (already used / inactive) → re-render naming the people; nothing saved. Tampering (other division) → 403.
5. Success → flash, e.g. "اضافه‌کاری برای ۳ نفر ثبت شد — روزهای کاری، ۱۴۰۵/۰۷/۱۱، ۲٫۵ ساعت", plus "دور ۲ تکمیل شد؛ دور ۳ آغاز شد." when the cycle closed; redirect to `GET /overtime/new` (Post/Redirect/Get).

### 9.3 Reports (`GET /reports`)

Server-rendered; filters travel in the query string, so results are bookmarkable and the export reuses them. All admins see **all divisions** and **all dates**.

**Wireframe**

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│ From [1405/06/01 📅]  To [1405/07/11 📅]  Division [All ▾]  Type [All ▾]                  │
│ Name / Personnel ID [______________]        [Apply] [Reset]               [Export CSV]   │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│ 42 entries · 96.5 hours                                                                 │
│ ┌────────────┬─────────┬────────────┬───────────────┬────────┬─────┬─────┬──────┬──────┐ │
│ │ Date       │ ID      │ Name       │ Division      │ Type   │ Hrs │ Cyc │ Desc │      │ │
│ ├────────────┼─────────┼────────────┼───────────────┼────────┼─────┼─────┼──────┼──────┤ │
│ │ 1405/07/11 │ 10234   │ Ali Rezaei │ Networking…   │ Weekday│ 2.5 │ 2   │ …    │[Del] │ │ ← own division
│ │ 1405/07/09 │ 20045   │ Reza Moradi│ Hardware…     │ Weekend│ 6   │ —   │      │      │ │ ← read-only row
│ └────────────┴─────────┴────────────┴───────────────┴────────┴─────┴─────┴──────┴──────┘ │
│ ‹ Prev   Page 1 of 1   Next ›                                                           │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

**Filters** — all optional, combined with `AND`:

| Filter | Control | Query param | Rule |
|---|---|---|---|
| From date | Jalali picker | `from` | Valid Jalali date; inclusive; **any date in the past is allowed** |
| To date | Jalali picker | `to` | Valid Jalali date; inclusive; must be ≥ `from` |
| Division | `<select>` | `division_id` | Must exist |
| Overtime type | `<select>` | `type_id` | Must exist |
| Name / ID | Text | `q` | ≤ 100 chars; normalised (§7.5); `LIKE %q%` on `name_search` **or** `personnel_code` |
| Page | — | `page` | Integer ≥ 1 |

- `ReportFilter::fromQuery()` parses and validates once; the page and the CSV export both use it, so the export always equals the filtered result.
- Invalid filter → error beside the field and no query is run.
- Sort: date descending, then id descending. Page size 50 (config).
- Summary line: total count and sum of hours for the whole filtered set (not just the page).
- The form is `method="get" action="/reports"`. **Export CSV** is a second submit button with `formaction="/reports/export"`, so it exports whatever is currently in the form with no JS. Reset is a link to `/reports`.
- Cycle column: that division's cycle number, or `—`.
- **Actions column:** a **Delete** button appears only on rows where `entry.division_id === user.division_id`. Other rows show nothing (read-only).

### 9.4 Delete flow (`POST /overtime/delete`)

1. Clicking **Delete** opens a native `<dialog>` filled by JS with the row summary (name, date, type, hours) and the text "آیا از حذف این رکورد اضافه‌کاری مطمئن هستید؟" with **Delete** / **Cancel** buttons.
2. Confirm submits a POST form with `csrf_token`, `entry_id` and `back` (the current `/reports?…` URL, validated to start with `/reports`).
3. Server runs `OvertimeService::deleteEntry()` (§5.5): authorization by loaded entry's division, delete, cycle handling, audit row.
4. Redirect back to the same filtered page (and page number, clamped if now out of range) with a flash: "رکورد حذف شد." — plus "دور N دوباره باز شد." if an "undo close" happened.

### 9.5 CSV export (`GET /reports/export`)

| Aspect | Spec |
|---|---|
| Auth | Required. Same filters as §9.3; **no pagination** (all matching rows, all divisions the filter allows). |
| Headers | `Content-Type: text/csv; charset=utf-8`; `Content-Disposition: attachment; filename="overtime-report-1405-07-11.csv"` (ASCII name, today's Jalali date) |
| Encoding | UTF-8 **with BOM** (`EF BB BF`) so Excel shows Persian text correctly |
| Columns | `تاریخ, کد پرسنلی, نام و نام خانوادگی, واحد, نوع اضافه‌کاری, ساعت, دور, توضیحات` (Date, Personnel ID, Name, Division, Type, Hours, Cycle, Description) |
| Date | Jalali `YYYY/MM/DD`, **Latin digits** |
| Hours | Dot decimal (`2.5`), Latin digits |
| Cycle | The division's cycle number, or empty for non-weekday entries |
| Description | Empty when null |
| Writer | `fputcsv($out, $row, ',', '"', '')` — the escape argument is passed explicitly because relying on its default is deprecated in recent PHP |
| Injection guard | Any text cell starting with `=`, `+`, `-`, `@`, tab or CR is prefixed with `'` |
| Memory | Rows streamed from an unbuffered PDO query straight to `php://output` |

Excel notes (put in the README): Excel strips leading zeros from numeric-looking cells, so if personnel codes can start with `0` they can be exported as `="0123"` (safe, because codes are validated to `^[0-9A-Za-z]+$` on write). Excel installs that use `;` as list separator may need **Data → From Text/CSV**.

---

## 10. Routes

| Method | Path | Auth | CSRF | Description |
|---|---|---|---|---|
| GET | `/` | – | – | Redirect to `/overtime/new` (authenticated) or `/login` |
| GET | `/login` | public | – | Login form |
| POST | `/login` | public | ✔ | Authenticate |
| POST | `/logout` | ✔ | ✔ | End session |
| GET | `/overtime/new` | ✔ | – | Submit Overtime page |
| POST | `/overtime` | ✔ + own division | ✔ | Store a batch of entries |
| POST | `/overtime/delete` | ✔ + own division | ✔ | Delete one entry |
| GET | `/reports` | ✔ | – | Report page |
| GET | `/reports/export` | ✔ | – (read-only) | CSV download |

Unknown route → 404 page. Wrong method → 405. Unauthenticated access to a protected route → redirect to `/login` (remembering the intended local path). Authorization failure → 403.

---

## 11. Project structure

```
overtime-mgmt/
├── public/                         # ← the ONLY directory exposed by the web server
│   ├── index.php                   # front controller
│   └── assets/
│       ├── css/app.css             # generated by Tailwind (not hand-edited)
│       ├── fonts/Vazirmatn-*.woff2 # self-hosted (SIL OFL)
│       └── js/
│           ├── lib/
│           │   ├── normalize.js    # §7.5 rules, shared by search and filters
│           │   ├── jalali.js       # Intl-based Solar Hijri math, weekday, names
│           │   ├── digits.js       # Persian/Latin digit helpers
│           │   └── datepicker.js   # in-house Jalali date picker (RTL)
│           └── pages/
│               ├── submit-overtime.js   # search, filters, row rules, day-rule check, button state
│               └── reports.js           # From/To pickers, delete <dialog>
├── src/                            # namespace App\
│   ├── bootstrap.php               # autoloader, env/config, error handler, timezone, extension check
│   ├── helpers.php                 # e(), t(), num(), url(), asset(), old(), csrf_field(), flash()
│   ├── Core/
│   │   ├── Router.php
│   │   ├── Request.php             # typed access to query/body/server; holds the current user
│   │   ├── Response.php            # html / redirect / csv helpers
│   │   ├── View.php                # template rendering with layout
│   │   ├── Session.php             # secure start, flash, timeouts
│   │   ├── Csrf.php                # token + one-time form nonce
│   │   ├── Database.php            # PDO factory
│   │   └── Config.php              # parse_ini_file(.env) + config/*.php
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── AuthController.php      # login, logout
│   │   │   ├── OvertimeController.php  # create (form), store, delete
│   │   │   └── ReportController.php    # index, export
│   │   └── Middleware/
│   │       ├── SecurityHeaders.php
│   │       ├── SessionTimeout.php
│   │       ├── RequireAuth.php         # loads current user + division each request
│   │       └── CsrfGuard.php
│   ├── Services/
│   │   ├── AuthService.php         # credential check, throttling, rehash
│   │   ├── AccessPolicy.php        # canSubmitFor(), canDelete() — division-scoped rules
│   │   ├── OvertimeService.php     # submitBatch() §5.4, deleteEntry() §5.5
│   │   ├── CycleService.php        # open(division) with lazy close/open, summary strip
│   │   ├── ReportService.php       # filtered query, totals, pagination
│   │   └── CsvExporter.php         # BOM, escaping, streaming
│   ├── Repositories/
│   │   ├── UserRepository.php
│   │   ├── LoginAttemptRepository.php
│   │   ├── PersonnelRepository.php
│   │   ├── OvertimeRepository.php
│   │   ├── CycleRepository.php
│   │   ├── AuditLogRepository.php
│   │   └── LookupRepository.php    # divisions + overtime types
│   ├── Input/                      # request DTOs with validate()
│   │   ├── LoginInput.php
│   │   ├── OvertimeSubmission.php
│   │   ├── DeleteEntryInput.php
│   │   └── ReportFilter.php
│   └── Support/
│       ├── JalaliDate.php          # §7.2
│       ├── TextNormalizer.php      # §7.5 (PHP twin of normalize.js)
│       └── Validator.php           # tiny helpers: required, int range, length…
├── templates/
│   ├── layout.php
│   ├── login.php
│   ├── overtime/new.php
│   ├── reports/index.php
│   ├── partials/                   # flash.php, field_error.php, pagination.php, delete_dialog.php
│   └── errors/                     # 403.php, 404.php, 500.php
├── lang/
│   └── fa.php                      # all UI strings (§7.6)
├── config/
│   ├── app.php                     # env-driven: timezone, limits, weekend days, page size
│   └── routes.php                  # route table with middleware per route
├── database/
│   ├── schema.sql
│   ├── seed.sql
│   ├── dev_sample_data.sql         # local development only
│   └── migrations/                 # empty at MVP
├── bin/                            # CLI only; never reachable from the web
│   ├── create-user.php
│   ├── personnel.php
│   └── prune-login-attempts.php
├── resources/
│   └── css/input.css               # Tailwind entry (+ @font-face)
├── storage/                        # git-ignored, writable by PHP only
│   ├── logs/
│   └── sessions/
├── .env.example
├── .gitignore
└── README.md                       # setup, build, deploy, Excel notes
```

### CLI scripts

| Script | Behaviour |
|---|---|
| `php bin/create-user.php <username> --division=<id\|name> [--name="…"]` | Prompts twice for the password (hidden input), enforces length ≥ 12, stores an Argon2id hash. `--reset-password` updates an existing user. Run once per admin; several admins can share a division. |
| `php bin/personnel.php add --code=10234 --name="علی رضایی" --division=2` | Validates and normalises code/name, fills `name_search`. |
| `php bin/personnel.php deactivate <code>` / `activate <code>` | Toggle `is_active`. Cycle effects are handled lazily (§5.3). |
| `php bin/personnel.php move <code> --division=3` | Changes a person's division (old entries keep their snapshot). |
| `php bin/personnel.php list [--division=2] [--all]` | Lists personnel. |
| `php bin/personnel.php rebuild-search` | Recomputes `name_search` for all rows (use after any manual SQL load). |
| `php bin/prune-login-attempts.php` | Deletes `login_attempts` older than 7 days (cron). |

---

## 12. Configuration

`.env` (outside web root, mode 0600, never committed). Loaded with `parse_ini_file($path, false, INI_SCANNER_RAW)`; quote values that contain special characters.

```ini
; ── App ──
APP_ENV="production"
APP_DEBUG="0"
APP_URL="https://overtime.example.org"
APP_TIMEZONE="Asia/Tehran"
APP_LOCALE="fa"
; 1 = show Persian digits on screen (CSV/DB always Latin)
UI_PERSIAN_DIGITS="1"

; ── Database ──
DB_HOST="127.0.0.1"
DB_PORT="3306"
DB_NAME="overtime_mgmt"
DB_USER="overtime_app"
DB_PASS="change-me"

; ── Session ──
; Use a plain name such as ot_sid and COOKIE_SECURE=0 on local HTTP dev.
SESSION_NAME="__Host-ot_sid"
COOKIE_SECURE="1"
SESSION_IDLE_MINUTES="30"
SESSION_ABSOLUTE_HOURS="8"

; ── Login throttling ──
LOGIN_WINDOW_MINUTES="15"
LOGIN_MAX_FAILURES_PER_USER_IP="5"
LOGIN_MAX_FAILURES_PER_IP="20"

; ── Overtime rules ──
OVERTIME_MAX_HOURS="8"
OVERTIME_HOURS_STEP="0.25"
; Submission window only; reports have no date limit.
OVERTIME_DATE_WINDOW_DAYS="366"
; Days that count as weekend for the Weekdays/Weekend day rules (mon..sun).
WEEKEND_DAYS="thu,fri"
REPORT_PAGE_SIZE="50"
```

**Time zones.** PHP's default zone is `APP_TIMEZONE` (`Asia/Tehran`, currently a fixed +03:30 offset without DST); "today", the default date and the ±366-day window use it. The PDO connection runs `SET time_zone = '+00:00'`, so `created_at`/`closed_at` are stored in UTC. `overtime_date` is a plain `DATE` and is unaffected.

---

## 13. Frontend build

- **Tailwind 4 standalone CLI** (single binary; no Node). Entry file `resources/css/input.css`:

  ```css
  @import "tailwindcss";
  @source "../../templates";
  @source "../../public/assets/js";   /* classes toggled from JS, e.g. hidden, opacity-50 */

  @font-face {
    font-family: "Vazirmatn";
    src: url("/assets/fonts/Vazirmatn-Variable.woff2") format("woff2");
    font-weight: 100 900;
    font-display: swap;
  }

  @theme {
    --font-sans: "Vazirmatn", Tahoma, system-ui, sans-serif;
  }
  ```

- Dev: `./tailwindcss -i resources/css/input.css -o public/assets/css/app.css --watch`
- Release: same command with `--minify`. Build in the release step so the server does not need the binary; the generated `app.css` is the artifact.
- **JS:** `<script type="module" src="…">`, one entry per page, shared modules imported natively. No transpiling.
- **Cache busting:** `asset('css/app.css')` appends `?v=<filemtime>`.
- **Do not use the Tailwind Play CDN** in production: it needs inline script/style and an external host, which conflicts with the strict CSP.
- **RTL conventions:** logical utilities only (§7.1); test every component in RTL; arrows/chevrons use `rtl:` flips.
- **Accessibility basics:** every input has a `<label>`; disabled checkboxes have a `title`/text explaining why (cycle vs read-only); the selection counter and day-rule message sit in `aria-live="polite"` regions; visible focus rings; colour is never the only status indicator.

---

## 14. Errors & logging

| Case | Handling |
|---|---|
| Uncaught exception | Global handler logs to `storage/logs/app.log` (message, file, line, request path — **no** request bodies) and shows a generic Persian 500 page |
| Validation error | Re-render with 422 and per-field Persian messages; old input preserved |
| CSRF / nonce failure | 403 page or redirect back with a flash message |
| Authorization failure | 403 page + security log entry |
| 404 / 405 | Simple templates |
| DB down | Generic 500; logged |
| PHP settings (production) | `display_errors=0`, `log_errors=1`, `expose_php=0` |

Logged security events (INFO/WARN): successful login, failed login (username + IP), throttle triggered, logout, authorization failures, deletions (also in `audit_log`). Never log passwords or session IDs.

---

## 15. Deployment

**Requirements:** a Linux host with HTTPS, PHP 8.5-FPM with the extensions in §3.1, MySQL 9.7 LTS (or 8.4 LTS).

**Nginx sketch**

```nginx
server {
    listen 443 ssl;
    http2 on;
    server_name overtime.example.org;
    root /var/www/overtime-mgmt/public;

    location / { try_files $uri /index.php$is_args$args; }

    location = /index.php {
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root/index.php;
        fastcgi_pass unix:/run/php/php-fpm.sock;
    }

    location ~ \.php$ { return 404; }      # nothing else is executable
    location ~ /\.    { deny all; }        # dotfiles
}
```

(Apache: point `DocumentRoot` at `public/` and rewrite everything that is not a file to `index.php`.)

**Local development:** `php -S localhost:8000 -t public public/index.php`, with `.env` set to `COOKIE_SECURE=0` and a plain session name.

**First install**

1. Create the DB and the `overtime_app` account; run `database/schema.sql` then `database/seed.sql`.
2. Copy `.env.example` → `.env`, fill values.
3. Create the admins: `php bin/create-user.php <username> --division=…` (one or more per division).
4. Add personnel with `php bin/personnel.php add …` (or a one-off SQL load followed by `rebuild-search`).
5. Build CSS (§13), deploy, ensure `storage/` is writable by the PHP user only.
6. Schedule `bin/prune-login-attempts.php` daily and a nightly `mysqldump`.

---

## 16. Implementation roadmap

Sizes: **S** ≈ under a day, **M** ≈ 1–2 days, **L** ≈ 2–3 days (single developer, rough).

| # | Milestone | Size | Contents | Done when |
|---|---|---|---|---|
| M0 | **Skeleton + RTL base** | S | Repo layout, autoloader, config/.env, router, request/response/view, error handler, layout (RTL, Vazirmatn, `lang/fa.php`, `t()`, `num()`), Tailwind build | A Persian hello page renders RTL through the router with the font loaded and CSP headers present |
| M1 | **Database & CLI** | S | `schema.sql`, `seed.sql`, `Database`, `create-user.php`, `personnel.php`, `TextNormalizer` | Fresh DB builds; one open cycle per division exists; admins and personnel can be created; `name_search` is filled |
| M2 | **Auth, security & authorization** | M | Sessions, CSRF, `RequireAuth` (per-request user load), `SessionTimeout`, login/logout, throttling, security headers, `AccessPolicy` | Logged-out access redirects; 5 bad logins are throttled; session ID changes on login; a deactivated user is cut off on the next request |
| M3 | **Jalali & day rules** *(parallel with M2)* | M | `JalaliDate` (PHP), `jalali.js`, RTL `datepicker.js`, weekday names, `isWeekendDay` | Round trips match across leap years (1403, 1408) and year boundaries; `1405/07/31` and `1404/12/30` are rejected; Persian weekday names match known dates (3 Oct 2026 = Saturday) |
| M4 | **Submit Overtime** | L | Page, DTO validation, `OvertimeService::submitBatch`, `CycleService`, JS (search, division filter, row rules, day-rule check, button state, counters), PRG flash, double-submit guard | §5.1 walk-through behaves exactly as listed per division; Weekdays on Thu/Fri and Weekend on Sat–Wed are blocked in the UI **and** by the server; other divisions' rows are locked and a forged POST gets 403; concurrent submits cannot double-book a person |
| M5 | **Reports, delete & CSV** | L | `ReportFilter`, `ReportService`, table, pagination, totals, delete dialog + `deleteEntry` + audit log, CSV export | Every filter works alone and in any combination with no date limit; delete follows §5.5; CSV equals the on-screen filtered set and opens correctly in Excel with Persian text |
| M6 | **Hardening & release** | S | Run the §8.7 checklist, production `php.ini`, Nginx config, README (incl. Excel notes), backups | Checklist complete; a fresh install on a clean server follows the README without surprises |

**Manual acceptance checks** (no automated tests in MVP): run the §5.1 walk-through in two divisions and confirm they do not affect each other; try submitting Weekdays on a Friday and Weekend on a Saturday (both blocked), and Out of quota on both (allowed); enter 8.25 hours (blocked) and 8 (allowed); leave the description empty; as a Networking admin, try to POST a Hardware person's id (403) and delete a Hardware entry id (403); delete the last submission of a closed cycle while the next cycle is empty and confirm the cycle re-opens; deactivate the last remaining person of a cycle and confirm the cycle closes on the next page load; submit the same form twice quickly; tick people, filter them out of view, submit, and confirm they are included; a description starting with `=1+1` is exported with a leading `'`; open the CSV in Excel.

---

## 17. Out of scope / next steps

| Item | Notes |
|---|---|
| Personnel & user management UI | CRUD screens; today it is CLI-only (§11) |
| Super-admin / read-only-only role | Add `role` to `users` and a `RequireRole` middleware; `division_id` could become nullable for global roles |
| Admins with several divisions | Replace `users.division_id` with a `user_divisions` pivot; submit would group the batch by division and lock each division's open cycle in ascending id order |
| Editing entries | Delete + resubmit for now; editing needs rules for changing type/date/cycle |
| Public-holiday calendar | A `holidays` table feeding the day rules (today: enter holidays as *Out of quota*) |
| Soft delete / undelete | Needs a rethink of the `(cycle_id, personnel_id)` unique key |
| Audit log viewer | Rows are recorded; no screen yet |
| Password reset, 2FA | Needs email or TOTP; out of scope for an internal MVP |
| Automated tests | Services and `JalaliDate` are isolated from HTTP and ready for unit tests |
| Composer + PSR-4 | Swap the hand-written autoloader if packages are ever introduced |

---

## 18. Remaining questions

These do not block the start of work — each has a default in the plan and is a config value or a small change.

1. **Weekend days (A1):** confirm Thursday + Friday as weekend (so *Weekdays* = Saturday–Wednesday). If only Friday is the weekend, change `WEEKEND_DAYS="fri"`.
2. **One division per admin (A2):** is that right, or must some admins work in several divisions (see §17 for the cost)?
3. **Personnel maintenance (A3):** is the CLI acceptable for adding/moving/deactivating personnel, or do you want a small management page in the first release?
4. **Delete semantics (§5.5):** confirm that deleting the last entry of a just-closed cycle should **re-open** that cycle, and that deleting from older closed cycles only removes the row.
5. **Digits (A5):** Persian digits on screen (default) — or Latin digits?
6. **Personnel IDs:** can they start with `0`? (Affects whether the CSV uses the `="0123"` trick for Excel.)
7. **Hours:** is a 0.25 h step right, and should the cap apply per entry (as assumed) rather than per person per day?
