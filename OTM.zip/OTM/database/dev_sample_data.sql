-- ─────────────────────────────────────────────────────────────────────────
-- DEV SAMPLE DATA — local development only. DO NOT run in production.
-- Creates fake personnel and one dev admin per division.
--
-- Dev admins (all divisions):
--   username: admin1 (پشتیبانی سخت‌افزار)
--   username: admin2 (شبکه و زیرساخت)
--   username: admin3 (پایگاه داده و امنیت اطلاعات)
--   password for all three: Dev-Password-1405
-- ─────────────────────────────────────────────────────────────────────────
SET NAMES utf8mb4;

-- Dev admins. Hash = Argon2id of 'Dev-Password-1405' (OWASP profile m=19456,t=2,p=1).
INSERT INTO users (username, password_hash, display_name, division_id) VALUES
  ('admin1', '$argon2id$v=19$m=19456,t=2,p=1$T0kjGMkCa/C0RwvaBk9D6g$N0Wlqcw4+9Z4/py34d1WAZ7aBTV/iTgj2j2/+Ex25rc', 'مدیر پشتیبانی سخت‌افزار', 1),
  ('admin2', '$argon2id$v=19$m=19456,t=2,p=1$T0kjGMkCa/C0RwvaBk9D6g$N0Wlqcw4+9Z4/py34d1WAZ7aBTV/iTgj2j2/+Ex25rc', 'مدیر شبکه و زیرساخت', 2),
  ('admin3', '$argon2id$v=19$m=19456,t=2,p=1$T0kjGMkCa/C0RwvaBk9D6g$N0Wlqcw4+9Z4/py34d1WAZ7aBTV/iTgj2j2/+Ex25rc', 'مدیر پایگاه داده و امنیت', 3);

-- Fake personnel. name_search is the normalised copy (§7.5): ZWNJ → space,
-- Arabic ي/ك → ی/ک, Latin digits, lower-cased.
INSERT INTO personnel (personnel_code, full_name, name_search, division_id) VALUES
  ('20045', 'رضا مرادی', 'رضا مرادی', 1),
  ('20078', 'مریم حسینی', 'مریم حسینی', 1),
  ('20112', 'حمید کاظمی', 'حمید کاظمی', 1),
  ('10234', 'علی رضایی', 'علی رضایی', 2),
  ('10311', 'سارا احمدی', 'سارا احمدی', 2),
  ('10452', 'محمد کریمی', 'محمد کریمی', 2),
  ('30021', 'نگار موسوی', 'نگار موسوی', 3),
  ('30056', 'بهرام صادقی', 'بهرام صادقی', 3),
  ('30109', 'لیلا نجفی', 'لیلا نجفی', 3);
