SET NAMES utf8mb4;

-- ── Reference data ────────────────────────────────────────────────────────
CREATE TABLE divisions (
  id    TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name  VARCHAR(100)     NOT NULL,                  -- Persian display name
  PRIMARY KEY (id),
  UNIQUE KEY uq_divisions_name (name)
) ENGINE=InnoDB;

CREATE TABLE overtime_types (
  id          TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  code        VARCHAR(30)      NOT NULL,            -- stable identifier used in code
  name        VARCHAR(60)      NOT NULL,            -- Persian display name
  uses_cycle  TINYINT(1)       NOT NULL DEFAULT 0,
  day_rule    ENUM('workday','weekend','any') NOT NULL DEFAULT 'any',
  sort_order  TINYINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uq_overtime_types_code (code)
) ENGINE=InnoDB;

-- ── Authentication ────────────────────────────────────────────────────────
CREATE TABLE users (
  id             INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  username       VARCHAR(64)      NOT NULL,
  password_hash  VARCHAR(255)     NOT NULL,
  display_name   VARCHAR(120)     NOT NULL,
  division_id    TINYINT UNSIGNED NOT NULL,         -- the division this admin manages
  is_active      TINYINT(1)       NOT NULL DEFAULT 1,
  last_login_at  DATETIME         NULL,
  created_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username),
  CONSTRAINT fk_users_division FOREIGN KEY (division_id) REFERENCES divisions (id)
) ENGINE=InnoDB;

CREATE TABLE login_attempts (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  username        VARCHAR(64)     NOT NULL,         -- as typed, lower-cased, truncated
  ip_address      VARBINARY(16)   NOT NULL,         -- INET6_ATON(); fits IPv4 and IPv6
  was_successful  TINYINT(1)      NOT NULL,
  attempted_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_attempts_user_ip_time (username, ip_address, attempted_at),
  KEY idx_attempts_ip_time (ip_address, attempted_at)
) ENGINE=InnoDB;

-- ── Personnel ─────────────────────────────────────────────────────────────
CREATE TABLE personnel (
  id              INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  personnel_code  VARCHAR(32)      NOT NULL,        -- business "Personnel ID", Latin digits/letters (may start with 0)
  full_name       VARCHAR(120)     NOT NULL,        -- as displayed (Persian)
  name_search     VARCHAR(160)     NOT NULL,        -- normalised copy used for searching (see §7.5)
  division_id     TINYINT UNSIGNED NOT NULL,
  is_active       TINYINT(1)       NOT NULL DEFAULT 1,
  created_at      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_personnel_code (personnel_code),
  KEY idx_personnel_division_active (division_id, is_active),
  CONSTRAINT fk_personnel_division FOREIGN KEY (division_id) REFERENCES divisions (id)
) ENGINE=InnoDB;

-- ── Cycles (per division) ─────────────────────────────────────────────────
CREATE TABLE cycles (
  id            INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  division_id   TINYINT UNSIGNED NOT NULL,
  cycle_number  INT UNSIGNED     NOT NULL,          -- 1, 2, 3 … within the division (shown in the UI)
  started_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  closed_at     DATETIME         NULL,
  -- 1 while open, NULL once closed. UNIQUE (division_id, open_marker) → at most ONE open cycle per division.
  open_marker   TINYINT(1) GENERATED ALWAYS AS (IF(closed_at IS NULL, 1, NULL)) STORED,
  PRIMARY KEY (id),
  UNIQUE KEY uq_cycles_division_number (division_id, cycle_number),
  UNIQUE KEY uq_cycles_one_open_per_division (division_id, open_marker),
  CONSTRAINT fk_cycles_division FOREIGN KEY (division_id) REFERENCES divisions (id)
) ENGINE=InnoDB;

-- ── Overtime entries ──────────────────────────────────────────────────────
CREATE TABLE overtime_entries (
  id                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  personnel_id      INT UNSIGNED     NOT NULL,
  division_id       TINYINT UNSIGNED NOT NULL,      -- snapshot; equals the cycle's division for weekday entries
  overtime_type_id  TINYINT UNSIGNED NOT NULL,
  overtime_date     DATE             NOT NULL,      -- Gregorian; shown as Solar Hijri
  hours             DECIMAL(4,2)     NOT NULL,
  description       VARCHAR(255)     NULL,          -- optional
  cycle_id          INT UNSIGNED     NULL,          -- only for types with uses_cycle = 1
  created_by        INT UNSIGNED     NOT NULL,
  created_at        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  -- One weekday overtime per person per cycle. NULL cycle_id rows never collide in MySQL.
  UNIQUE KEY uq_entries_cycle_personnel (cycle_id, personnel_id),
  KEY idx_entries_date (overtime_date),
  KEY idx_entries_personnel_date (personnel_id, overtime_date),
  -- Hard sanity bound only; the business cap (default 8 h) is configurable in the app.
  CONSTRAINT chk_entries_hours CHECK (hours > 0 AND hours <= 24),
  CONSTRAINT fk_entries_personnel FOREIGN KEY (personnel_id)     REFERENCES personnel (id),
  CONSTRAINT fk_entries_division  FOREIGN KEY (division_id)      REFERENCES divisions (id),
  CONSTRAINT fk_entries_type      FOREIGN KEY (overtime_type_id) REFERENCES overtime_types (id),
  CONSTRAINT fk_entries_cycle     FOREIGN KEY (cycle_id)         REFERENCES cycles (id),
  CONSTRAINT fk_entries_user      FOREIGN KEY (created_by)       REFERENCES users (id)
) ENGINE=InnoDB;

-- ── Audit (deletions) ─────────────────────────────────────────────────────
CREATE TABLE audit_log (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     INT UNSIGNED    NOT NULL,
  action      VARCHAR(40)     NOT NULL,             -- 'overtime.delete'
  entity_id   BIGINT UNSIGNED NULL,
  details     JSON            NOT NULL,             -- full snapshot of the deleted row (+ personnel code/name, Jalali date, type)
  ip_address  VARBINARY(16)   NULL,
  created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_audit_created (created_at),
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB;
