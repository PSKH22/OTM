SET NAMES utf8mb4;

-- ── Divisions (§6.3) ──────────────────────────────────────────────────────
INSERT INTO divisions (name) VALUES
  ('پشتیبانی سخت‌افزار'),                 -- Hardware Support
  ('شبکه و زیرساخت'),                      -- Networking and Infrastructure
  ('پایگاه داده و امنیت اطلاعات');        -- Database and Information Security

-- ── Overtime types (§6.3) ─────────────────────────────────────────────────
INSERT INTO overtime_types (code, name, uses_cycle, day_rule, sort_order) VALUES
  ('weekdays',     'روزهای کاری',  1, 'workday', 1),
  ('weekend',      'آخر هفته',     0, 'weekend', 2),
  ('out_of_quota', 'خارج از سهمیه', 0, 'any',     3);

-- Cycle 1 (open) for every division. Any future division must get one too.
INSERT INTO cycles (division_id, cycle_number) SELECT id, 1 FROM divisions;
