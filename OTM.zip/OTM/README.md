# مدیریت اضافه‌کاری — Overtime Management System

A small internal web app for division admins to record personnel overtime and report on it.
Persian UI, right-to-left, Solar Hijri dates. No framework, no Composer, no npm.

- **Stack:** PHP 8.5 · MySQL 9.7 LTS (or 8.4 LTS) · Tailwind CSS 4 (standalone CLI) · vanilla JS (native ES modules)
- **Font:** Vazirmatn (SIL OFL), self-hosted in `public/assets/fonts/`

---

## 1. Requirements

- PHP 8.5-FPM with extensions: `pdo_mysql`, `intl`, `mbstring`, Argon2 (`PASSWORD_ARGON2ID`)
- MySQL 9.7 LTS or 8.4 LTS (InnoDB, `utf8mb4`)
- Nginx + PHP-FPM (or Apache) with **HTTPS** in production
- Tailwind CSS 4 **standalone CLI** binary (build time only — not needed on the server)

## 2. First install

1. Create the database and a dedicated account, then load schema and seed:

   ```sql
   CREATE DATABASE overtime_mgmt CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
   CREATE USER 'overtime_app'@'localhost' IDENTIFIED BY '…';
   GRANT SELECT, INSERT, UPDATE, DELETE ON overtime_mgmt.* TO 'overtime_app'@'localhost';
   ```

   ```bash
   mysql overtime_mgmt < database/schema.sql
   mysql overtime_mgmt < database/seed.sql
   # optional, local dev only: mysql overtime_mgmt < database/dev_sample_data.sql
   ```

2. `cp .env.example .env` and fill in the values. `.env` lives outside the web root,
   mode `0600`, and is git-ignored.

3. Create admins (one or more per division):

   ```bash
   php bin/create-user.php ali.karimi --division="شبکه و زیرساخت" --name="علی کریمی"
   ```

4. Add personnel (or a one-off SQL load followed by `rebuild-search`):

   ```bash
   php bin/personnel.php add --code=10234 --name="علی رضایی" --division=2
   ```

5. Build the CSS (§3 below) and deploy; the web server exposes **only `public/`**.

6. Make `storage/` writable by the PHP user only (`chmod 700 storage storage/logs storage/sessions`).

7. Schedule a daily prune and a nightly backup:

   ```cron
   0 3 * * *  php /var/www/overtime-mgmt/bin/prune-login-attempts.php
   30 3 * * * mysqldump overtime_mgmt | gzip > /backups/overtime-$(date +\%F).sql.gz
   ```

### Local development

```bash
cp .env.example .env   # then set COOKIE_SECURE="0" and SESSION_NAME="ot_sid"
mysql overtime_mgmt < database/schema.sql && mysql overtime_mgmt < database/seed.sql
mysql overtime_mgmt < database/dev_sample_data.sql   # admins: admin1/2/3, password: Dev-Password-1405
php -S localhost:8000 -t public public/index.php
```

## 3. Tailwind build

Entry file: `resources/css/input.css`. Output: `public/assets/css/app.css` (generated — never hand-edit, git-ignored).

```bash
# Dev (watch):
./tailwindcss -i resources/css/input.css -o public/assets/css/app.css --watch

# Release:
./tailwindcss -i resources/css/input.css -o public/assets/css/app.css --minify
```

Do **not** use the Tailwind Play CDN — it conflicts with the strict CSP.

## 4. CLI tools

| Command | Behaviour |
|---|---|
| `php bin/create-user.php <username> --division=<id\|name> [--name="…"]` | Hidden password prompt (twice), ≥12 chars, Argon2id hash. `--reset-password` updates an existing user. |
| `php bin/personnel.php add --code=… --name="…" --division=…` | Validates/normalises code and name, fills `name_search`. |
| `php bin/personnel.php deactivate <code>` / `activate <code>` | Toggle `is_active`; cycle effects are lazy. |
| `php bin/personnel.php move <code> --division=…` | Transfer; old entries keep their division snapshot. |
| `php bin/personnel.php list [--division=…] [--all]` | List personnel. |
| `php bin/personnel.php rebuild-search` | Recompute `name_search` after any manual SQL load. |
| `php bin/prune-login-attempts.php` | Delete `login_attempts` older than 7 days (cron). |

## 5. Excel notes (CSV export)

- The CSV is UTF-8 **with BOM**, so Persian text displays correctly in Excel.
- Personnel codes that start with `0` are exported as `="0123"` so Excel keeps the leading zero
  (codes are validated to `^[0-9A-Za-z]+$`, so this is injection-safe).
- Text cells starting with `=`, `+`, `-`, `@`, tab or CR are prefixed with `'` (formula-injection guard).
- Excel installs that use `;` as the list separator may need **Data → From Text/CSV** to import.
- Dates are Solar Hijri `YYYY/MM/DD` and hours use dot decimals — always Latin digits in the CSV.

## 6. Security checklist (§8.7)

- PDO prepared statements only (`ATTR_EMULATE_PREPARES => false`); dynamic SQL from whitelists
- All output escaped via `e()`; JS uses `textContent`; strict CSP with no inline script/style
- CSRF token on every POST (per-session, `hash_equals`); one-time `form_nonce` on the submit form
- Authorization re-checked on the server for every write; entry division is never read from the form
- Session: `HttpOnly` + `Secure` + `SameSite=Lax`, strict mode, regenerate id at login, 30 min idle / 8 h absolute timeout
- Argon2id password hashing, login throttling (5 per user+IP / 20 per IP per 15 min), generic errors, timing equalisation
- `frame-ancestors 'none'` + `X-Frame-Options: DENY` (clickjacking)
- Redirects restricted to local paths (post-delete must start with `/reports`)
- `display_errors=0` in production; details only in `storage/logs/app.log`
- `.env` outside web root, git-ignored

Production `php.ini`: `display_errors=0`, `log_errors=1`, `expose_php=0`.

## 7. Configuration reference (`.env`)

| Key | Default | Meaning |
|---|---|---|
| `APP_ENV` / `APP_DEBUG` | `production` / `0` | Environment; debug shows exception details (never in production) |
| `APP_URL` | — | External URL (reference) |
| `APP_TIMEZONE` | `Asia/Tehran` | "Today", default date, ±366-day window |
| `APP_LOCALE` | `fa` | UI locale |
| `UI_PERSIAN_DIGITS` | `1` | Persian digits on screen (CSV/DB always Latin) |
| `DB_HOST` / `DB_PORT` / `DB_NAME` / `DB_USER` / `DB_PASS` | — | MySQL connection |
| `SESSION_NAME` | `__Host-ot_sid` | Cookie name (plain name on local HTTP dev) |
| `COOKIE_SECURE` | `1` | `Secure` cookie flag (set `0` for local HTTP dev) |
| `SESSION_IDLE_MINUTES` | `30` | Idle timeout |
| `SESSION_ABSOLUTE_HOURS` | `8` | Absolute session cap |
| `LOGIN_WINDOW_MINUTES` | `15` | Throttle window |
| `LOGIN_MAX_FAILURES_PER_USER_IP` | `5` | Throttle: failures per (username, IP) |
| `LOGIN_MAX_FAILURES_PER_IP` | `20` | Throttle: failures per IP |
| `OVERTIME_MAX_HOURS` | `8` | Hours cap per entry |
| `OVERTIME_HOURS_STEP` | `0.25` | Minimum hours step |
| `OVERTIME_DATE_WINDOW_DAYS` | `366` | Submission window (reports have no limit) |
| `WEEKEND_DAYS` | `thu,fri` | Weekend for the day rules (`mon`..`sun`) |
| `REPORT_PAGE_SIZE` | `50` | Report rows per page |

## 8. Project layout

See `plan.md` §11. In short: `public/` is the only web-exposed directory;
`src/` holds the `App\` code (Core / Http / Services / Repositories / Input / Support);
`templates/` the PHP views; `lang/fa.php` all UI strings; `database/` schema + seeds;
`bin/` the CLI tools; `deploy/nginx.conf.example` the web server sketch.
