# Overtime Management System — Implementation Task Breakdown

> **Reading guide:** Each task is self-contained. Give the LLM the task description **plus** the relevant spec sections (§ references are listed per task). Dependencies tell you what must already exist. Acceptance criteria let you verify the output before moving on.

---

## Phase 1 — Frontend Foundation (Templates, CSS, Fonts)

---

### Task 1 · Project Skeleton & Tailwind CSS Build

**Files to create**
```
resources/css/input.css
.gitignore
```

**Spec sections:** §3.1, §3.2, §13, §7.1

**Instructions**
1. Create `resources/css/input.css` as the Tailwind 4 entry file.
   - `@import "tailwindcss";`
   - `@source` directives pointing at `../../templates` and `../../public/assets/js`.
   - `@font-face` for **Vazirmatn** variable `woff2` at `/assets/fonts/Vazirmatn-Variable.woff2`, `font-weight: 100 900`, `font-display: swap`.
   - `@theme` block setting `--font-sans: "Vazirmatn", Tahoma, system-ui, sans-serif`.
2. Create `.gitignore` covering: `.env`, `storage/logs/*`, `storage/sessions/*`, `public/assets/css/app.css`, `node_modules/`, `tailwindcss` binary.
3. Create empty placeholder directories (as `.gitkeep` files):
   - `public/assets/fonts/`
   - `public/assets/js/lib/`
   - `public/assets/js/pages/`
   - `templates/partials/`
   - `templates/errors/`
   - `lang/`
   - `config/`
   - `database/migrations/`
   - `bin/`
   - `src/` (with sub-dirs `Core/`, `Http/Controllers/`, `Http/Middleware/`, `Services/`, `Repositories/`, `Input/`, `Support/`)
   - `storage/logs/`
   - `storage/sessions/`

**Acceptance criteria**
- `./tailwindcss -i resources/css/input.css -o public/assets/css/app.css` produces a valid CSS file.
- No CDN or Node/npm references anywhere.
- `.gitignore` prevents `.env` and generated CSS from being committed.

---

### Task 2 · Persian Language File (`lang/fa.php`)

**Files to create**
```
lang/fa.php
```

**Spec sections:** §7.1, §7.6

**Instructions**
1. Create `lang/fa.php` returning an associative array of **all** keys listed in the §7.6 glossary table.
2. Every key from the table must be present with its exact Persian value.
3. Add additional keys needed by templates that are implied but not in the glossary:
   - Flash messages: `flash_submit_success` (`اضافه‌کاری برای {count} نفر ثبت شد — {type}، {date}، {hours} ساعت`), `flash_cycle_closed` (`دور {n} تکمیل شد؛ دور {next} آغاز شد.`), `flash_delete_success` (`رکورد حذف شد.`), `flash_cycle_reopened` (`دور {n} دوباره باز شد.`), `flash_logout`.
   - Validation: `err_required`, `err_invalid_date`, `err_date_window`, `err_invalid_hours`, `err_hours_step`, `err_personnel_count`, `err_unknown_personnel`, `err_inactive_personnel`, `err_already_used_cycle`, `err_batch_rejected`.
   - Auth: `err_csrf` (`نشست شما منقضی شده است؛ صفحه را دوباره بارگیری کنید.`), `err_forbidden`.
   - Pagination: `pagination_prev`, `pagination_next`, `pagination_info` (`صفحه {current} از {total}`).
   - Report summary: `report_summary` (`{count} رکورد · {hours} ساعت`).
   - Delete dialog: `confirm_delete_title`, `confirm_delete_body`, `btn_delete_confirm`, `btn_delete_cancel`.
   - Status labels: `status_locked` (`🔒 فقط مشاهده`).
4. Use `{placeholder}` syntax for interpolation. The `t()` helper (built later) will do `str_replace`.

**Acceptance criteria**
- File is valid PHP returning `array<string, string>`.
- Every key in §7.6 is present verbatim.
- No English text in values (except placeholders).

---

### Task 3 · Base Layout Template (`templates/layout.php`)

**Files to create**
```
templates/layout.php
templates/partials/flash.php
```

**Spec sections:** §7.1, §8.7, §9 (common layout), §13

**Dependencies:** Task 1 (CSS file path), Task 2 (language keys)

**Instructions**
1. `layout.php` receives `$title`, `$content` (pre-rendered HTML string), and optional `$activeNav`.
2. `<html lang="fa" dir="rtl">`.
3. `<head>`:
   - `<meta charset="utf-8">`, viewport, `<title>` using `$title` + app name.
   - `<link rel="stylesheet" href="<?= asset('css/app.css') ?>">`.
   - No inline `<style>` or `<script>` (strict CSP).
4. `<body>`:
   - **Top bar** (hidden on login page via `$showNav` flag):
     - App name (`t('app_name')`).
     - Nav links: `t('nav_submit')` → `/overtime/new`, `t('nav_reports')` → `/reports`. Active link highlighted.
     - Right side: current user display name + division name, Logout button (a `<form method="post" action="/logout">` with `csrf_field()`).
   - **Flash area** under nav: `<?php include partials/flash.php ?>` with `role="status"` / `role="alert"`.
   - `$content`.
5. All output escaped via `e()` except `$content` (already rendered).
6. Use **Tailwind logical utilities only** (`ms-*`, `me-*`, `ps-*`, `pe-*`, `start-*`, `end-*`, `text-start`, `border-s`, `rounded-s`). No physical `ml-/mr-/pl-/pr-/left-/right-`.
7. `flash.php` partial: renders session flash messages (success → green, error → red) and clears them.

**Acceptance criteria**
- Valid RTL HTML5.
- No physical-direction Tailwind classes.
- Logout is a POST form with CSRF hidden field placeholder.
- Flash area uses ARIA live regions.

---

### Task 4 · Login Page Template (`templates/login.php`)

**Files to create**
```
templates/login.php
```

**Spec sections:** §9.1, §7.1, §8.1

**Dependencies:** Task 3

**Instructions**
1. Standalone page (no nav bar). Centered card layout.
2. Fields:
   - Username: `<input type="text" name="username" autocomplete="username" required>`, label `t('username')`.
   - Password: `<input type="password" name="password" autocomplete="current-password" required>`, label `t('password')`.
   - CSRF hidden field via `csrf_field()`.
3. Submit button: `t('login')`.
4. Error display: single generic message area above the form (shows `t('err_login')` or `t('err_throttle')`).
5. Old input: `value="<?= e(old('username')) ?>"` on username.
6. `dir="rtl"` inherited from layout. Input text alignment via `text-start`.
7. `method="post" action="/login"`.

**Acceptance criteria**
- No nav bar rendered.
- CSRF field present.
- Generic error area (never reveals which credential was wrong).
- Accessible labels on both inputs.

---

### Task 5 · Submit Overtime Page Template (`templates/overtime/new.php`)

**Files to create**
```
templates/overtime/new.php
```

**Spec sections:** §9.2, §7.1, §7.4, §7.6, §5.1, §5.2

**Dependencies:** Task 3, Task 2

**Instructions**
1. Receives from controller: `$types`, `$divisions`, `$userDivisionId`, `$personnel` (array with `id`, `personnel_code`, `full_name`, `division_id`, `used_in_open_cycle`, `division_name`), `$cycleSummary` (array per division), `$errors`, `$old`, `$weekendDays` (for JS data attribute).
2. **Form row** (wraps to single column on narrow screens):
   - **Type** `<select name="type_id">`: options from `$types`, each with `data-uses-cycle` and `data-day-rule` attributes. Selected from `$old`.
   - **Division filter** `<select id="division-filter">` (no `name` attribute — display only per C2). Options: "همه واحدها" + each division. Defaults to `$userDivisionId`.
   - **Date**: `<input type="text" name="date" data-jalali-datepicker dir="ltr" autocomplete="off" inputmode="numeric" data-min="…" data-max="…">` + `<span id="weekday-label">` for weekday name + `<div id="day-rule-msg" aria-live="polite">` for mismatch message.
   - **Hours**: `<input type="text" name="hours" dir="ltr" inputmode="decimal" class="text-end">`, label `t('hours')`.
   - **Description**: `<input type="text" name="description" maxlength="255">`, label `t('description')` + "(اختیاری)".
   - Hidden: `csrf_field()` + `<input type="hidden" name="form_nonce" value="…">`.
3. **Cycle summary strip**: one chip per division: `{name}: دور {cycle_number} · {done}/{total}`. Own division chip highlighted.
4. **Search box**: `<input type="text" id="personnel-search" placeholder="<?= t('search_placeholder') ?>">`.
5. **Selection counter**: `<span id="selected-count" aria-live="polite">`.
6. **Personnel table** (horizontally scrollable container):
   - Columns: checkbox, Name, Personnel ID, Division, Status.
   - Each row `<tr>` carries: `data-personnel-id`, `data-division-id`, `data-own` (1/0), `data-used` (1/0).
   - Checkbox: `name="personnel_ids[]" value="{id}"`. Disabled + `title` when `!own` or (`uses_cycle` and `used`).
   - Status cell text per §9.2 rules.
   - Header checkbox: "select all visible, enabled rows" with indeterminate support.
   - Personnel code and date cells get `dir="ltr"`.
7. **Submit button**: `t('submit')`, initially disabled state managed by JS.
8. `form method="post" action="/overtime"`.
9. `<script type="application/json" id="i18n">` block with JS-needed strings (day-rule messages, selected_count template, status labels, weekend days array).
10. `<script type="module" src="<?= asset('js/pages/submit-overtime.js') ?>">`.
11. All Tailwind classes logical only.

**Acceptance criteria**
- Division dropdown has **no** `name` attribute.
- Every row has all four `data-` attributes.
- JSON i18n block is present and valid JSON.
- No inline JS event handlers.

---

### Task 6 · Reports Page Template + Delete Dialog (`templates/reports/index.php`, `templates/partials/delete_dialog.php`)

**Files to create**
```
templates/reports/index.php
templates/partials/delete_dialog.php
templates/partials/pagination.php
```

**Spec sections:** §9.3, §9.4, §7.1

**Dependencies:** Task 3, Task 2

**Instructions**
1. **Filter form** (`method="get" action="/reports"`):
   - From date: `<input type="text" name="from" data-jalali-datepicker dir="ltr" inputmode="numeric">`.
   - To date: same with `name="to"`.
   - Division `<select name="division_id">`: "همه واحدها" + divisions.
   - Type `<select name="type_id">`: "همه انواع" + types.
   - Search: `<input type="text" name="q" maxlength="100">`.
   - Apply button (`type="submit"`), Reset link (`href="/reports"`), **Export CSV** button (`type="submit" formaction="/reports/export"`).
   - Per-field error display.
2. **Summary line**: `t('report_summary')` with count + total hours.
3. **Table** (scrollable):
   - Columns: Date, Personnel ID, Name, Division, Type, Hours, Cycle, Description, Actions.
   - Date and Personnel ID cells: `dir="ltr"`.
   - Cycle: number or `—`.
   - Description: truncated with `title` attribute for full text.
   - Actions: Delete button **only** when `$row['division_id'] === $userDivisionId`. Button carries `data-entry-id`, `data-name`, `data-date`, `data-type`, `data-hours` for the dialog.
4. **Pagination partial**: Prev/Next links + "Page X of Y". Links preserve current query string.
5. **Delete dialog** (`delete_dialog.php`):
   - Native `<dialog id="delete-dialog">`.
   - Summary area filled by JS.
   - Confirmation text: `t('confirm_delete')`.
   - `<form method="post" action="/overtime/delete">` with hidden `csrf_token`, `entry_id`, `back`.
   - Delete (submit) + Cancel buttons.
6. `<script type="application/json" id="i18n">` with delete-related strings.
7. `<script type="module" src="<?= asset('js/pages/reports.js') ?>">`.

**Acceptance criteria**
- Export button uses `formaction="/reports/export"` (same form, no JS needed).
- Delete button absent for other-division rows.
- `<dialog>` element used (not a div overlay).
- All filters preserved in pagination links.

---

### Task 7 · Error Page Templates

**Files to create**
```
templates/errors/403.php
templates/errors/404.php
templates/errors/500.php
```

**Spec sections:** §14, §7.1

**Dependencies:** Task 3

**Instructions**
1. Each extends the layout (minimal nav) or is a standalone minimal page.
2. **403**: Persian "دسترسی مجاز نیست" message. No technical details.
3. **404**: Persian "صفحه پیدا نشد" + link back to `/overtime/new`.
4. **500**: Persian generic "خطای داخلی سرور" + "لطفاً بعداً دوباره تلاش کنید." **No** stack trace, file names, or exception details.
5. All RTL, Vazirmatn font, centered card.

**Acceptance criteria**
- No sensitive information on any error page.
- All text in Persian via `t()` or hardcoded Persian strings.

---

## Phase 2 — Frontend JavaScript

---

### Task 8 · `digits.js` + `normalize.js`

**Files to create**
```
public/assets/js/lib/digits.js
public/assets/js/lib/normalize.js
```

**Spec sections:** §7.5, §3.2, §7.1

**Instructions**

**`digits.js`** (ES module):
- `toLatinDigits(str)`: replace Persian `۰-۹` (U+06F0–F9) and Arabic-Indic `٠-٩` (U+0660–69) with `0-9`.
- `toPersianDigits(str)`: reverse mapping.
- `parseDecimal(str)`: normalise digits to Latin, replace `٫` (U+066B) and `,` with `.`, return trimmed string.

**`normalize.js`** (ES module, must be identical rules to PHP `TextNormalizer`):
- `normalizeText(str)`:
  1. Arabic `ي` (U+064A) → `ی` (U+06CC).
  2. Arabic `ك` (U+0643) → `ک` (U+06A9).
  3. Persian/Arabic-Indic digits → Latin (import from `digits.js`).
  4. Remove ZWNJ (U+200C), tatweel (U+0640), Arabic diacritics (U+064B–U+065F).
  5. Collapse whitespace, trim, lower-case Latin letters.

**Acceptance criteria**
- Both are ES modules with named exports.
- No dependencies on external libraries.
- `normalizeText('علی‌رضا')` === `normalizeText('علي رضا')` (ZWNJ vs space, ي→ی).

---

### Task 9 · `jalali.js` — Solar Hijri Math (Browser)

**Files to create**
```
public/assets/js/lib/jalali.js
```

**Spec sections:** §7.3, §3.2

**Instructions**
1. ES module, no external dependencies.
2. **Gregorian → Jalali**: use `Intl.DateTimeFormat('en-u-ca-persian-nu-latn', {year:'numeric',month:'numeric',day:'numeric',timeZone:'UTC'})` with `formatToParts`. Extract year/month/day, ignore era.
3. **Jalali → Gregorian**: anchor on 1 Farvardin (probe March 19–22 of `jy + 621` using the above function), then add day offsets. Month lengths: 1–6 = 31, 7–11 = 30, 12 = 29 (30 in leap). Leap detection: next Nowruz is 366 days away.
4. **Validation**: `isValidJalali(y, m, d)` — month 1-12, day within month length.
5. **Names**:
   - `monthNames()`: `Intl.DateTimeFormat('fa-IR-u-ca-persian', {month:'long'})` → فروردین … اسفند.
   - `weekdayName(gregorianDate)`: `{weekday:'long'}` → شنبه … جمعه.
   - `weekdayNarrow(gregorianDate)`: `{weekday:'narrow'}` for calendar header.
6. **Weekday number**: from converted Gregorian via `Date.UTC(...)` → `getUTCDay()`. Saturday = 6, Sunday = 0, …, Friday = 5. Also expose ISO weekday (1=Mon…7=Sun) for day-rule checks.
7. **Week starts on Saturday**.
8. Export: `toJalali(date)`, `toGregorian(jy, jm, jd)`, `isValidJalali`, `jalaliMonthLength(jy, jm)`, `monthName(jm)`, `weekdayName`, `isoWeekday(date)`, `today()`.

**Acceptance criteria**
- Round-trip: `toGregorian(...toJalali(date))` returns the same date.
- Leap year 1403: month 12 has 30 days. Non-leap 1404: month 12 has 29 days.
- `weekdayName(new Date('2026-10-03'))` returns `'شنبه'` (Saturday).
- No third-party imports.

---

### Task 10 · `datepicker.js` — In-House Jalali Date Picker

**Files to create**
```
public/assets/js/lib/datepicker.js
```

**Spec sections:** §7.4, §7.1, §13

**Dependencies:** Task 8 (digits), Task 9 (jalali)

**Instructions**
1. ES module. Targets any `<input data-jalali-datepicker>`.
2. **Popup calendar**:
   - RTL grid, 7 columns, **Saturday at the right edge**.
   - Header: month name + year, prev/next month buttons (arrows flip under RTL), year selector dropdown.
   - Day grid: numbers as buttons. Weekend columns tinted (Friday always; Thursday per config passed via `data-weekend-days` or the i18n JSON block).
   - "امروز" (Today) button.
   - Footer with selected date display.
3. **Interaction**:
   - Click/focus on input opens popup. Esc closes. Click outside closes.
   - Arrow keys move focused day. Enter/Space selects.
   - Selecting a day writes `YYYY/MM/DD` into the input (Persian digits if `data-persian-digits="1"`).
   - Emits native `change` event on the input.
   - Typing a date directly is also allowed.
4. **Optional** `data-min` / `data-max` (Jalali strings) to grey out / reject out-of-range dates.
5. **Accessibility**: `role="dialog"`, `aria-label` on day buttons, focus returns to input on close.
6. ~250 lines target. No framework, no npm.
7. Initialise automatically: `document.querySelectorAll('[data-jalali-datepicker]').forEach(init)`.

**Acceptance criteria**
- Popup renders RTL with Saturday at right.
- Friday column is visually distinct.
- Selecting 31 Esfand 1404 is rejected (non-leap).
- `change` event fires on selection.
- Focus management works (Esc → focus back to input).

---

### Task 11 · `submit-overtime.js` — Submit Page Behaviour

**Files to create**
```
public/assets/js/pages/submit-overtime.js
```

**Spec sections:** §9.2 (client behaviour table), §5.2, §7.5, §7.1

**Dependencies:** Task 8, Task 9, Task 10

**Instructions**
1. ES module. Imports from `../lib/normalize.js`, `../lib/jalali.js`, `../lib/digits.js`.
2. Read i18n strings from `<script type="application/json" id="i18n">`.
3. **Division filter**: hide/show `<tr>` by `data-division-id`. "همه واحدها" shows all. Combines with search.
4. **Search**: normalise both query and row text via `normalizeText`. Match on name OR personnel code. `۱۰۲۳۴` matches `10234`.
5. **Row state / disabling**:
   - Read the selected type's `data-uses-cycle` and `data-day-rule`.
   - Disable checkbox if `!data-own` OR (`uses_cycle` AND `data-used`).
   - Un-tick and mute disabled rows.
   - Status column text: `فقط مشاهده` for other divisions; `انجام‌شده در دور N` / `آزاد` for own when cycle applies; `—` otherwise.
   - Re-evaluate on every type `<select>` change.
6. **Header checkbox**: select all visible + enabled. Indeterminate state.
7. **Selection counter**: `N نفر انتخاب شده (M مخفی)` in the `aria-live` region.
8. **Weekday label**: on date change, convert Jalali → Gregorian → show Persian weekday name.
9. **Day-rule check**: on type or date change:
   - `workday` + weekend day → show `err_day_workday` with weekday name.
   - `weekend` + non-weekend → show `err_day_weekend`.
   - `any` → no check.
   - Weekend days read from i18n JSON.
10. **Submit button state**: disabled when any of: nothing selected, date empty/invalid/out-of-window, hours empty/invalid/over cap, type/date mismatch. Also disabled after click (prevent double-submit).
11. **Default date**: fill with today (Jalali) if empty on load.
12. No `innerHTML` with data. Use `textContent`.

**Acceptance criteria**
- Switching type to "Weekend" disables all weekday-used rows correctly.
- Searching `علي` finds `علی` (normalisation).
- Day-rule message appears/disappears reactively.
- Submit button is disabled until all conditions met.

---

### Task 12 · `reports.js` — Reports Page Behaviour

**Files to create**
```
public/assets/js/pages/reports.js
```

**Spec sections:** §9.3, §9.4

**Dependencies:** Task 10

**Instructions**
1. ES module.
2. Initialise Jalali date pickers on the From/To filter inputs (import `datepicker.js`).
3. **From/To pairing**: From's `data-max` = To's value; To's `data-min` = From's value. Update dynamically.
4. **Delete dialog**:
   - Click any `[data-entry-id]` delete button → open `<dialog id="delete-dialog">`.
   - Fill summary: name, date (Jalali), type, hours.
   - Set hidden `entry_id` value.
   - Set hidden `back` value to `window.location.href` (must start with `/reports`).
   - Cancel button closes dialog.
   - Confirm submits the form.
5. No inline handlers. Event delegation on the table body.

**Acceptance criteria**
- Dialog shows correct row data.
- Cancel closes without submitting.
- `back` field is populated with current URL.
- Date pickers enforce From ≤ To.

---

## Phase 3 — Backend Foundation

---

### Task 13 · `.env.example`, `Config.php`, `bootstrap.php`, `helpers.php`

**Files to create**
```
.env.example
src/Core/Config.php
src/bootstrap.php
src/helpers.php
```

**Spec sections:** §12, §3.2, §4.1, §4.2, §7.1, §14

**Instructions**

**`.env.example`**: replicate the full `.env` block from §12 with all keys and safe defaults. Comment each section.

**`Config.php`** (namespace `App\Core`):
- `load(string $envPath)`: use `parse_ini_file($path, false, INI_SCANNER_RAW)`. Fail fast if missing.
- Merge with `config/app.php` (which reads env values and provides typed accessors).
- Expose: `get(string $key, mixed $default = null)`.

**`config/app.php`**: return an array reading from env with defaults:
```php
'timezone' => 'Asia/Tehran',
'locale' => 'fa',
'persian_digits' => (bool) env('UI_PERSIAN_DIGITS', true),
'weekend_days' => array_map(fn($d) => strtolower(trim($d)), explode(',', env('WEEKEND_DAYS', 'thu,fri'))),
'overtime_max_hours' => 8,
'overtime_hours_step' => 0.25,
'overtime_date_window_days' => 366,
'report_page_size' => 50,
'session_idle_minutes' => 30,
'session_absolute_hours' => 8,
'login_window_minutes' => 15,
'login_max_user_ip' => 5,
'login_max_ip' => 20,
```

**`bootstrap.php`**:
1. Check required extensions: `pdo_mysql`, `intl`, `mbstring`, `PASSWORD_ARGON2ID` defined. Fail fast with clear message.
2. `spl_autoload_register` mapping `App\` → `src/` (PSR-4 style).
3. Require `helpers.php`.
4. Load config from `.env`.
5. `date_default_timezone_set(config('app.timezone'))`.
6. Custom error handler → log to `storage/logs/app.log`, show generic 500 in production.
7. `declare(strict_types=1)` at top of every file.

**`helpers.php`**:
- `e(string $s): string` → `htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')`.
- `t(string $key, array $replacements = []): string` → lookup in `lang/fa.php`, `str_replace` placeholders.
- `num(string|int|float $n): string` → if `persian_digits` config, `strtr` Latin→Persian digits; else return as-is.
- `url(string $path): string`.
- `asset(string $path): string` → append `?v=filemtime()`.
- `old(string $key, string $default = ''): string` → from flash old input.
- `csrf_field(): string` → `<input type="hidden" name="csrf_token" value="…">`.
- `flash(string $type, string $msg): void`.

**Acceptance criteria**
- `require 'src/bootstrap.php'` boots without errors when `.env` exists.
- Missing extension → clear error message naming the extension.
- `t('app_name')` returns `مدیریت اضافه‌کاری`.
- `num(1405)` returns `۱۴۰۵` when Persian digits enabled.

---

### Task 14 · Database Schema (`database/schema.sql`)

**Files to create**
```
database/schema.sql
```

**Spec sections:** §6.1, §6.2, §6.4

**Instructions**
1. Reproduce the **exact** schema from §6.2. All tables:
   - `divisions`, `overtime_types`, `users`, `login_attempts`, `personnel`, `cycles`, `overtime_entries`, `audit_log`.
2. Key details to preserve:
   - `cycles.open_marker` generated column: `TINYINT(1) GENERATED ALWAYS AS (IF(closed_at IS NULL, 1, NULL)) STORED`.
   - `UNIQUE KEY uq_cycles_one_open_per_division (division_id, open_marker)`.
   - `UNIQUE KEY uq_entries_cycle_personnel (cycle_id, personnel_id)`.
   - `CHECK (hours > 0 AND hours <= 24)` on `overtime_entries`.
   - All foreign keys.
   - `utf8mb4`, InnoDB everywhere.
   - Indexes as specified (`idx_personnel_division_active`, `idx_entries_date`, `idx_entries_personnel_date`, `idx_attempts_user_ip_time`, `idx_attempts_ip_time`, `idx_audit_created`).
3. `SET NAMES utf8mb4;` at top.

**Acceptance criteria**
- Schema applies cleanly on MySQL 8.4+ / 9.7.
- The generated column + unique key correctly prevents two open cycles per division.
- `overtime_entries.hours` CHECK constraint rejects 0 and >24.

---

### Task 15 · Seed Data + Dev Sample Data

**Files to create**
```
database/seed.sql
database/dev_sample_data.sql
```

**Spec sections:** §6.3

**Dependencies:** Task 14

**Instructions**

**`seed.sql`**:
- Insert 3 divisions (exact Persian names from §6.3).
- Insert 3 overtime types (exact codes, names, `uses_cycle`, `day_rule`, `sort_order` from §6.3).
- Insert cycle 1 (open) for every division via `INSERT … SELECT`.

**`dev_sample_data.sql`** (local dev only, clearly commented):
- 2–3 fake personnel per division with Persian names and codes.
- 1 dev admin per division with a known bcrypt/argon2 hash (comment the plaintext password).
- Must reference correct division IDs.

**Acceptance criteria**
- Running `schema.sql` then `seed.sql` produces a usable database.
- Every division has exactly one open cycle.
- Dev sample is clearly marked as non-production.

---

### Task 16 · Core Framework: `Router`, `Request`, `Response`, `View`

**Files to create**
```
src/Core/Router.php
src/Core/Request.php
src/Core/Response.php
src/Core/View.php
```

**Spec sections:** §4.1, §4.2, §4.3, §10

**Instructions**

**`Router.php`**:
- Array-based, exact path matching (no regex, no path parameters).
- `add(string $method, string $path, callable|array $handler, array $middleware = [])`.
- `dispatch(Request $request): Response`.
- Unknown route → 404. Wrong method → 405.
- Route table loaded from `config/routes.php`.

**`Request.php`**:
- Typed access to `$_GET`, `$_POST`, `$_SERVER`.
- `method()`, `path()`, `query(key, default)`, `input(key, default)`, `ip()`.
- `setUser(User $user)` / `user(): ?User` — holds the current user loaded by middleware.
- `all(): array` for old input preservation.

**`Response.php`**:
- `html(string $body, int $status = 200): static`.
- `redirect(string $url, int $status = 302): static`.
- `csv(string $filename, callable $writer): static` — sets headers, BOM, streams.
- `send(): void`.

**`View.php`**:
- `render(string $template, array $data = []): string`.
- Wraps in `templates/layout.php`.
- Extracts `$data` into template scope.
- `renderPartial(string $partial, array $data = []): string`.

**Acceptance criteria**
- Router dispatches exact paths only.
- Request never exposes raw superglobals to services.
- View renders layout + template + flash.

---

### Task 17 · `Session.php`, `Csrf.php`, `Database.php`

**Files to create**
```
src/Core/Session.php
src/Core/Csrf.php
src/Core/Database.php
```

**Spec sections:** §8.4, §8.5, §3.2, §12

**Instructions**

**`Session.php`**:
- `start()`: configure `session.cookie_httponly`, `session.cookie_secure` (from config), `session.cookie_samesite = 'Lax'`, `session.use_strict_mode = 1`, `session.use_only_cookies = 1`, cookie name from env, save path `storage/sessions/`.
- `get/set/delete/has`.
- `flash(type, msg)` / `getFlash(type)`.
- `regenerate()`.
- `destroy()`.
- `userId(): ?int`, `setUserId(int)`, `createdAt()`, `lastActivity()`.

**`Csrf.php`**:
- `token(): string` — per-session, `bin2hex(random_bytes(32))`.
- `validate(string $token): bool` — `hash_equals`.
- `generateFormNonce(): string` — one-time nonce stored in session.
- `consumeFormNonce(string $nonce): bool` — validate + delete.
- `field(): string` — returns hidden input HTML.

**`Database.php`**:
- `connect(): PDO` using config values.
- `PDO::ERRMODE_EXCEPTION`, `PDO::ATTR_EMULATE_PREPARES => false`, `PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC`.
- `SET time_zone = '+00:00'` after connect.
- `SET NAMES utf8mb4`.

**Acceptance criteria**
- Session cookie is `HttpOnly`, `Secure` (in prod), `SameSite=Lax`.
- CSRF token is 64 hex chars.
- Form nonce is consumed (single-use).
- PDO uses real prepared statements.

---

## Phase 4 — Middleware & Authentication

---

### Task 18 · Middleware Pipeline

**Files to create**
```
src/Http/Middleware/SecurityHeaders.php
src/Http/Middleware/SessionTimeout.php
src/Http/Middleware/RequireAuth.php
src/Http/Middleware/CsrfGuard.php
```

**Spec sections:** §4.1, §8.4, §8.5, §8.7

**Dependencies:** Task 16, Task 17

**Instructions**
Each middleware: `handle(Request $request, callable $next): Response`.

**`SecurityHeaders`** (all responses):
- Set the exact CSP from §8.7: `default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'`.
- `X-Content-Type-Options: nosniff`.
- `X-Frame-Options: DENY`.
- `Referrer-Policy: same-origin`.
- `Strict-Transport-Security: max-age=31536000` (HTTPS only).
- `Cache-Control: no-store` on authenticated pages.

**`SessionTimeout`**:
- Check idle timeout (30 min) and absolute timeout (8 h) from session.
- Expired → destroy session, redirect to `/login`.
- Update `last_activity`.

**`RequireAuth`**:
- No session user → redirect to `/login` (store intended path if local, starts with `/`, not `//`).
- Load user from DB by `users.id` **every request** (per §8.4).
- User inactive → destroy session, redirect to login.
- Set `$request->setUser($user)`.

**`CsrfGuard`** (POST only):
- Validate `csrf_token` via `hash_equals`.
- Failure → 403 with Persian "session expired" page.

**Acceptance criteria**
- Unauthenticated access to `/overtime/new` redirects to `/login`.
- Deactivated user is rejected on next request.
- POST without valid CSRF → 403.
- All security headers present on every response.

---

### Task 19 · Auth Service, Repository & Controller

**Files to create**
```
src/Services/AuthService.php
src/Repositories/UserRepository.php
src/Repositories/LoginAttemptRepository.php
src/Http/Controllers/AuthController.php
src/Input/LoginInput.php
```

**Spec sections:** §8.1, §8.2, §8.3, §9.1

**Dependencies:** Task 17, Task 18

**Instructions**

**`UserRepository`**: `findByUsername(string)`, `findById(int)`, `updateLastLogin(int)`, `updatePasswordHash(int, string)`.

**`LoginAttemptRepository`**: `record(string $username, string $ip, bool $success)`, `countRecent(string $username, string $ip, int $minutes): int`, `countRecentByIp(string $ip, int $minutes): int`, `clearForUserIp(string $username, string $ip)`, `prune(int $daysOld)`.

**`AuthService`**:
- `attempt(string $username, string $password, string $ip): array{success: bool, user?: array, error?: string}`.
  1. Throttle check (≥5 per user+IP or ≥20 per IP in 15 min).
  2. Look up user by lower-cased username. If missing/inactive, still `password_verify` against dummy hash (timing equalisation).
  3. `password_verify`. Failure → record, return generic error.
  4. Success → `session_regenerate_id(true)`, store `user_id`, `created_at`, `last_activity`. Check `password_needs_rehash` → re-hash. Update `last_login_at`. Clear failed attempts. Return user.
- Hashing: `PASSWORD_ARGON2ID`, `memory_cost=19456`, `time_cost=2`, `threads=1`. Fallback `PASSWORD_DEFAULT`.

**`AuthController`**:
- `showLogin()`: if authenticated → redirect `/overtime/new`. Render login template.
- `login()`: CSRF → validate input → `AuthService::attempt` → success: redirect to intended local path or `/overtime/new`. Failure: re-render with generic error (422).
- `logout()`: CSRF → clear session, destroy, redirect to `/login`.

**`LoginInput`**: validate username (required, ≤64) and password (required, ≤128).

**Acceptance criteria**
- 5 failed logins from same user+IP → throttle message.
- Unknown username and wrong password produce identical error and similar timing.
- Session ID changes on successful login.
- Post-login redirect only to local paths (starts with single `/`, not `//`).

---

## Phase 5 — Domain Support (PHP)

---

### Task 20 · `JalaliDate.php` — Server-Side Solar Hijri

**Files to create**
```
src/Support/JalaliDate.php
```

**Spec sections:** §7.2, §3.2

**Dependencies:** Task 13

**Instructions**
1. Namespace `App\Support`. `declare(strict_types=1)`.
2. Methods (exact signatures from §7.2):
   - `normalizeDigits(string $s): string` — Persian ۰-۹ and Arabic-Indic ٠-٩ → Latin.
   - `toGregorian(string $jalali): ?string` — `'1405/07/11'` → `'2026-10-03'` or `null`.
   - `fromGregorian(string $iso, bool $persianDigits = false): string`.
   - `weekdayName(string $iso): string` — Persian weekday via `IntlDateFormatter` pattern `EEEE`.
   - `isWeekendDay(string $iso, array $weekendDays): bool` — ISO weekday `format('N')` in config list.
   - `today(): string` — today as Jalali in `Asia/Tehran`.
3. **IntlDateFormatter** must use `IntlDateFormatter::TRADITIONAL` (see §7.2 comment).
4. **Strict validation**: after converting Jalali→Gregorian, convert back and require exact match. Reject `1405/07/31`, `1404/12/30` (non-leap).
5. Input regex after digit normalisation: `^\d{4}[/-]\d{1,2}[/-]\d{1,2}$`.
6. `IntlCalendar` month is 0-based.

**Acceptance criteria**
- `toGregorian('1405/07/11')` returns `'2026-10-03'`.
- `fromGregorian('2026-10-03')` returns `'1405/07/11'`.
- `toGregorian('1405/07/31')` returns `null` (invalid).
- `toGregorian('1404/12/30')` returns `null` (non-leap).
- `toGregorian('1403/12/30')` returns a valid date (leap year).
- `isWeekendDay('2026-10-03', ['thu','fri'])` → `false` (Saturday).
- `isWeekendDay('2026-10-08', ['thu','fri'])` → `true` (Thursday).

---

### Task 21 · `TextNormalizer.php` + `Validator.php`

**Files to create**
```
src/Support/TextNormalizer.php
src/Support/Validator.php
```

**Spec sections:** §7.5, §9.2

**Dependencies:** Task 13

**Instructions**

**`TextNormalizer`**:
- `normalize(string $s): string` — identical rules to `normalize.js` (Task 8):
  1. Arabic `ي` → `ی`, Arabic `ك` → `ک`.
  2. Persian/Arabic-Indic digits → Latin.
  3. Remove ZWNJ, tatweel, Arabic diacritics.
  4. Collapse whitespace, trim, lower-case Latin.
- `normalizePersonnelCode(string $code): string` — trim, validate `^[0-9A-Za-z]+$`.

**`Validator`** (static helpers):
- `required(mixed $v): bool`.
- `intRange(int $v, int $min, int $max): bool`.
- `strLength(string $s, int $max): bool` (uses `mb_strlen`).
- `inArray(mixed $v, array $allowed): bool`.
- `isDecimalStep(string $v, float $step): bool` — for 0.25 h step.
- `jalaliDate(string $s): bool` — format check only (real validation in `JalaliDate`).

**Acceptance criteria**
- `TextNormalizer::normalize('علی‌رضا')` === `TextNormalizer::normalize('علي رضا')`.
- Validator correctly rejects hours not on 0.25 step.

---

### Task 22 · Input DTOs

**Files to create**
```
src/Input/OvertimeSubmission.php
src/Input/DeleteEntryInput.php
src/Input/ReportFilter.php
```

**Spec sections:** §9.2, §9.3, §9.4, §5.2

**Dependencies:** Task 20, Task 21

**Instructions**

**`OvertimeSubmission`**:
- `fromPost(array $post, array $config): self`.
- Fields: `type_id` (int, required), `date` (Jalali string), `hours` (string), `description` (?string), `personnel_ids` (array).
- `validate(): array` → list of error strings. Rules:
  - `type_id`: required, must exist (checked by service).
  - `date`: required, valid Jalali (via `JalaliDate::toGregorian`), within ±366 days of today.
  - `hours`: required, numeric after digit/decimal normalisation, 0.25 ≤ h ≤ 8, multiple of 0.25.
  - `description`: optional, trimmed, ≤255 `mb_strlen`, strip control chars, empty → `null`.
  - `personnel_ids`: 1–500 items, all integers, deduplicated.

**`DeleteEntryInput`**: `entry_id` (int, required), `back` (string, must start with `/reports`).

**`ReportFilter`**:
- `fromQuery(array $query): self`.
- Fields: `from`, `to`, `division_id`, `type_id`, `q`, `page`.
- Validate each per §9.3 rules. `to` ≥ `from` if both set. `q` ≤ 100 chars, normalised.
- `toSqlConditions(): array{where: string, params: array}` — whitelist approach.

**Acceptance criteria**
- Hours `۲٫۵` (Persian) validates correctly.
- Date `1405/07/31` fails validation.
- Report filter with only `q` set produces correct WHERE clause.
- `back` URL not starting with `/reports` is rejected.

---

## Phase 6 — Repositories

---

### Task 23 · All Repository Classes

**Files to create**
```
src/Repositories/PersonnelRepository.php
src/Repositories/OvertimeRepository.php
src/Repositories/CycleRepository.php
src/Repositories/AuditLogRepository.php
src/Repositories/LookupRepository.php
```

**Spec sections:** §6.5, §5.4, §5.5, §9.3

**Dependencies:** Task 17 (Database), Task 14 (schema)

**Instructions**
All repositories receive `PDO` via constructor. **Parameterised queries only.** No business logic.

**`LookupRepository`**: `divisions(): array`, `overtimeTypes(): array`.

**`PersonnelRepository`**:
- `activeWithCycleStatus(): array` — the §6.5 query with `EXISTS` subquery. Returns all active personnel with `used_in_open_cycle`.
- `findByIds(array $ids): array`.
- `activeByDivision(int $divisionId): array`.

**`CycleRepository`**:
- `openCycleForUpdate(int $divisionId): ?array` — `SELECT … WHERE division_id = :div AND closed_at IS NULL FOR UPDATE`.
- `closeCycle(int $cycleId): void`.
- `openNextCycle(int $divisionId, int $nextNumber): int` — INSERT, return new id.
- `deleteCycle(int $cycleId): void`.
- `reopenCycle(int $cycleId): void` — `SET closed_at = NULL`.
- `mostRecentClosedCycle(int $divisionId): ?array`.
- `summaryStrip(): array` — the cycle summary query from §6.5.
- `remainingCount(int $divisionId, int $cycleId): int` — active personnel with no entry in cycle.

**`OvertimeRepository`**:
- `insertBatch(array $rows): void` — one INSERT per row in loop.
- `existingInCycle(int $cycleId, array $personnelIds): array`.
- `findById(int $id): ?array`.
- `delete(int $id): void`.
- `filteredQuery(ReportFilter $f, bool $paginated): array` — the §6.5 report query.
- `filteredTotals(ReportFilter $f): array{count: int, hours: float}`.
- `streamForCsv(ReportFilter $f): \Generator` — unbuffered query for CSV.

**`AuditLogRepository`**: `log(int $userId, string $action, ?int $entityId, array $details, string $ip): void`.

**Acceptance criteria**
- No string concatenation in SQL. All parameters bound.
- `openCycleForUpdate` uses `FOR UPDATE`.
- Report query supports all optional filters via AND.
- CSV streaming uses unbuffered PDO.

---

## Phase 7 — Business Services

---

### Task 24 · `AccessPolicy.php`

**Files to create**
```
src/Services/AccessPolicy.php
```

**Spec sections:** §8.6

**Dependencies:** Task 13

**Instructions**
1. Single class, stateless.
2. `canSubmitFor(array $user, int $divisionId): bool` → `$user['division_id'] === $divisionId`.
3. `canDelete(array $user, array $entry): bool` → `$user['division_id'] === $entry['division_id']`.
4. Both compare against `user.division_id` loaded from DB in current request.
5. No other role checks in MVP.

**Acceptance criteria**
- Returns `false` for cross-division access.
- No hardcoded division IDs.

---

### Task 25 · `CycleService.php`

**Files to create**
```
src/Services/CycleService.php
```

**Spec sections:** §5.1, §5.3, §5.4

**Dependencies:** Task 23

**Instructions**
1. `open(int $divisionId, PDO $pdo): array` — **must be called as first statement in transaction**:
   - `SELECT … FOR UPDATE` on the division's open cycle.
   - **Lazy close/open**: if the open cycle has ≥1 entries AND 0 remaining active personnel → close it, open next (`cycle_number + 1`).
   - Return `['id' => …, 'cycle_number' => …]`.
2. `summaryStrip(): array` — delegates to `CycleRepository`.
3. `checkAndClose(int $divisionId, int $cycleId, PDO $pdo): ?int` — after insert, count remaining. If 0 → close cycle, open next. Return new cycle number or null.
4. All operations assume caller already holds the transaction.

**Acceptance criteria**
- Lazy close works: deactivate last person → next page load closes cycle.
- `FOR UPDATE` is the first SQL in the transaction.
- Two concurrent submits serialise correctly.

---

### Task 26 · `OvertimeService.php` — Submit + Delete

**Files to create**
```
src/Services/OvertimeService.php
```

**Spec sections:** §5.4, §5.5, §8.6, §9.2, §9.4

**Dependencies:** Task 23, Task 24, Task 25, Task 20, Task 22

**Instructions**

**`submitBatch(OvertimeSubmission $input, array $user, array $type): array`**
Follow §5.4 exactly:
1. Division from `$user['division_id']`, **never** from form.
2. Validate day rule: `JalaliDate::isWeekendDay()` against `$type['day_rule']`.
3. `BEGIN`.
4. If `$type['uses_cycle']`:
   a. `$cycle = CycleService::open($divisionId, $pdo)` (FOR UPDATE first).
   b. Check existing entries in cycle for submitted personnel. Any → ROLLBACK, error listing names.
   c. Set `$cycleId`.
   Else `$cycleId = null`.
5. Verify all personnel exist, active, and in user's division. Mismatch → ROLLBACK, 403 + security log.
6. INSERT one row per person.
7. If uses_cycle: check remaining, close/open if needed.
8. COMMIT.
9. Catch SQLSTATE 23000 / errno 1062 → friendly duplicate message.
10. Return `['success' => true, 'count' => N, 'cycleClosed' => bool, 'newCycleNumber' => ?int]`.

**`deleteEntry(int $entryId, array $user): array`**
Follow §5.5 exactly:
1. `BEGIN`.
2. Lock open cycle for user's division (`FOR UPDATE`).
3. Load entry by id (`FOR UPDATE`). Not found → ROLLBACK. Wrong division → ROLLBACK, 403.
4. DELETE.
5. If entry had `cycle_id` and it's a **closed** cycle:
   - If it's the most recent closed cycle AND open cycle has 0 entries → delete empty open cycle, re-open previous.
   - Else: no cycle change.
6. INSERT `audit_log` with full JSON snapshot.
7. COMMIT.
8. Return `['success' => true, 'cycleReopened' => bool, 'reopenedNumber' => ?int]`.

**Acceptance criteria**
- Submit for another division's personnel → 403.
- Duplicate in cycle → friendly error with names.
- Delete from most-recent closed cycle with empty open cycle → cycle re-opens.
- Audit log row created on every delete.

---

### Task 27 · `ReportService.php` + `CsvExporter.php`

**Files to create**
```
src/Services/ReportService.php
src/Services/CsvExporter.php
```

**Spec sections:** §9.3, §9.5, §6.5

**Dependencies:** Task 23, Task 22, Task 20

**Instructions**

**`ReportService`**:
- `query(ReportFilter $f, int $page, int $pageSize): array` — rows + pagination meta.
- `totals(ReportFilter $f): array{count: int, hours: float}`.
- `stream(ReportFilter $f): \Generator` — for CSV.

**`CsvExporter`**:
- `export(ReportFilter $f, string $todayJalali): Response`.
- Headers: `Content-Type: text/csv; charset=utf-8`, `Content-Disposition: attachment; filename="overtime-report-{jalali}.csv"`.
- Write UTF-8 BOM (`\xEF\xBB\xBF`).
- Columns: تاریخ, کد پرسنلی, نام و نام خانوادگی, واحد, نوع اضافه‌کاری, ساعت, دور, توضیحات.
- Date: Jalali `YYYY/MM/DD` Latin digits.
- Hours: dot decimal, Latin digits.
- Cycle: number or empty.
- **Injection guard**: prefix cells starting with `=`, `+`, `-`, `@`, tab, CR with `'`.
- `fputcsv($out, $row, ',', '"', '')` — explicit escape arg.
- Stream from unbuffered PDO to `php://output`.

**Acceptance criteria**
- CSV opens in Excel with correct Persian text (BOM present).
- Formula `=1+1` in description exports as `'=1+1`.
- Exported rows match the on-screen filtered result exactly.
- No pagination in CSV.

---

## Phase 8 — Controllers, Routing & Front Controller

---

### Task 28 · `OvertimeController` + `ReportController`

**Files to create**
```
src/Http/Controllers/OvertimeController.php
src/Http/Controllers/ReportController.php
```

**Spec sections:** §9.2, §9.3, §9.4, §9.5, §4.2, §10

**Dependencies:** Task 26, Task 27, Task 24, Task 16

**Instructions**

**`OvertimeController`**:
- `create(Request $req): Response` — GET `/overtime/new`. Load types, divisions, personnel with cycle status, cycle summary strip. Render template. Generate `form_nonce`.
- `store(Request $req): Response` — POST `/overtime`. CSRF → consume `form_nonce` → `OvertimeSubmission::fromPost` → validate → `OvertimeService::submitBatch`. Success: flash + redirect (PRG). Validation error: re-render 422 with old input. Business error: re-render with names. Tampering: 403.
- `delete(Request $req): Response` — POST `/overtime/delete`. CSRF → `DeleteEntryInput` → `OvertimeService::deleteEntry`. Success: flash + redirect to `back`. Error: 403 or 404.

**`ReportController`**:
- `index(Request $req): Response` — GET `/reports`. `ReportFilter::fromQuery` → validate → `ReportService::query` + totals. Render with pagination.
- `export(Request $req): Response` — GET `/reports/export`. Same filter → `CsvExporter::export`.

**Controllers must NOT contain SQL or business rules.** They build DTOs, call services, choose view/redirect.

**Acceptance criteria**
- POST `/overtime` with forged division personnel → 403.
- Double-submit (back + resubmit) rejected by `form_nonce`.
- Report page shows all divisions for all admins.
- Delete button only rendered for own-division rows.

---

### Task 29 · Route Table + Front Controller (`public/index.php`)

**Files to create**
```
config/routes.php
public/index.php
```

**Spec sections:** §4.1, §4.3, §10

**Dependencies:** Task 16, Task 18, Task 28, Task 19

**Instructions**

**`config/routes.php`**: return array matching §10 route table:

| Method | Path | Controller | Middleware |
|--------|------|-----------|------------|
| GET | `/` | redirect | — |
| GET | `/login` | AuthController::showLogin | (public) |
| POST | `/login` | AuthController::login | CsrfGuard |
| POST | `/logout` | AuthController::logout | RequireAuth, CsrfGuard |
| GET | `/overtime/new` | OvertimeController::create | RequireAuth |
| POST | `/overtime` | OvertimeController::store | RequireAuth, CsrfGuard |
| POST | `/overtime/delete` | OvertimeController::delete | RequireAuth, CsrfGuard |
| GET | `/reports` | ReportController::index | RequireAuth |
| GET | `/reports/export` | ReportController::export | RequireAuth |

Default-deny: everything behind `RequireAuth` unless marked public.

**`public/index.php`**:
1. `declare(strict_types=1)`.
2. `require '../src/bootstrap.php'`.
3. Start session.
4. Build `Request`.
5. Run middleware pipeline → controller.
6. Send `Response`.
7. Catch uncaught exceptions → log + generic 500.

**Acceptance criteria**
- Unknown path → 404.
- Wrong method → 405.
- `/` redirects to `/overtime/new` (authenticated) or `/login`.
- All routes wired correctly.

---

## Phase 9 — CLI Tools

---

### Task 30 · `bin/create-user.php`

**Files to create**
```
bin/create-user.php
```

**Spec sections:** §8.2, §11

**Dependencies:** Task 14, Task 17

**Instructions**
1. Usage: `php bin/create-user.php <username> --division=<id|name> [--name="…"]`.
2. `--reset-password` flag updates an existing user's password.
3. Prompt for password twice (hidden input via `stty -echo` / `readline`). Never as CLI argument.
4. Enforce ≥ 12 characters, ≤ 128, any characters.
5. Hash with `PASSWORD_ARGON2ID` (same params as `AuthService`).
6. Validate division exists (by id or name).
7. Reject duplicate username.
8. Success message with username and division.

**Acceptance criteria**
- Password never appears in process list or logs.
- Division validated against DB.
- `--reset-password` works for existing users.

---

### Task 31 · `bin/personnel.php`

**Files to create**
```
bin/personnel.php
```

**Spec sections:** §11, §7.5, §6.4

**Dependencies:** Task 14,
# Overtime Management System — Implementation Task Breakdown

> **Reading guide:** Each task is self-contained. Give the LLM the task description **plus** the relevant spec sections (§ references are listed per task). Dependencies tell you what must already exist. Acceptance criteria let you verify the output before moving on.

---

## Phase 1 — Frontend Foundation (Templates, CSS, Fonts)

---

### Task 1 · Project Skeleton & Tailwind CSS Build

**Files to create**
```
resources/css/input.css
.gitignore
```

**Spec sections:** §3.1, §3.2, §13, §7.1

**Instructions**
1. Create `resources/css/input.css` as the Tailwind 4 entry file.
   - `@import "tailwindcss";`
   - `@source` directives pointing at `../../templates` and `../../public/assets/js`.
   - `@font-face` for **Vazirmatn** variable `woff2` at `/assets/fonts/Vazirmatn-Variable.woff2`, `font-weight: 100 900`, `font-display: swap`.
   - `@theme` block setting `--font-sans: "Vazirmatn", Tahoma, system-ui, sans-serif`.
2. Create `.gitignore` covering: `.env`, `storage/logs/*`, `storage/sessions/*`, `public/assets/css/app.css`, `node_modules/`, `tailwindcss` binary.
3. Create empty placeholder directories (as `.gitkeep` files):
   - `public/assets/fonts/`
   - `public/assets/js/lib/`
   - `public/assets/js/pages/`
   - `templates/partials/`
   - `templates/errors/`
   - `lang/`
   - `config/`
   - `database/migrations/`
   - `bin/`
   - `src/` (with sub-dirs `Core/`, `Http/Controllers/`, `Http/Middleware/`, `Services/`, `Repositories/`, `Input/`, `Support/`)
   - `storage/logs/`
   - `storage/sessions/`

**Acceptance criteria**
- `./tailwindcss -i resources/css/input.css -o public/assets/css/app.css` produces a valid CSS file.
- No CDN or Node/npm references anywhere.
- `.gitignore` prevents `.env` and generated CSS from being committed.

---

### Task 2 · Persian Language File (`lang/fa.php`)

**Files to create**
```
lang/fa.php
```

**Spec sections:** §7.1, §7.6

**Instructions**
1. Create `lang/fa.php` returning an associative array of **all** keys listed in the §7.6 glossary table.
2. Every key from the table must be present with its exact Persian value.
3. Add additional keys needed by templates that are implied but not in the glossary:
   - Flash messages: `flash_submit_success` (`اضافه‌کاری برای {count} نفر ثبت شد — {type}، {date}، {hours} ساعت`), `flash_cycle_closed` (`دور {n} تکمیل شد؛ دور {next} آغاز شد.`), `flash_delete_success` (`رکورد حذف شد.`), `flash_cycle_reopened` (`دور {n} دوباره باز شد.`), `flash_logout`.
   - Validation: `err_required`, `err_invalid_date`, `err_date_window`, `err_invalid_hours`, `err_hours_step`, `err_personnel_count`, `err_unknown_personnel`, `err_inactive_personnel`, `err_already_used_cycle`, `err_batch_rejected`.
   - Auth: `err_csrf` (`نشست شما منقضی شده است؛ صفحه را دوباره بارگیری کنید.`), `err_forbidden`.
   - Pagination: `pagination_prev`, `pagination_next`, `pagination_info` (`صفحه {current} از {total}`).
   - Report summary: `report_summary` (`{count} رکورد · {hours} ساعت`).
   - Delete dialog: `confirm_delete_title`, `confirm_delete_body`, `btn_delete_confirm`, `btn_delete_cancel`.
   - Status labels: `status_locked` (`🔒 فقط مشاهده`).
4. Use `{placeholder}` syntax for interpolation. The `t()` helper (built later) will do `str_replace`.

**Acceptance criteria**
- File is valid PHP returning `array<string, string>`.
- Every key in §7.6 is present verbatim.
- No English text in values (except placeholders).

---

### Task 3 · Base Layout Template (`templates/layout.php`)

**Files to create**
```
templates/layout.php
templates/partials/flash.php
```

**Spec sections:** §7.1, §8.7, §9 (common layout), §13

**Dependencies:** Task 1 (CSS file path), Task 2 (language keys)

**Instructions**
1. `layout.php` receives `$title`, `$content` (pre-rendered HTML string), and optional `$activeNav`.
2. `<html lang="fa" dir="rtl">`.
3. `<head>`:
   - `<meta charset="utf-8">`, viewport, `<title>` using `$title` + app name.
   - `<link rel="stylesheet" href="<?= asset('css/app.css') ?>">`.
   - No inline `<style>` or `<script>` (strict CSP).
4. `<body>`:
   - **Top bar** (hidden on login page via `$showNav` flag):
     - App name (`t('app_name')`).
     - Nav links: `t('nav_submit')` → `/overtime/new`, `t('nav_reports')` → `/reports`. Active link highlighted.
     - Right side: current user display name + division name, Logout button (a `<form method="post" action="/logout">` with `csrf_field()`).
   - **Flash area** under nav: `<?php include partials/flash.php ?>` with `role="status"` / `role="alert"`.
   - `$content`.
5. All output escaped via `e()` except `$content` (already rendered).
6. Use **Tailwind logical utilities only** (`ms-*`, `me-*`, `ps-*`, `pe-*`, `start-*`, `end-*`, `text-start`, `border-s`, `rounded-s`). No physical `ml-/mr-/pl-/pr-/left-/right-`.
7. `flash.php` partial: renders session flash messages (success → green, error → red) and clears them.

**Acceptance criteria**
- Valid RTL HTML5.
- No physical-direction Tailwind classes.
- Logout is a POST form with CSRF hidden field placeholder.
- Flash area uses ARIA live regions.

---

### Task 4 · Login Page Template (`templates/login.php`)

**Files to create**
```
templates/login.php
```

**Spec sections:** §9.1, §7.1, §8.1

**Dependencies:** Task 3

**Instructions**
1. Standalone page (no nav bar). Centered card layout.
2. Fields:
   - Username: `<input type="text" name="username" autocomplete="username" required>`, label `t('username')`.
   - Password: `<input type="password" name="password" autocomplete="current-password" required>`, label `t('password')`.
   - CSRF hidden field via `csrf_field()`.
3. Submit button: `t('login')`.
4. Error display: single generic message area above the form (shows `t('err_login')` or `t('err_throttle')`).
5. Old input: `value="<?= e(old('username')) ?>"` on username.
6. `dir="rtl"` inherited from layout. Input text alignment via `text-start`.
7. `method="post" action="/login"`.

**Acceptance criteria**
- No nav bar rendered.
- CSRF field present.
- Generic error area (never reveals which credential was wrong).
- Accessible labels on both inputs.

---

### Task 5 · Submit Overtime Page Template (`templates/overtime/new.php`)

**Files to create**
```
templates/overtime/new.php
```

**Spec sections:** §9.2, §7.1, §7.4, §7.6, §5.1, §5.2

**Dependencies:** Task 3, Task 2

**Instructions**
1. Receives from controller: `$types`, `$divisions`, `$userDivisionId`, `$personnel` (array with `id`, `personnel_code`, `full_name`, `division_id`, `used_in_open_cycle`, `division_name`), `$cycleSummary` (array per division), `$errors`, `$old`, `$weekendDays` (for JS data attribute).
2. **Form row** (wraps to single column on narrow screens):
   - **Type** `<select name="type_id">`: options from `$types`, each with `data-uses-cycle` and `data-day-rule` attributes. Selected from `$old`.
   - **Division filter** `<select id="division-filter">` (no `name` attribute — display only per C2). Options: "همه واحدها" + each division. Defaults to `$userDivisionId`.
   - **Date**: `<input type="text" name="date" data-jalali-datepicker dir="ltr" autocomplete="off" inputmode="numeric" data-min="…" data-max="…">` + `<span id="weekday-label">` for weekday name + `<div id="day-rule-msg" aria-live="polite">` for mismatch message.
   - **Hours**: `<input type="text" name="hours" dir="ltr" inputmode="decimal" class="text-end">`, label `t('hours')`.
   - **Description**: `<input type="text" name="description" maxlength="255">`, label `t('description')` + "(اختیاری)".
   - Hidden: `csrf_field()` + `<input type="hidden" name="form_nonce" value="…">`.
3. **Cycle summary strip**: one chip per division: `{name}: دور {cycle_number} · {done}/{total}`. Own division chip highlighted.
4. **Search box**: `<input type="text" id="personnel-search" placeholder="<?= t('search_placeholder') ?>">`.
5. **Selection counter**: `<span id="selected-count" aria-live="polite">`.
6. **Personnel table** (horizontally scrollable container):
   - Columns: checkbox, Name, Personnel ID, Division, Status.
   - Each row `<tr>` carries: `data-personnel-id`, `data-division-id`, `data-own` (1/0), `data-used` (1/0).
   - Checkbox: `name="personnel_ids[]" value="{id}"`. Disabled + `title` when `!own` or (`uses_cycle` and `used`).
   - Status cell text per §9.2 rules.
   - Header checkbox: "select all visible, enabled rows" with indeterminate support.
   - Personnel code and date cells get `dir="ltr"`.
7. **Submit button**: `t('submit')`, initially disabled state managed by JS.
8. `form method="post" action="/overtime"`.
9. `<script type="application/json" id="i18n">` block with JS-needed strings (day-rule messages, selected_count template, status labels, weekend days array).
10. `<script type="module" src="<?= asset('js/pages/submit-overtime.js') ?>">`.
11. All Tailwind classes logical only.

**Acceptance criteria**
- Division dropdown has **no** `name` attribute.
- Every row has all four `data-` attributes.
- JSON i18n block is present and valid JSON.
- No inline JS event handlers.

---

### Task 6 · Reports Page Template + Delete Dialog (`templates/reports/index.php`, `templates/partials/delete_dialog.php`)

**Files to create**
```
templates/reports/index.php
templates/partials/delete_dialog.php
templates/partials/pagination.php
```

**Spec sections:** §9.3, §9.4, §7.1

**Dependencies:** Task 3, Task 2

**Instructions**
1. **Filter form** (`method="get" action="/reports"`):
   - From date: `<input type="text" name="from" data-jalali-datepicker dir="ltr" inputmode="numeric">`.
   - To date: same with `name="to"`.
   - Division `<select name="division_id">`: "همه واحدها" + divisions.
   - Type `<select name="type_id">`: "همه انواع" + types.
   - Search: `<input type="text" name="q" maxlength="100">`.
   - Apply button (`type="submit"`), Reset link (`href="/reports"`), **Export CSV** button (`type="submit" formaction="/reports/export"`).
   - Per-field error display.
2. **Summary line**: `t('report_summary')` with count + total hours.
3. **Table** (scrollable):
   - Columns: Date, Personnel ID, Name, Division, Type, Hours, Cycle, Description, Actions.
   - Date and Personnel ID cells: `dir="ltr"`.
   - Cycle: number or `—`.
   - Description: truncated with `title` attribute for full text.
   - Actions: Delete button **only** when `$row['division_id'] === $userDivisionId`. Button carries `data-entry-id`, `data-name`, `data-date`, `data-type`, `data-hours` for the dialog.
4. **Pagination partial**: Prev/Next links + "Page X of Y". Links preserve current query string.
5. **Delete dialog** (`delete_dialog.php`):
   - Native `<dialog id="delete-dialog">`.
   - Summary area filled by JS.
   - Confirmation text: `t('confirm_delete')`.
   - `<form method="post" action="/overtime/delete">` with hidden `csrf_token`, `entry_id`, `back`.
   - Delete (submit) + Cancel buttons.
6. `<script type="application/json" id="i18n">` with delete-related strings.
7. `<script type="module" src="<?= asset('js/pages/reports.js') ?>">`.

**Acceptance criteria**
- Export button uses `formaction="/reports/export"` (same form, no JS needed).
- Delete button absent for other-division rows.
- `<dialog>` element used (not a div overlay).
- All filters preserved in pagination links.

---

### Task 7 · Error Page Templates

**Files to create**
```
templates/errors/403.php
templates/errors/404.php
templates/errors/500.php
```

**Spec sections:** §14, §7.1

**Dependencies:** Task 3

**Instructions**
1. Each extends the layout (minimal nav) or is a standalone minimal page.
2. **403**: Persian "دسترسی مجاز نیست" message. No technical details.
3. **404**: Persian "صفحه پیدا نشد" + link back to `/overtime/new`.
4. **500**: Persian generic "خطای داخلی سرور" + "لطفاً بعداً دوباره تلاش کنید." **No** stack trace, file names, or exception details.
5. All RTL, Vazirmatn font, centered card.

**Acceptance criteria**
- No sensitive information on any error page.
- All text in Persian via `t()` or hardcoded Persian strings.

---

## Phase 2 — Frontend JavaScript

---

### Task 8 · `digits.js` + `normalize.js`

**Files to create**
```
public/assets/js/lib/digits.js
public/assets/js/lib/normalize.js
```

**Spec sections:** §7.5, §3.2, §7.1

**Instructions**

**`digits.js`** (ES module):
- `toLatinDigits(str)`: replace Persian `۰-۹` (U+06F0–F9) and Arabic-Indic `٠-٩` (U+0660–69) with `0-9`.
- `toPersianDigits(str)`: reverse mapping.
- `parseDecimal(str)`: normalise digits to Latin, replace `٫` (U+066B) and `,` with `.`, return trimmed string.

**`normalize.js`** (ES module, must be identical rules to PHP `TextNormalizer`):
- `normalizeText(str)`:
  1. Arabic `ي` (U+064A) → `ی` (U+06CC).
  2. Arabic `ك` (U+0643) → `ک` (U+06A9).
  3. Persian/Arabic-Indic digits → Latin (import from `digits.js`).
  4. Remove ZWNJ (U+200C), tatweel (U+0640), Arabic diacritics (U+064B–U+065F).
  5. Collapse whitespace, trim, lower-case Latin letters.

**Acceptance criteria**
- Both are ES modules with named exports.
- No dependencies on external libraries.
- `normalizeText('علی‌رضا')` === `normalizeText('علي رضا')` (ZWNJ vs space, ي→ی).

---

### Task 9 · `jalali.js` — Solar Hijri Math (Browser)

**Files to create**
```
public/assets/js/lib/jalali.js
```

**Spec sections:** §7.3, §3.2

**Instructions**
1. ES module, no external dependencies.
2. **Gregorian → Jalali**: use `Intl.DateTimeFormat('en-u-ca-persian-nu-latn', {year:'numeric',month:'numeric',day:'numeric',timeZone:'UTC'})` with `formatToParts`. Extract year/month/day, ignore era.
3. **Jalali → Gregorian**: anchor on 1 Farvardin (probe March 19–22 of `jy + 621` using the above function), then add day offsets. Month lengths: 1–6 = 31, 7–11 = 30, 12 = 29 (30 in leap). Leap detection: next Nowruz is 366 days away.
4. **Validation**: `isValidJalali(y, m, d)` — month 1-12, day within month length.
5. **Names**:
   - `monthNames()`: `Intl.DateTimeFormat('fa-IR-u-ca-persian', {month:'long'})` → فروردین … اسفند.
   - `weekdayName(gregorianDate)`: `{weekday:'long'}` → شنبه … جمعه.
   - `weekdayNarrow(gregorianDate)`: `{weekday:'narrow'}` for calendar header.
6. **Weekday number**: from converted Gregorian via `Date.UTC(...)` → `getUTCDay()`. Saturday = 6, Sunday = 0, …, Friday = 5. Also expose ISO weekday (1=Mon…7=Sun) for day-rule checks.
7. **Week starts on Saturday**.
8. Export: `toJalali(date)`, `toGregorian(jy, jm, jd)`, `isValidJalali`, `jalaliMonthLength(jy, jm)`, `monthName(jm)`, `weekdayName`, `isoWeekday(date)`, `today()`.

**Acceptance criteria**
- Round-trip: `toGregorian(...toJalali(date))` returns the same date.
- Leap year 1403: month 12 has 30 days. Non-leap 1404: month 12 has 29 days.
- `weekdayName(new Date('2026-10-03'))` returns `'شنبه'` (Saturday).
- No third-party imports.

---

### Task 10 · `datepicker.js` — In-House Jalali Date Picker

**Files to create**
```
public/assets/js/lib/datepicker.js
```

**Spec sections:** §7.4, §7.1, §13

**Dependencies:** Task 8 (digits), Task 9 (jalali)

**Instructions**
1. ES module. Targets any `<input data-jalali-datepicker>`.
2. **Popup calendar**:
   - RTL grid, 7 columns, **Saturday at the right edge**.
   - Header: month name + year, prev/next month buttons (arrows flip under RTL), year selector dropdown.
   - Day grid: numbers as buttons. Weekend columns tinted (Friday always; Thursday per config passed via `data-weekend-days` or the i18n JSON block).
   - "امروز" (Today) button.
   - Footer with selected date display.
3. **Interaction**:
   - Click/focus on input opens popup. Esc closes. Click outside closes.
   - Arrow keys move focused day. Enter/Space selects.
   - Selecting a day writes `YYYY/MM/DD` into the input (Persian digits if `data-persian-digits="1"`).
   - Emits native `change` event on the input.
   - Typing a date directly is also allowed.
4. **Optional** `data-min` / `data-max` (Jalali strings) to grey out / reject out-of-range dates.
5. **Accessibility**: `role="dialog"`, `aria-label` on day buttons, focus returns to input on close.
6. ~250 lines target. No framework, no npm.
7. Initialise automatically: `document.querySelectorAll('[data-jalali-datepicker]').forEach(init)`.

**Acceptance criteria**
- Popup renders RTL with Saturday at right.
- Friday column is visually distinct.
- Selecting 31 Esfand 1404 is rejected (non-leap).
- `change` event fires on selection.
- Focus management works (Esc → focus back to input).

---

### Task 11 · `submit-overtime.js` — Submit Page Behaviour

**Files to create**
```
public/assets/js/pages/submit-overtime.js
```

**Spec sections:** §9.2 (client behaviour table), §5.2, §7.5, §7.1

**Dependencies:** Task 8, Task 9, Task 10

**Instructions**
1. ES module. Imports from `../lib/normalize.js`, `../lib/jalali.js`, `../lib/digits.js`.
2. Read i18n strings from `<script type="application/json" id="i18n">`.
3. **Division filter**: hide/show `<tr>` by `data-division-id`. "همه واحدها" shows all. Combines with search.
4. **Search**: normalise both query and row text via `normalizeText`. Match on name OR personnel code. `۱۰۲۳۴` matches `10234`.
5. **Row state / disabling**:
   - Read the selected type's `data-uses-cycle` and `data-day-rule`.
   - Disable checkbox if `!data-own` OR (`uses_cycle` AND `data-used`).
   - Un-tick and mute disabled rows.
   - Status column text: `فقط مشاهده` for other divisions; `انجام‌شده در دور N` / `آزاد` for own when cycle applies; `—` otherwise.
   - Re-evaluate on every type `<select>` change.
6. **Header checkbox**: select all visible + enabled. Indeterminate state.
7. **Selection counter**: `N نفر انتخاب شده (M مخفی)` in the `aria-live` region.
8. **Weekday label**: on date change, convert Jalali → Gregorian → show Persian weekday name.
9. **Day-rule check**: on type or date change:
   - `workday` + weekend day → show `err_day_workday` with weekday name.
   - `weekend` + non-weekend → show `err_day_weekend`.
   - `any` → no check.
   - Weekend days read from i18n JSON.
10. **Submit button state**: disabled when any of: nothing selected, date empty/invalid/out-of-window, hours empty/invalid/over cap, type/date mismatch. Also disabled after click (prevent double-submit).
11. **Default date**: fill with today (Jalali) if empty on load.
12. No `innerHTML` with data. Use `textContent`.

**Acceptance criteria**
- Switching type to "Weekend" disables all weekday-used rows correctly.
- Searching `علي` finds `علی` (normalisation).
- Day-rule message appears/disappears reactively.
- Submit button is disabled until all conditions met.

---

### Task 12 · `reports.js` — Reports Page Behaviour

**Files to create**
```
public/assets/js/pages/reports.js
```

**Spec sections:** §9.3, §9.4

**Dependencies:** Task 10

**Instructions**
1. ES module.
2. Initialise Jalali date pickers on the From/To filter inputs (import `datepicker.js`).
3. **From/To pairing**: From's `data-max` = To's value; To's `data-min` = From's value. Update dynamically.
4. **Delete dialog**:
   - Click any `[data-entry-id]` delete button → open `<dialog id="delete-dialog">`.
   - Fill summary: name, date (Jalali), type, hours.
   - Set hidden `entry_id` value.
   - Set hidden `back` value to `window.location.href` (must start with `/reports`).
   - Cancel button closes dialog.
   - Confirm submits the form.
5. No inline handlers. Event delegation on the table body.

**Acceptance criteria**
- Dialog shows correct row data.
- Cancel closes without submitting.
- `back` field is populated with current URL.
- Date pickers enforce From ≤ To.

---

## Phase 3 — Backend Foundation

---

### Task 13 · `.env.example`, `Config.php`, `bootstrap.php`, `helpers.php`

**Files to create**
```
.env.example
src/Core/Config.php
src/bootstrap.php
src/helpers.php
```

**Spec sections:** §12, §3.2, §4.1, §4.2, §7.1, §14

**Instructions**

**`.env.example`**: replicate the full `.env` block from §12 with all keys and safe defaults. Comment each section.

**`Config.php`** (namespace `App\Core`):
- `load(string $envPath)`: use `parse_ini_file($path, false, INI_SCANNER_RAW)`. Fail fast if missing.
- Merge with `config/app.php` (which reads env values and provides typed accessors).
- Expose: `get(string $key, mixed $default = null)`.

**`config/app.php`**: return an array reading from env with defaults:
```php
'timezone' => 'Asia/Tehran',
'locale' => 'fa',
'persian_digits' => (bool) env('UI_PERSIAN_DIGITS', true),
'weekend_days' => array_map(fn($d) => strtolower(trim($d)), explode(',', env('WEEKEND_DAYS', 'thu,fri'))),
'overtime_max_hours' => 8,
'overtime_hours_step' => 0.25,
'overtime_date_window_days' => 366,
'report_page_size' => 50,
'session_idle_minutes' => 30,
'session_absolute_hours' => 8,
'login_window_minutes' => 15,
'login_max_user_ip' => 5,
'login_max_ip' => 20,
```

**`bootstrap.php`**:
1. Check required extensions: `pdo_mysql`, `intl`, `mbstring`, `PASSWORD_ARGON2ID` defined. Fail fast with clear message.
2. `spl_autoload_register` mapping `App\` → `src/` (PSR-4 style).
3. Require `helpers.php`.
4. Load config from `.env`.
5. `date_default_timezone_set(config('app.timezone'))`.
6. Custom error handler → log to `storage/logs/app.log`, show generic 500 in production.
7. `declare(strict_types=1)` at top of every file.

**`helpers.php`**:
- `e(string $s): string` → `htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')`.
- `t(string $key, array $replacements = []): string` → lookup in `lang/fa.php`, `str_replace` placeholders.
- `num(string|int|float $n): string` → if `persian_digits` config, `strtr` Latin→Persian digits; else return as-is.
- `url(string $path): string`.
- `asset(string $path): string` → append `?v=filemtime()`.
- `old(string $key, string $default = ''): string` → from flash old input.
- `csrf_field(): string` → `<input type="hidden" name="csrf_token" value="…">`.
- `flash(string $type, string $msg): void`.

**Acceptance criteria**
- `require 'src/bootstrap.php'` boots without errors when `.env` exists.
- Missing extension → clear error message naming the extension.
- `t('app_name')` returns `مدیریت اضافه‌کاری`.
- `num(1405)` returns `۱۴۰۵` when Persian digits enabled.

---

### Task 14 · Database Schema (`database/schema.sql`)

**Files to create**
```
database/schema.sql
```

**Spec sections:** §6.1, §6.2, §6.4

**Instructions**
1. Reproduce the **exact** schema from §6.2. All tables:
   - `divisions`, `overtime_types`, `users`, `login_attempts`, `personnel`, `cycles`, `overtime_entries`, `audit_log`.
2. Key details to preserve:
   - `cycles.open_marker` generated column: `TINYINT(1) GENERATED ALWAYS AS (IF(closed_at IS NULL, 1, NULL)) STORED`.
   - `UNIQUE KEY uq_cycles_one_open_per_division (division_id, open_marker)`.
   - `UNIQUE KEY uq_entries_cycle_personnel (cycle_id, personnel_id)`.
   - `CHECK (hours > 0 AND hours <= 24)` on `overtime_entries`.
   - All foreign keys.
   - `utf8mb4`, InnoDB everywhere.
   - Indexes as specified (`idx_personnel_division_active`, `idx_entries_date`, `idx_entries_personnel_date`, `idx_attempts_user_ip_time`, `idx_attempts_ip_time`, `idx_audit_created`).
3. `SET NAMES utf8mb4;` at top.

**Acceptance criteria**
- Schema applies cleanly on MySQL 8.4+ / 9.7.
- The generated column + unique key correctly prevents two open cycles per division.
- `overtime_entries.hours` CHECK constraint rejects 0 and >24.

---

### Task 15 · Seed Data + Dev Sample Data

**Files to create**
```
database/seed.sql
database/dev_sample_data.sql
```

**Spec sections:** §6.3

**Dependencies:** Task 14

**Instructions**

**`seed.sql`**:
- Insert 3 divisions (exact Persian names from §6.3).
- Insert 3 overtime types (exact codes, names, `uses_cycle`, `day_rule`, `sort_order` from §6.3).
- Insert cycle 1 (open) for every division via `INSERT … SELECT`.

**`dev_sample_data.sql`** (local dev only, clearly commented):
- 2–3 fake personnel per division with Persian names and codes.
- 1 dev admin per division with a known bcrypt/argon2 hash (comment the plaintext password).
- Must reference correct division IDs.

**Acceptance criteria**
- Running `schema.sql` then `seed.sql` produces a usable database.
- Every division has exactly one open cycle.
- Dev sample is clearly marked as non-production.

---

### Task 16 · Core Framework: `Router`, `Request`, `Response`, `View`

**Files to create**
```
src/Core/Router.php
src/Core/Request.php
src/Core/Response.php
src/Core/View.php
```

**Spec sections:** §4.1, §4.2, §4.3, §10

**Instructions**

**`Router.php`**:
- Array-based, exact path matching (no regex, no path parameters).
- `add(string $method, string $path, callable|array $handler, array $middleware = [])`.
- `dispatch(Request $request): Response`.
- Unknown route → 404. Wrong method → 405.
- Route table loaded from `config/routes.php`.

**`Request.php`**:
- Typed access to `$_GET`, `$_POST`, `$_SERVER`.
- `method()`, `path()`, `query(key, default)`, `input(key, default)`, `ip()`.
- `setUser(User $user)` / `user(): ?User` — holds the current user loaded by middleware.
- `all(): array` for old input preservation.

**`Response.php`**:
- `html(string $body, int $status = 200): static`.
- `redirect(string $url, int $status = 302): static`.
- `csv(string $filename, callable $writer): static` — sets headers, BOM, streams.
- `send(): void`.

**`View.php`**:
- `render(string $template, array $data = []): string`.
- Wraps in `templates/layout.php`.
- Extracts `$data` into template scope.
- `renderPartial(string $partial, array $data = []): string`.

**Acceptance criteria**
- Router dispatches exact paths only.
- Request never exposes raw superglobals to services.
- View renders layout + template + flash.

---

### Task 17 · `Session.php`, `Csrf.php`, `Database.php`

**Files to create**
```
src/Core/Session.php
src/Core/Csrf.php
src/Core/Database.php
```

**Spec sections:** §8.4, §8.5, §3.2, §12

**Instructions**

**`Session.php`**:
- `start()`: configure `session.cookie_httponly`, `session.cookie_secure` (from config), `session.cookie_samesite = 'Lax'`, `session.use_strict_mode = 1`, `session.use_only_cookies = 1`, cookie name from env, save path `storage/sessions/`.
- `get/set/delete/has`.
- `flash(type, msg)` / `getFlash(type)`.
- `regenerate()`.
- `destroy()`.
- `userId(): ?int`, `setUserId(int)`, `createdAt()`, `lastActivity()`.

**`Csrf.php`**:
- `token(): string` — per-session, `bin2hex(random_bytes(32))`.
- `validate(string $token): bool` — `hash_equals`.
- `generateFormNonce(): string` — one-time nonce stored in session.
- `consumeFormNonce(string $nonce): bool` — validate + delete.
- `field(): string` — returns hidden input HTML.

**`Database.php`**:
- `connect(): PDO` using config values.
- `PDO::ERRMODE_EXCEPTION`, `PDO::ATTR_EMULATE_PREPARES => false`, `PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC`.
- `SET time_zone = '+00:00'` after connect.
- `SET NAMES utf8mb4`.

**Acceptance criteria**
- Session cookie is `HttpOnly`, `Secure` (in prod), `SameSite=Lax`.
- CSRF token is 64 hex chars.
- Form nonce is consumed (single-use).
- PDO uses real prepared statements.

---

## Phase 4 — Middleware & Authentication

---

### Task 18 · Middleware Pipeline

**Files to create**
```
src/Http/Middleware/SecurityHeaders.php
src/Http/Middleware/SessionTimeout.php
src/Http/Middleware/RequireAuth.php
src/Http/Middleware/CsrfGuard.php
```

**Spec sections:** §4.1, §8.4, §8.5, §8.7

**Dependencies:** Task 16, Task 17

**Instructions**
Each middleware: `handle(Request $request, callable $next): Response`.

**`SecurityHeaders`** (all responses):
- Set the exact CSP from §8.7: `default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'`.
- `X-Content-Type-Options: nosniff`.
- `X-Frame-Options: DENY`.
- `Referrer-Policy: same-origin`.
- `Strict-Transport-Security: max-age=31536000` (HTTPS only).
- `Cache-Control: no-store` on authenticated pages.

**`SessionTimeout`**:
- Check idle timeout (30 min) and absolute timeout (8 h) from session.
- Expired → destroy session, redirect to `/login`.
- Update `last_activity`.

**`RequireAuth`**:
- No session user → redirect to `/login` (store intended path if local, starts with `/`, not `//`).
- Load user from DB by `users.id` **every request** (per §8.4).
- User inactive → destroy session, redirect to login.
- Set `$request->setUser($user)`.

**`CsrfGuard`** (POST only):
- Validate `csrf_token` via `hash_equals`.
- Failure → 403 with Persian "session expired" page.

**Acceptance criteria**
- Unauthenticated access to `/overtime/new` redirects to `/login`.
- Deactivated user is rejected on next request.
- POST without valid CSRF → 403.
- All security headers present on every response.

---

### Task 19 · Auth Service, Repository & Controller

**Files to create**
```
src/Services/AuthService.php
src/Repositories/UserRepository.php
src/Repositories/LoginAttemptRepository.php
src/Http/Controllers/AuthController.php
src/Input/LoginInput.php
```

**Spec sections:** §8.1, §8.2, §8.3, §9.1

**Dependencies:** Task 17, Task 18

**Instructions**

**`UserRepository`**: `findByUsername(string)`, `findById(int)`, `updateLastLogin(int)`, `updatePasswordHash(int, string)`.

**`LoginAttemptRepository`**: `record(string $username, string $ip, bool $success)`, `countRecent(string $username, string $ip, int $minutes): int`, `countRecentByIp(string $ip, int $minutes): int`, `clearForUserIp(string $username, string $ip)`, `prune(int $daysOld)`.

**`AuthService`**:
- `attempt(string $username, string $password, string $ip): array{success: bool, user?: array, error?: string}`.
  1. Throttle check (≥5 per user+IP or ≥20 per IP in 15 min).
  2. Look up user by lower-cased username. If missing/inactive, still `password_verify` against dummy hash (timing equalisation).
  3. `password_verify`. Failure → record, return generic error.
  4. Success → `session_regenerate_id(true)`, store `user_id`, `created_at`, `last_activity`. Check `password_needs_rehash` → re-hash. Update `last_login_at`. Clear failed attempts. Return user.
- Hashing: `PASSWORD_ARGON2ID`, `memory_cost=19456`, `time_cost=2`, `threads=1`. Fallback `PASSWORD_DEFAULT`.

**`AuthController`**:
- `showLogin()`: if authenticated → redirect `/overtime/new`. Render login template.
- `login()`: CSRF → validate input → `AuthService::attempt` → success: redirect to intended local path or `/overtime/new`. Failure: re-render with generic error (422).
- `logout()`: CSRF → clear session, destroy, redirect to `/login`.

**`LoginInput`**: validate username (required, ≤64) and password (required, ≤128).

**Acceptance criteria**
- 5 failed logins from same user+IP → throttle message.
- Unknown username and wrong password produce identical error and similar timing.
- Session ID changes on successful login.
- Post-login redirect only to local paths (starts with single `/`, not `//`).

---

## Phase 5 — Domain Support (PHP)

---

### Task 20 · `JalaliDate.php` — Server-Side Solar Hijri

**Files to create**
```
src/Support/JalaliDate.php
```

**Spec sections:** §7.2, §3.2

**Dependencies:** Task 13

**Instructions**
1. Namespace `App\Support`. `declare(strict_types=1)`.
2. Methods (exact signatures from §7.2):
   - `normalizeDigits(string $s): string` — Persian ۰-۹ and Arabic-Indic ٠-٩ → Latin.
   - `toGregorian(string $jalali): ?string` — `'1405/07/11'` → `'2026-10-03'` or `null`.
   - `fromGregorian(string $iso, bool $persianDigits = false): string`.
   - `weekdayName(string $iso): string` — Persian weekday via `IntlDateFormatter` pattern `EEEE`.
   - `isWeekendDay(string $iso, array $weekendDays): bool` — ISO weekday `format('N')` in config list.
   - `today(): string` — today as Jalali in `Asia/Tehran`.
3. **IntlDateFormatter** must use `IntlDateFormatter::TRADITIONAL` (see §7.2 comment).
4. **Strict validation**: after converting Jalali→Gregorian, convert back and require exact match. Reject `1405/07/31`, `1404/12/30` (non-leap).
5. Input regex after digit normalisation: `^\d{4}[/-]\d{1,2}[/-]\d{1,2}$`.
6. `IntlCalendar` month is 0-based.

**Acceptance criteria**
- `toGregorian('1405/07/11')` returns `'2026-10-03'`.
- `fromGregorian('2026-10-03')` returns `'1405/07/11'`.
- `toGregorian('1405/07/31')` returns `null` (invalid).
- `toGregorian('1404/12/30')` returns `null` (non-leap).
- `toGregorian('1403/12/30')` returns a valid date (leap year).
- `isWeekendDay('2026-10-03', ['thu','fri'])` → `false` (Saturday).
- `isWeekendDay('2026-10-08', ['thu','fri'])` → `true` (Thursday).

---

### Task 21 · `TextNormalizer.php` + `Validator.php`

**Files to create**
```
src/Support/TextNormalizer.php
src/Support/Validator.php
```

**Spec sections:** §7.5, §9.2

**Dependencies:** Task 13

**Instructions**

**`TextNormalizer`**:
- `normalize(string $s): string` — identical rules to `normalize.js` (Task 8):
  1. Arabic `ي` → `ی`, Arabic `ك` → `ک`.
  2. Persian/Arabic-Indic digits → Latin.
  3. Remove ZWNJ, tatweel, Arabic diacritics.
  4. Collapse whitespace, trim, lower-case Latin.
- `normalizePersonnelCode(string $code): string` — trim, validate `^[0-9A-Za-z]+$`.

**`Validator`** (static helpers):
- `required(mixed $v): bool`.
- `intRange(int $v, int $min, int $max): bool`.
- `strLength(string $s, int $max): bool` (uses `mb_strlen`).
- `inArray(mixed $v, array $allowed): bool`.
- `isDecimalStep(string $v, float $step): bool` — for 0.25 h step.
- `jalaliDate(string $s): bool` — format check only (real validation in `JalaliDate`).

**Acceptance criteria**
- `TextNormalizer::normalize('علی‌رضا')` === `TextNormalizer::normalize('علي رضا')`.
- Validator correctly rejects hours not on 0.25 step.

---

### Task 22 · Input DTOs

**Files to create**
```
src/Input/OvertimeSubmission.php
src/Input/DeleteEntryInput.php
src/Input/ReportFilter.php
```

**Spec sections:** §9.2, §9.3, §9.4, §5.2

**Dependencies:** Task 20, Task 21

**Instructions**

**`OvertimeSubmission`**:
- `fromPost(array $post, array $config): self`.
- Fields: `type_id` (int, required), `date` (Jalali string), `hours` (string), `description` (?string), `personnel_ids` (array).
- `validate(): array` → list of error strings. Rules:
  - `type_id`: required, must exist (checked by service).
  - `date`: required, valid Jalali (via `JalaliDate::toGregorian`), within ±366 days of today.
  - `hours`: required, numeric after digit/decimal normalisation, 0.25 ≤ h ≤ 8, multiple of 0.25.
  - `description`: optional, trimmed, ≤255 `mb_strlen`, strip control chars, empty → `null`.
  - `personnel_ids`: 1–500 items, all integers, deduplicated.

**`DeleteEntryInput`**: `entry_id` (int, required), `back` (string, must start with `/reports`).

**`ReportFilter`**:
- `fromQuery(array $query): self`.
- Fields: `from`, `to`, `division_id`, `type_id`, `q`, `page`.
- Validate each per §9.3 rules. `to` ≥ `from` if both set. `q` ≤ 100 chars, normalised.
- `toSqlConditions(): array{where: string, params: array}` — whitelist approach.

**Acceptance criteria**
- Hours `۲٫۵` (Persian) validates correctly.
- Date `1405/07/31` fails validation.
- Report filter with only `q` set produces correct WHERE clause.
- `back` URL not starting with `/reports` is rejected.

---

## Phase 6 — Repositories

---

### Task 23 · All Repository Classes

**Files to create**
```
src/Repositories/PersonnelRepository.php
src/Repositories/OvertimeRepository.php
src/Repositories/CycleRepository.php
src/Repositories/AuditLogRepository.php
src/Repositories/LookupRepository.php
```

**Spec sections:** §6.5, §5.4, §5.5, §9.3

**Dependencies:** Task 17 (Database), Task 14 (schema)

**Instructions**
All repositories receive `PDO` via constructor. **Parameterised queries only.** No business logic.

**`LookupRepository`**: `divisions(): array`, `overtimeTypes(): array`.

**`PersonnelRepository`**:
- `activeWithCycleStatus(): array` — the §6.5 query with `EXISTS` subquery. Returns all active personnel with `used_in_open_cycle`.
- `findByIds(array $ids): array`.
- `activeByDivision(int $divisionId): array`.

**`CycleRepository`**:
- `openCycleForUpdate(int $divisionId): ?array` — `SELECT … WHERE division_id = :div AND closed_at IS NULL FOR UPDATE`.
- `closeCycle(int $cycleId): void`.
- `openNextCycle(int $divisionId, int $nextNumber): int` — INSERT, return new id.
- `deleteCycle(int $cycleId): void`.
- `reopenCycle(int $cycleId): void` — `SET closed_at = NULL`.
- `mostRecentClosedCycle(int $divisionId): ?array`.
- `summaryStrip(): array` — the cycle summary query from §6.5.
- `remainingCount(int $divisionId, int $cycleId): int` — active personnel with no entry in cycle.

**`OvertimeRepository`**:
- `insertBatch(array $rows): void` — one INSERT per row in loop.
- `existingInCycle(int $cycleId, array $personnelIds): array`.
- `findById(int $id): ?array`.
- `delete(int $id): void`.
- `filteredQuery(ReportFilter $f, bool $paginated): array` — the §6.5 report query.
- `filteredTotals(ReportFilter $f): array{count: int, hours: float}`.
- `streamForCsv(ReportFilter $f): \Generator` — unbuffered query for CSV.

**`AuditLogRepository`**: `log(int $userId, string $action, ?int $entityId, array $details, string $ip): void`.

**Acceptance criteria**
- No string concatenation in SQL. All parameters bound.
- `openCycleForUpdate` uses `FOR UPDATE`.
- Report query supports all optional filters via AND.
- CSV streaming uses unbuffered PDO.

---

## Phase 7 — Business Services

---

### Task 24 · `AccessPolicy.php`

**Files to create**
```
src/Services/AccessPolicy.php
```

**Spec sections:** §8.6

**Dependencies:** Task 13

**Instructions**
1. Single class, stateless.
2. `canSubmitFor(array $user, int $divisionId): bool` → `$user['division_id'] === $divisionId`.
3. `canDelete(array $user, array $entry): bool` → `$user['division_id'] === $entry['division_id']`.
4. Both compare against `user.division_id` loaded from DB in current request.
5. No other role checks in MVP.

**Acceptance criteria**
- Returns `false` for cross-division access.
- No hardcoded division IDs.

---

### Task 25 · `CycleService.php`

**Files to create**
```
src/Services/CycleService.php
```

**Spec sections:** §5.1, §5.3, §5.4

**Dependencies:** Task 23

**Instructions**
1. `open(int $divisionId, PDO $pdo): array` — **must be called as first statement in transaction**:
   - `SELECT … FOR UPDATE` on the division's open cycle.
   - **Lazy close/open**: if the open cycle has ≥1 entries AND 0 remaining active personnel → close it, open next (`cycle_number + 1`).
   - Return `['id' => …, 'cycle_number' => …]`.
2. `summaryStrip(): array` — delegates to `CycleRepository`.
3. `checkAndClose(int $divisionId, int $cycleId, PDO $pdo): ?int` — after insert, count remaining. If 0 → close cycle, open next. Return new cycle number or null.
4. All operations assume caller already holds the transaction.

**Acceptance criteria**
- Lazy close works: deactivate last person → next page load closes cycle.
- `FOR UPDATE` is the first SQL in the transaction.
- Two concurrent submits serialise correctly.

---

### Task 26 · `OvertimeService.php` — Submit + Delete

**Files to create**
```
src/Services/OvertimeService.php
```

**Spec sections:** §5.4, §5.5, §8.6, §9.2, §9.4

**Dependencies:** Task 23, Task 24, Task 25, Task 20, Task 22

**Instructions**

**`submitBatch(OvertimeSubmission $input, array $user, array $type): array`**
Follow §5.4 exactly:
1. Division from `$user['division_id']`, **never** from form.
2. Validate day rule: `JalaliDate::isWeekendDay()` against `$type['day_rule']`.
3. `BEGIN`.
4. If `$type['uses_cycle']`:
   a. `$cycle = CycleService::open($divisionId, $pdo)` (FOR UPDATE first).
   b. Check existing entries in cycle for submitted personnel. Any → ROLLBACK, error listing names.
   c. Set `$cycleId`.
   Else `$cycleId = null`.
5. Verify all personnel exist, active, and in user's division. Mismatch → ROLLBACK, 403 + security log.
6. INSERT one row per person.
7. If uses_cycle: check remaining, close/open if needed.
8. COMMIT.
9. Catch SQLSTATE 23000 / errno 1062 → friendly duplicate message.
10. Return `['success' => true, 'count' => N, 'cycleClosed' => bool, 'newCycleNumber' => ?int]`.

**`deleteEntry(int $entryId, array $user): array`**
Follow §5.5 exactly:
1. `BEGIN`.
2. Lock open cycle for user's division (`FOR UPDATE`).
3. Load entry by id (`FOR UPDATE`). Not found → ROLLBACK. Wrong division → ROLLBACK, 403.
4. DELETE.
5. If entry had `cycle_id` and it's a **closed** cycle:
   - If it's the most recent closed cycle AND open cycle has 0 entries → delete empty open cycle, re-open previous.
   - Else: no cycle change.
6. INSERT `audit_log` with full JSON snapshot.
7. COMMIT.
8. Return `['success' => true, 'cycleReopened' => bool, 'reopenedNumber' => ?int]`.

**Acceptance criteria**
- Submit for another division's personnel → 403.
- Duplicate in cycle → friendly error with names.
- Delete from most-recent closed cycle with empty open cycle → cycle re-opens.
- Audit log row created on every delete.

---

### Task 27 · `ReportService.php` + `CsvExporter.php`

**Files to create**
```
src/Services/ReportService.php
src/Services/CsvExporter.php
```

**Spec sections:** §9.3, §9.5, §6.5

**Dependencies:** Task 23, Task 22, Task 20

**Instructions**

**`ReportService`**:
- `query(ReportFilter $f, int $page, int $pageSize): array` — rows + pagination meta.
- `totals(ReportFilter $f): array{count: int, hours: float}`.
- `stream(ReportFilter $f): \Generator` — for CSV.

**`CsvExporter`**:
- `export(ReportFilter $f, string $todayJalali): Response`.
- Headers: `Content-Type: text/csv; charset=utf-8`, `Content-Disposition: attachment; filename="overtime-report-{jalali}.csv"`.
- Write UTF-8 BOM (`\xEF\xBB\xBF`).
- Columns: تاریخ, کد پرسنلی, نام و نام خانوادگی, واحد, نوع اضافه‌کاری, ساعت, دور, توضیحات.
- Date: Jalali `YYYY/MM/DD` Latin digits.
- Hours: dot decimal, Latin digits.
- Cycle: number or empty.
- **Injection guard**: prefix cells starting with `=`, `+`, `-`, `@`, tab, CR with `'`.
- `fputcsv($out, $row, ',', '"', '')` — explicit escape arg.
- Stream from unbuffered PDO to `php://output`.

**Acceptance criteria**
- CSV opens in Excel with correct Persian text (BOM present).
- Formula `=1+1` in description exports as `'=1+1`.
- Exported rows match the on-screen filtered result exactly.
- No pagination in CSV.

---

## Phase 8 — Controllers, Routing & Front Controller

---

### Task 28 · `OvertimeController` + `ReportController`

**Files to create**
```
src/Http/Controllers/OvertimeController.php
src/Http/Controllers/ReportController.php
```

**Spec sections:** §9.2, §9.3, §9.4, §9.5, §4.2, §10

**Dependencies:** Task 26, Task 27, Task 24, Task 16

**Instructions**

**`OvertimeController`**:
- `create(Request $req): Response` — GET `/overtime/new`. Load types, divisions, personnel with cycle status, cycle summary strip. Render template. Generate `form_nonce`.
- `store(Request $req): Response` — POST `/overtime`. CSRF → consume `form_nonce` → `OvertimeSubmission::fromPost` → validate → `OvertimeService::submitBatch`. Success: flash + redirect (PRG). Validation error: re-render 422 with old input. Business error: re-render with names. Tampering: 403.
- `delete(Request $req): Response` — POST `/overtime/delete`. CSRF → `DeleteEntryInput` → `OvertimeService::deleteEntry`. Success: flash + redirect to `back`. Error: 403 or 404.

**`ReportController`**:
- `index(Request $req): Response` — GET `/reports`. `ReportFilter::fromQuery` → validate → `ReportService::query` + totals. Render with pagination.
- `export(Request $req): Response` — GET `/reports/export`. Same filter → `CsvExporter::export`.

**Controllers must NOT contain SQL or business rules.** They build DTOs, call services, choose view/redirect.

**Acceptance criteria**
- POST `/overtime` with forged division personnel → 403.
- Double-submit (back + resubmit) rejected by `form_nonce`.
- Report page shows all divisions for all admins.
- Delete button only rendered for own-division rows.

---

### Task 29 · Route Table + Front Controller (`public/index.php`)

**Files to create**
```
config/routes.php
public/index.php
```

**Spec sections:** §4.1, §4.3, §10

**Dependencies:** Task 16, Task 18, Task 28, Task 19

**Instructions**

**`config/routes.php`**: return array matching §10 route table:

| Method | Path | Controller | Middleware |
|--------|------|-----------|------------|
| GET | `/` | redirect | — |
| GET | `/login` | AuthController::showLogin | (public) |
| POST | `/login` | AuthController::login | CsrfGuard |
| POST | `/logout` | AuthController::logout | RequireAuth, CsrfGuard |
| GET | `/overtime/new` | OvertimeController::create | RequireAuth |
| POST | `/overtime` | OvertimeController::store | RequireAuth, CsrfGuard |
| POST | `/overtime/delete` | OvertimeController::delete | RequireAuth, CsrfGuard |
| GET | `/reports` | ReportController::index | RequireAuth |
| GET | `/reports/export` | ReportController::export | RequireAuth |

Default-deny: everything behind `RequireAuth` unless marked public.

**`public/index.php`**:
1. `declare(strict_types=1)`.
2. `require '../src/bootstrap.php'`.
3. Start session.
4. Build `Request`.
5. Run middleware pipeline → controller.
6. Send `Response`.
7. Catch uncaught exceptions → log + generic 500.

**Acceptance criteria**
- Unknown path → 404.
- Wrong method → 405.
- `/` redirects to `/overtime/new` (authenticated) or `/login`.
- All routes wired correctly.

---

## Phase 9 — CLI Tools

---

### Task 30 · `bin/create-user.php`

**Files to create**
```
bin/create-user.php
```

**Spec sections:** §8.2, §11

**Dependencies:** Task 14, Task 17

**Instructions**
1. Usage: `php bin/create-user.php <username> --division=<id|name> [--name="…"]`.
2. `--reset-password` flag updates an existing user's password.
3. Prompt for password twice (hidden input via `stty -echo` / `readline`). Never as CLI argument.
4. Enforce ≥ 12 characters, ≤ 128, any characters.
5. Hash with `PASSWORD_ARGON2ID` (same params as `AuthService`).
6. Validate division exists (by id or name).
7. Reject duplicate username.
8. Success message with username and division.

**Acceptance criteria**
- Password never appears in process list or logs.
- Division validated against DB.
- `--reset-password` works for existing users.

---

### Task 31 · `bin/personnel.php`

**Files to create**
```
bin/personnel.php
```

**Spec sections:** §11, §7.5, §6.4

**Dependencies:** Task 14, Task 17, Task 21

**Instructions**
Subcommands:
- `add --code=<code> --name="<name>" --division=<id>`: validate code (`^[0-9A-Za-z]+$`), normalise name, fill `name_search` via `TextNormalizer::normalize`. Reject duplicate code.
- `deactivate <code>` / `activate <code>`: toggle `is_active`.
- `move <code> --division=<id>`: change division. Old entries keep snapshot.
- `list [--division=<id>] [--all]`: display table.
- `rebuild-search`: recompute `name_search` for all rows.
All output to stdout. Errors to stderr with non-zero exit.

**Acceptance criteria**
- `name_search` is correctly normalised (ZWNJ removed, ي→ی, ك→ک).
- Personnel code validated.
- Division validated.

---

### Task 32 · `bin/prune-login-attempts.php`

**Files to create**
```
bin/prune-login-attempts.php
```

**Spec sections:** §8.3, §11

**Dependencies:** Task 14, Task 17

**Instructions**
- Delete `login_attempts` rows older than 7 days.
- Output count of deleted rows.
- Suitable for daily cron.

**Acceptance criteria**
- Only old rows deleted.
- Exit code 0 on success.

---

## Phase 10 — Deployment & Documentation

---

### Task 33 · Nginx Config, README, Final Checklist

**Files to create**
```
README.md
deploy/nginx.conf.example
```

**Spec sections:** §15, §9.5 (Excel notes), §8.7, §16

**Instructions**

**`deploy/nginx.conf.example`**: reproduce the Nginx sketch from §15. Comment each block.

**`README.md`**:
1. **Setup**: PHP 8.5, MySQL 9.7/8.4, required extensions.
2. **First install** steps (from §15): create DB, run schema + seed, `.env`, create users, add personnel, build CSS, set permissions.
3. **Tailwind build**: dev (`--watch`) and release (`--minify`).
4. **CLI usage**: `create-user.php`, `personnel.php`, `prune-login-attempts.php`.
5. **Cron**: daily prune, nightly `mysqldump`.
6. **Excel notes**: BOM, leading zeros → `="0123"` trick, `;` separator caveat.
7. **Security checklist** summary from §8.7.
8. **Configuration reference**: all `.env` keys.

**Acceptance criteria**
- A fresh install following README works without surprises.
- Excel notes are present.
- Nginx config restricts execution to `index.php` only.

---

## Dependency Graph (Summary)

```
Task 1  (skeleton/CSS)
Task 2  (lang/fa.php)
Task 3  (layout)          ← 1, 2
Task 4  (login template)  ← 3
Task 5  (submit template) ← 3, 2
Task 6  (reports template)← 3, 2
Task 7  (error templates) ← 3

Task 8  (digits+normalize.js)
Task 9  (jalali.js)       ← 8
Task 10 (datepicker.js)   ← 8, 9
Task 11 (submit-overtime.js) ← 8, 9, 10
Task 12 (reports.js)      ← 10

Task 13 (.env, Config, bootstrap, helpers)
Task 14 (schema.sql)
Task 15 (seed.sql)        ← 14
Task 16 (Router, Request, Response, View) ← 13
Task 17 (Session, Csrf, Database)         ← 13, 14

Task 18 (Middleware)      ← 16, 17
Task 19 (Auth)            ← 17, 18

Task 20 (JalaliDate.php)  ← 13
Task 21 (TextNormalizer, Validator) ← 13
Task 22 (Input DTOs)      ← 20, 21

Task 23 (Repositories)    ← 17, 14
Task 24 (AccessPolicy)    ← 13
Task 25 (CycleService)    ← 23
Task 26 (OvertimeService) ← 23, 24, 25, 20, 22
Task 27 (ReportService, CsvExporter) ← 23, 22, 20

Task 28 (Controllers)     ← 26, 27, 24, 16
Task 29 (routes, index.php) ← 16, 18, 28, 19

Task 30 (create-user CLI) ← 14, 17
Task 31 (personnel CLI)   ← 14, 17, 21
Task 32 (prune CLI)       ← 14, 17

Task 33 (deploy + README) ← all
```

---

## Suggested Execution Order

| Order | Tasks | Rationale |
|-------|-------|-----------|
| 1 | 1, 2 | Skeleton + strings — no deps |
| 2 | 3, 4, 5, 6, 7 | All templates (parallel-safe after 3) |
| 3 | 8, 9, 10, 11, 12 | All JS (sequential within, parallel with backend) |
| 4 | 13, 14, 15 | Backend foundation |
| 5 | 16, 17 | Core framework |
| 6 | 18, 19 | Middleware + Auth |
| 7 | 20, 21, 22 | Domain support |
| 8 | 23, 24 | Repositories + policy |
| 9 | 25, 26, 27 | Business services |
| 10 | 28, 29 | Controllers + wiring |
| 11 | 30, 31, 32 | CLI tools |
| 12 | 33 | Deployment + docs |

> **Parallelism note:** Tasks within the same row that have no mutual dependency can be given to separate LLM sessions simultaneously. For example, Tasks 4–7 are independent once Task 3 is done. Tasks 8–12 (JS) can run in parallel with Tasks 13–17 (backend foundation).
