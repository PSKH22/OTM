<?php
/**
 * Reports page. Receives:
 *   array  $filter        current raw filter values: from, to, division_id, type_id, q
 *   array  $divisions, $types
 *   array  $rows          each: id, date_jalali, personnel_code, full_name, division,
 *                         division_id, type, hours, cycle_number, description
 *   array  $totals        count, hours (whole filtered set)
 *   array  $pagination    page, totalPages
 *   array  $queryBase     filter params for pagination links
 *   int    $userDivisionId
 *   array  $errors        field => message
 */
$errors = $errors ?? [];
$fieldClass = 'block min-h-11 w-full rounded-lg border px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-500/40';
$fieldOk    = 'border-slate-300 focus:border-sky-500';
$fieldErr   = 'border-red-400 focus:border-red-500';
?>
<div class="space-y-6">
  <h1 class="text-xl font-bold text-slate-900"><?= e(t('nav_reports')) ?></h1>

  <form method="get" action="<?= e(url('/reports')) ?>"
        class="grid grid-cols-1 gap-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:grid-cols-2 lg:grid-cols-3">
    <div>
      <label for="from" class="mb-1 block text-sm font-medium text-slate-700"><?= e(t('from_date')) ?></label>
      <input type="text" id="from" name="from" data-jalali-datepicker dir="ltr" inputmode="numeric" autocomplete="off"
             value="<?= e($filter['from'] ?? '') ?>"
             class="<?= $fieldClass ?> <?= isset($errors['from']) ? $fieldErr : $fieldOk ?>">
      <?php if (isset($errors['from'])): ?><p class="mt-1 text-xs text-red-600"><?= e($errors['from']) ?></p><?php endif; ?>
    </div>

    <div>
      <label for="to" class="mb-1 block text-sm font-medium text-slate-700"><?= e(t('to_date')) ?></label>
      <input type="text" id="to" name="to" data-jalali-datepicker dir="ltr" inputmode="numeric" autocomplete="off"
             value="<?= e($filter['to'] ?? '') ?>"
             class="<?= $fieldClass ?> <?= isset($errors['to']) ? $fieldErr : $fieldOk ?>">
      <?php if (isset($errors['to'])): ?><p class="mt-1 text-xs text-red-600"><?= e($errors['to']) ?></p><?php endif; ?>
    </div>

    <div>
      <label for="division_id" class="mb-1 block text-sm font-medium text-slate-700"><?= e(t('division')) ?></label>
      <select id="division_id" name="division_id" class="<?= $fieldClass ?> <?= isset($errors['division_id']) ? $fieldErr : $fieldOk ?>">
        <option value=""><?= e(t('all_divisions')) ?></option>
        <?php foreach ($divisions as $d): ?>
        <option value="<?= (int) $d['id'] ?>" <?php if ((string) ($filter['division_id'] ?? '') === (string) $d['id']): ?>selected<?php endif; ?>>
          <?= e($d['name']) ?>
        </option>
        <?php endforeach; ?>
      </select>
      <?php if (isset($errors['division_id'])): ?><p class="mt-1 text-xs text-red-600"><?= e($errors['division_id']) ?></p><?php endif; ?>
    </div>

    <div>
      <label for="type_id" class="mb-1 block text-sm font-medium text-slate-700"><?= e(t('type')) ?></label>
      <select id="type_id" name="type_id" class="<?= $fieldClass ?> <?= isset($errors['type_id']) ? $fieldErr : $fieldOk ?>">
        <option value=""><?= e(t('all_types')) ?></option>
        <?php foreach ($types as $tp): ?>
        <option value="<?= (int) $tp['id'] ?>" <?php if ((string) ($filter['type_id'] ?? '') === (string) $tp['id']): ?>selected<?php endif; ?>>
          <?= e($tp['name']) ?>
        </option>
        <?php endforeach; ?>
      </select>
      <?php if (isset($errors['type_id'])): ?><p class="mt-1 text-xs text-red-600"><?= e($errors['type_id']) ?></p><?php endif; ?>
    </div>

    <div>
      <label for="q" class="mb-1 block text-sm font-medium text-slate-700"><?= e(t('search_placeholder')) ?></label>
      <input type="text" id="q" name="q" maxlength="100" value="<?= e($filter['q'] ?? '') ?>"
             class="<?= $fieldClass ?> <?= isset($errors['q']) ? $fieldErr : $fieldOk ?>">
      <?php if (isset($errors['q'])): ?><p class="mt-1 text-xs text-red-600"><?= e($errors['q']) ?></p><?php endif; ?>
    </div>

    <div class="flex flex-wrap items-end gap-2">
      <button type="submit"
              class="min-h-11 rounded-lg bg-sky-600 px-5 py-2 text-sm font-semibold text-white transition-colors hover:bg-sky-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 focus-visible:ring-offset-2">
        <?= e(t('apply')) ?>
      </button>
      <a href="<?= e(url('/reports')) ?>"
         class="inline-flex min-h-11 items-center rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-100">
        <?= e(t('reset')) ?>
      </a>
      <button type="submit" formaction="<?= e(url('/reports/export')) ?>"
              class="min-h-11 rounded-lg border border-emerald-600 px-4 py-2 text-sm font-semibold text-emerald-700 transition-colors hover:bg-emerald-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2">
        <?= e(t('export_csv')) ?>
      </button>
    </div>
  </form>

  <p class="text-sm text-slate-600">
    <?= e(t('report_summary', ['count' => num($totals['count']), 'hours' => num($totals['hours'])])) ?>
  </p>

  <div class="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm">
    <table class="min-w-full divide-y divide-slate-200 text-sm">
      <thead class="bg-slate-50 text-slate-600">
        <tr>
          <th scope="col" class="px-3 py-3 text-start font-medium"><?= e(t('date')) ?></th>
          <th scope="col" class="px-3 py-3 text-start font-medium"><?= e(t('personnel_id')) ?></th>
          <th scope="col" class="px-3 py-3 text-start font-medium"><?= e(t('name')) ?></th>
          <th scope="col" class="px-3 py-3 text-start font-medium"><?= e(t('division')) ?></th>
          <th scope="col" class="px-3 py-3 text-start font-medium"><?= e(t('type')) ?></th>
          <th scope="col" class="px-3 py-3 text-start font-medium"><?= e(t('hours')) ?></th>
          <th scope="col" class="px-3 py-3 text-start font-medium"><?= e(t('cycle')) ?></th>
          <th scope="col" class="px-3 py-3 text-start font-medium"><?= e(t('description')) ?></th>
          <th scope="col" class="px-3 py-3 text-start font-medium"><span class="sr-only"><?= e(t('actions')) ?></span></th>
        </tr>
      </thead>
      <tbody id="report-body" class="divide-y divide-slate-100">
        <?php if ($rows === []): ?>
        <tr><td colspan="9" class="px-3 py-8 text-center text-slate-500"><?= e(t('no_records')) ?></td></tr>
        <?php endif; ?>
        <?php foreach ($rows as $row):
            $canDelete = (int) $row['division_id'] === $userDivisionId;
            $desc = (string) ($row['description'] ?? '');
            $descShort = mb_strlen($desc) > 40 ? mb_substr($desc, 0, 40) . '…' : $desc;
        ?>
        <tr>
          <td class="px-3 py-2 whitespace-nowrap text-slate-800" dir="ltr"><?= e(num($row['date_jalali'])) ?></td>
          <td class="px-3 py-2 text-slate-600" dir="ltr"><?= e(num($row['personnel_code'])) ?></td>
          <td class="px-3 py-2 font-medium text-slate-800"><?= e($row['full_name']) ?></td>
          <td class="px-3 py-2 text-slate-600"><?= e($row['division']) ?></td>
          <td class="px-3 py-2 text-slate-600"><?= e($row['type']) ?></td>
          <td class="px-3 py-2 text-slate-600" dir="ltr"><?= e(num($row['hours'])) ?></td>
          <td class="px-3 py-2 text-slate-600"><?= $row['cycle_number'] !== null ? e(num($row['cycle_number'])) : '—' ?></td>
          <td class="max-w-48 truncate px-3 py-2 text-slate-600" <?php if ($desc !== ''): ?>title="<?= e($desc) ?>"<?php endif; ?>><?= e($descShort) ?></td>
          <td class="px-3 py-2">
            <?php if ($canDelete): ?>
            <button type="button"
                    data-entry-id="<?= (int) $row['id'] ?>"
                    data-name="<?= e($row['full_name']) ?>"
                    data-date="<?= e(num($row['date_jalali'])) ?>"
                    data-type="<?= e($row['type']) ?>"
                    data-hours="<?= e(num($row['hours'])) ?>"
                    class="min-h-11 rounded-lg border border-red-300 px-3 py-1.5 text-xs font-medium text-red-700 transition-colors hover:bg-red-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500">
              <?= e(t('delete')) ?>
            </button>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <?php include __DIR__ . '/../partials/pagination.php'; ?>
</div>

<?php include __DIR__ . '/../partials/delete_dialog.php'; ?>

<script type="application/json" id="i18n"><?= json_encode([
    'confirm_delete' => t('confirm_delete'),
], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<script type="module" src="<?= e(asset('js/pages/reports.js')) ?>"></script>
