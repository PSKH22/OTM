<?php
/**
 * Submit Overtime page. Receives:
 *   array  $types          overtime types (id, code, name, uses_cycle, day_rule)
 *   array  $divisions      divisions (id, name)
 *   int    $userDivisionId the logged-in admin's division
 *   array  $personnel      active personnel with used_in_open_cycle + division_name
 *   array  $cycleSummary   per-division: division_id, name, cycle_number, done, total_active
 *   array  $errors         field => message key (already translated via t())
 *   array  $old            old input: type_id, date, hours, description, personnel_ids[]
 *   array  $weekendDays    e.g. ['thu','fri']
 *   string $formNonce      one-time form nonce
 *   string $dateMin/$dateMax  Jalali submission window bounds
 *   string $todayJalali    default date
 */
$errors = $errors ?? [];
$old    = $old ?? [];
$oldPersonnel = array_map('intval', (array) ($old['personnel_ids'] ?? []));

$selectedTypeId = (int) ($old['type_id'] ?? ($types[0]['id'] ?? 0));
$selectedType   = null;
foreach ($types as $t) {
    if ((int) $t['id'] === $selectedTypeId) { $selectedType = $t; break; }
}
$selectedType  = $selectedType ?? ($types[0] ?? null);
$usesCycleInit = $selectedType !== null && (int) $selectedType['uses_cycle'] === 1;

$cycleByDivision = [];
foreach ($cycleSummary as $chip) {
    $cycleByDivision[(int) $chip['division_id']] = $chip;
}

$i18n = [
    'err_day_workday'   => t('err_day_workday'),
    'err_day_weekend'   => t('err_day_weekend'),
    'err_hours_max'     => t('err_hours_max', ['max' => num(config('app.overtime_max_hours'))]),
    'selected_count'    => t('selected_count'),
    'selected_count_hidden' => t('selected_count_hidden'),
    'status_available'  => t('status_available'),
    'status_done_cycle' => t('status_done_cycle'),
    'status_locked'     => t('status_locked'),
    'weekend_days'      => array_values($weekendDays),
    'cycle_numbers'     => array_map(
        static fn ($chip) => (int) $chip['cycle_number'],
        array_column($cycleSummary, null, 'division_id'),
    ),
    'persian_digits'    => (bool) config('app.persian_digits'),
    'max_hours'         => (float) config('app.overtime_max_hours'),
    'hours_step'        => (float) config('app.overtime_hours_step'),
    'date_window_days'  => (int) config('app.overtime_date_window_days'),
];

$fieldClass = 'block min-h-11 w-full rounded-lg border px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-500/40';
$fieldOk    = 'border-slate-300 focus:border-sky-500';
$fieldErr   = 'border-red-400 focus:border-red-500';
?>
<div class="space-y-6">
  <h1 class="text-xl font-bold text-slate-900"><?= e(t('nav_submit')) ?></h1>

  <?php if (isset($errors['general'])): ?>
  <div role="alert" class="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"><?= e($errors['general']) ?></div>
  <?php endif; ?>

  <form method="post" action="<?= e(url('/overtime')) ?>" id="overtime-form" class="space-y-6">
    <?= csrf_field() ?>
    <input type="hidden" name="form_nonce" value="<?= e($formNonce) ?>">

    <div class="grid grid-cols-1 gap-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:grid-cols-2 lg:grid-cols-5">
      <div>
        <label for="type_id" class="mb-1 block text-sm font-medium text-slate-700"><?= e(t('type')) ?></label>
        <select id="type_id" name="type_id" class="<?= $fieldClass ?> <?= isset($errors['type_id']) ? $fieldErr : $fieldOk ?>">
          <?php foreach ($types as $t): ?>
          <option value="<?= (int) $t['id'] ?>"
                  data-uses-cycle="<?= (int) $t['uses_cycle'] ?>"
                  data-day-rule="<?= e($t['day_rule']) ?>"
                  <?php if ((int) $t['id'] === $selectedTypeId): ?>selected<?php endif; ?>>
            <?= e($t['name']) ?>
          </option>
          <?php endforeach; ?>
        </select>
        <?php if (isset($errors['type_id'])): ?><p class="mt-1 text-xs text-red-600"><?= e($errors['type_id']) ?></p><?php endif; ?>
      </div>

      <div>
        <label for="division-filter" class="mb-1 block text-sm font-medium text-slate-700"><?= e(t('division')) ?></label>
        <select id="division-filter" class="<?= $fieldClass ?> <?= $fieldOk ?>">
          <option value=""><?= e(t('all_divisions')) ?></option>
          <?php foreach ($divisions as $d): ?>
          <option value="<?= (int) $d['id'] ?>" <?php if ((int) $d['id'] === $userDivisionId): ?>selected<?php endif; ?>>
            <?= e($d['name']) ?>
          </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div>
        <label for="date" class="mb-1 block text-sm font-medium text-slate-700"><?= e(t('date')) ?></label>
        <div class="flex items-center gap-2">
          <input type="text" id="date" name="date" data-jalali-datepicker
                 dir="ltr" autocomplete="off" inputmode="numeric"
                 data-min="<?= e($dateMin) ?>" data-max="<?= e($dateMax) ?>"
                 value="<?= e($old['date'] ?? $todayJalali) ?>"
                 class="<?= $fieldClass ?> <?= isset($errors['date']) ? $fieldErr : $fieldOk ?>">
          <span id="weekday-label" class="shrink-0 text-sm text-slate-500"></span>
        </div>
        <div id="day-rule-msg" aria-live="polite" class="mt-1 text-xs text-amber-700"></div>
        <?php if (isset($errors['date'])): ?><p class="mt-1 text-xs text-red-600"><?= e($errors['date']) ?></p><?php endif; ?>
      </div>

      <div>
        <label for="hours" class="mb-1 block text-sm font-medium text-slate-700"><?= e(t('hours')) ?></label>
        <input type="text" id="hours" name="hours" dir="ltr" inputmode="decimal"
               value="<?= e($old['hours'] ?? '') ?>"
               class="<?= $fieldClass ?> text-end <?= isset($errors['hours']) ? $fieldErr : $fieldOk ?>">
        <?php if (isset($errors['hours'])): ?><p class="mt-1 text-xs text-red-600"><?= e($errors['hours']) ?></p><?php endif; ?>
      </div>

      <div>
        <label for="description" class="mb-1 block text-sm font-medium text-slate-700">
          <?= e(t('description')) ?> <span class="font-normal text-slate-400"><?= e(t('optional')) ?></span>
        </label>
        <input type="text" id="description" name="description" maxlength="255"
               value="<?= e($old['description'] ?? '') ?>"
               class="<?= $fieldClass ?> <?= isset($errors['description']) ? $fieldErr : $fieldOk ?>">
        <?php if (isset($errors['description'])): ?><p class="mt-1 text-xs text-red-600"><?= e($errors['description']) ?></p><?php endif; ?>
      </div>
    </div>

    <div class="flex flex-wrap gap-2" aria-label="<?= e(t('cycle')) ?>">
      <?php foreach ($cycleSummary as $chip): ?>
      <span class="rounded-full border px-3 py-1.5 text-xs font-medium
                   <?= (int) $chip['division_id'] === $userDivisionId
                       ? 'border-sky-300 bg-sky-50 text-sky-900'
                       : 'border-slate-200 bg-white text-slate-600' ?>">
        <?= e(t('cycle_chip', [
            'name'  => $chip['name'],
            'n'     => num($chip['cycle_number']),
            'done'  => num($chip['done']),
            'total' => num($chip['total_active']),
        ])) ?>
      </span>
      <?php endforeach; ?>
    </div>

    <div class="flex flex-wrap items-center gap-3">
      <div class="min-w-56 grow">
        <label for="personnel-search" class="sr-only"><?= e(t('search_placeholder')) ?></label>
        <input type="text" id="personnel-search" placeholder="<?= e(t('search_placeholder')) ?>"
               class="<?= $fieldClass ?> <?= $fieldOk ?>">
      </div>
      <span id="selected-count" aria-live="polite" class="text-sm text-slate-600"></span>
      <button type="submit" id="submit-btn" disabled
              class="min-h-11 rounded-lg bg-sky-600 px-6 py-2 text-sm font-semibold text-white transition-colors hover:bg-sky-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:bg-slate-300">
        <?= e(t('submit')) ?>
      </button>
    </div>
    <?php if (isset($errors['personnel_ids'])): ?><p class="text-xs text-red-600"><?= e($errors['personnel_ids']) ?></p><?php endif; ?>

    <div class="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm">
      <table class="min-w-full divide-y divide-slate-200 text-sm">
        <thead class="bg-slate-50 text-slate-600">
          <tr>
            <th scope="col" class="w-10 px-3 py-3 text-center">
              <input type="checkbox" id="select-all" aria-label="<?= e(t('submit')) ?>"
                     class="size-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500">
            </th>
            <th scope="col" class="px-3 py-3 text-start font-medium"><?= e(t('name')) ?></th>
            <th scope="col" class="px-3 py-3 text-start font-medium"><?= e(t('personnel_id')) ?></th>
            <th scope="col" class="px-3 py-3 text-start font-medium"><?= e(t('division')) ?></th>
            <th scope="col" class="px-3 py-3 text-start font-medium"><?= e(t('status')) ?></th>
          </tr>
        </thead>
        <tbody id="personnel-body" class="divide-y divide-slate-100">
          <?php foreach ($personnel as $p):
              $own  = (int) $p['division_id'] === $userDivisionId;
              $used = (int) $p['used_in_open_cycle'] === 1;
              $disabled = !$own || ($usesCycleInit && $used);
              $cycleNum = $cycleByDivision[(int) $p['division_id']]['cycle_number'] ?? null;
              if (!$own) {
                  $statusText = t('status_locked');
              } elseif ($usesCycleInit) {
                  $statusText = $used
                      ? t('status_done_cycle', ['n' => num($cycleNum ?? 0)])
                      : t('status_available');
              } else {
                  $statusText = '—';
              }
              $checked = in_array((int) $p['id'], $oldPersonnel, true) && !$disabled;
          ?>
          <tr data-personnel-id="<?= (int) $p['id'] ?>"
              data-division-id="<?= (int) $p['division_id'] ?>"
              data-own="<?= $own ? 1 : 0 ?>"
              data-used="<?= $used ? 1 : 0 ?>"
              class="<?= $disabled ? 'opacity-50' : '' ?> <?= $checked ? 'bg-sky-50' : '' ?>">
            <td class="px-3 py-2 text-center">
              <input type="checkbox" name="personnel_ids[]" value="<?= (int) $p['id'] ?>"
                     <?php if ($disabled): ?>disabled title="<?= e(!$own ? t('read_only') : t('status_done_cycle', ['n' => num($cycleNum ?? 0)])) ?>"<?php endif; ?>
                     <?php if ($checked): ?>checked<?php endif; ?>
                     class="size-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500">
            </td>
            <td class="px-3 py-2 font-medium text-slate-800"><?= e($p['full_name']) ?></td>
            <td class="px-3 py-2 text-slate-600" dir="ltr"><?= e(num($p['personnel_code'])) ?></td>
            <td class="px-3 py-2 text-slate-600"><?= e($p['division_name']) ?></td>
            <td class="status-cell px-3 py-2 text-slate-600"><?= e($statusText) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </form>
</div>

<script type="application/json" id="i18n"><?= json_encode($i18n, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<script type="module" src="<?= e(asset('js/pages/submit-overtime.js')) ?>"></script>
