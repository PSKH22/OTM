<?php
/**
 * Renders and clears session flash messages.
 * success → green (role=status), error → red (role=alert).
 */
$flashSuccess = flash_get('success');
$flashError   = flash_get('error');
?>
<?php if ($flashSuccess !== [] || $flashError !== []): ?>
<div class="mx-auto w-full max-w-7xl px-4 pt-4 sm:px-6">
  <?php foreach ($flashSuccess as $msg): ?>
  <div role="status" class="mb-2 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
    <?= e($msg) ?>
  </div>
  <?php endforeach; ?>
  <?php foreach ($flashError as $msg): ?>
  <div role="alert" class="mb-2 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
    <?= e($msg) ?>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
