<?php
/**
 * Pagination partial. Receives:
 *   array $pagination  page (int), totalPages (int)
 *   array $queryBase   current filter params (page key is overwritten here)
 */
$page       = (int) ($pagination['page'] ?? 1);
$totalPages = (int) ($pagination['totalPages'] ?? 1);
if ($totalPages < 1) { $totalPages = 1; }

$pageUrl = static function (int $p) use ($queryBase): string {
    $params = array_merge($queryBase ?? [], ['page' => $p]);
    return url('/reports') . '?' . http_build_query($params);
};

$linkBase = 'inline-flex min-h-11 items-center rounded-lg border px-4 py-2 text-sm font-medium transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500';
$linkOn   = 'border-slate-300 text-slate-700 hover:bg-slate-100';
$linkOff  = 'pointer-events-none border-slate-200 text-slate-300';
?>
<?php if ($totalPages > 1): ?>
<nav class="flex items-center justify-center gap-3" aria-label="pagination">
  <?php if ($page > 1): ?>
  <a href="<?= e($pageUrl($page - 1)) ?>" class="<?= $linkBase ?> <?= $linkOn ?>">‹ <?= e(t('pagination_prev')) ?></a>
  <?php else: ?>
  <span class="<?= $linkBase ?> <?= $linkOff ?>" aria-disabled="true">‹ <?= e(t('pagination_prev')) ?></span>
  <?php endif; ?>

  <span class="text-sm text-slate-600"><?= e(t('pagination_info', ['current' => num($page), 'total' => num($totalPages)])) ?></span>

  <?php if ($page < $totalPages): ?>
  <a href="<?= e($pageUrl($page + 1)) ?>" class="<?= $linkBase ?> <?= $linkOn ?>"><?= e(t('pagination_next')) ?> ›</a>
  <?php else: ?>
  <span class="<?= $linkBase ?> <?= $linkOff ?>" aria-disabled="true"><?= e(t('pagination_next')) ?> ›</span>
  <?php endif; ?>
</nav>
<?php endif; ?>
