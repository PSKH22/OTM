<?php
/**
 * Delete confirmation dialog (native <dialog>). Filled by reports.js.
 */
?>
<dialog id="delete-dialog"
        class="fixed inset-0 m-auto w-full max-w-md rounded-2xl border border-slate-200 bg-white p-0 shadow-xl backdrop:bg-slate-900/50">
  <form method="post" action="<?= e(url('/overtime/delete')) ?>" class="p-6">
    <?= csrf_field() ?>
    <input type="hidden" name="entry_id" id="delete-entry-id" value="">
    <input type="hidden" name="back" id="delete-back" value="">

    <h2 class="mb-3 text-lg font-bold text-slate-900"><?= e(t('confirm_delete_title')) ?></h2>

    <dl id="delete-summary" class="mb-4 space-y-1 rounded-lg bg-slate-50 p-3 text-sm text-slate-700">
      <div class="flex justify-between gap-4"><dt class="text-slate-500"><?= e(t('name')) ?></dt><dd id="delete-name" class="font-medium"></dd></div>
      <div class="flex justify-between gap-4"><dt class="text-slate-500"><?= e(t('date')) ?></dt><dd id="delete-date" dir="ltr"></dd></div>
      <div class="flex justify-between gap-4"><dt class="text-slate-500"><?= e(t('type')) ?></dt><dd id="delete-type"></dd></div>
      <div class="flex justify-between gap-4"><dt class="text-slate-500"><?= e(t('hours')) ?></dt><dd id="delete-hours" dir="ltr"></dd></div>
    </dl>

    <p class="mb-6 text-sm text-slate-700"><?= e(t('confirm_delete')) ?></p>

    <div class="flex justify-end gap-2">
      <button type="button" id="delete-cancel"
              class="min-h-11 rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500">
        <?= e(t('btn_delete_cancel')) ?>
      </button>
      <button type="submit"
              class="min-h-11 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-red-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500 focus-visible:ring-offset-2">
        <?= e(t('btn_delete_confirm')) ?>
      </button>
    </div>
  </form>
</dialog>
