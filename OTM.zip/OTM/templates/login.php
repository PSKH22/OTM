<?php
/**
 * Login page (standalone, no nav). Receives:
 *   ?string $error  one of 'err_login' | 'err_throttle' | 'err_csrf' (already translated key) or null
 */
?>
<div class="flex min-h-screen items-center justify-center px-4 py-10">
  <div class="w-full max-w-sm">
    <div class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
      <h1 class="mb-1 text-center text-xl font-bold text-slate-900"><?= e(t('app_name')) ?></h1>
      <p class="mb-6 text-center text-sm text-slate-500"><?= e(t('login_title')) ?></p>

      <?php if (!empty($error)): ?>
      <div role="alert" class="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
        <?= e(t($error)) ?>
      </div>
      <?php endif; ?>

      <form method="post" action="<?= e(url('/login')) ?>" class="space-y-4">
        <?= csrf_field() ?>

        <div>
          <label for="username" class="mb-1 block text-sm font-medium text-slate-700"><?= e(t('username')) ?></label>
          <input type="text" id="username" name="username" autocomplete="username" required
                 value="<?= e(old('username')) ?>"
                 class="block min-h-11 w-full rounded-lg border border-slate-300 px-3 py-2 text-start text-slate-900 shadow-sm focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/40">
        </div>

        <div>
          <label for="password" class="mb-1 block text-sm font-medium text-slate-700"><?= e(t('password')) ?></label>
          <input type="password" id="password" name="password" autocomplete="current-password" required
                 class="block min-h-11 w-full rounded-lg border border-slate-300 px-3 py-2 text-start text-slate-900 shadow-sm focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/40">
        </div>

        <button type="submit"
                class="min-h-11 w-full rounded-lg bg-sky-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-sky-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 focus-visible:ring-offset-2">
          <?= e(t('login')) ?>
        </button>
      </form>
    </div>
  </div>
</div>
