<?php
/**
 * Base layout. Receives:
 *   string $title      page title
 *   string $content    pre-rendered HTML of the page template
 *   ?string $activeNav 'submit' | 'reports' | null
 *   bool   $showNav    false on the login page
 *   ?array $user       current user (display_name, division_name) when authenticated
 */
$showNav   = $showNav ?? true;
$activeNav = $activeNav ?? null;
$user      = $user ?? null;

$navLinkBase = 'rounded-lg px-3 py-2 text-sm font-medium transition-colors min-h-11 inline-flex items-center';
$navActive   = 'bg-sky-100 text-sky-900';
$navIdle     = 'text-slate-600 hover:bg-slate-100 hover:text-slate-900';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= e($title) ?> — <?= e(t('app_name')) ?></title>
<link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body class="min-h-screen bg-slate-50 font-sans text-slate-800 antialiased">
<?php if ($showNav): ?>
<header class="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
  <div class="mx-auto flex max-w-7xl flex-wrap items-center gap-x-4 gap-y-2 px-4 py-2 sm:px-6">
    <a href="<?= e(url('/overtime/new')) ?>" class="text-base font-bold text-slate-900"><?= e(t('app_name')) ?></a>

    <nav class="flex items-center gap-1" aria-label="main">
      <a href="<?= e(url('/overtime/new')) ?>"
         class="<?= $navLinkBase ?> <?= $activeNav === 'submit' ? $navActive : $navIdle ?>"
         <?php if ($activeNav === 'submit'): ?>aria-current="page"<?php endif; ?>><?= e(t('nav_submit')) ?></a>
      <a href="<?= e(url('/reports')) ?>"
         class="<?= $navLinkBase ?> <?= $activeNav === 'reports' ? $navActive : $navIdle ?>"
         <?php if ($activeNav === 'reports'): ?>aria-current="page"<?php endif; ?>><?= e(t('nav_reports')) ?></a>
    </nav>

    <div class="ms-auto flex items-center gap-3">
      <?php if ($user): ?>
      <span class="text-sm text-slate-600">
        <span class="font-medium text-slate-800"><?= e($user['display_name']) ?></span>
        <span class="text-slate-400">·</span>
        <?= e($user['division_name']) ?>
      </span>
      <?php endif; ?>
      <form method="post" action="<?= e(url('/logout')) ?>">
        <?= csrf_field() ?>
        <button type="submit"
                class="min-h-11 rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500">
          <?= e(t('logout')) ?>
        </button>
      </form>
    </div>
  </div>
</header>
<?php endif; ?>

<?php include __DIR__ . '/partials/flash.php'; ?>

<main class="<?= $showNav ? 'mx-auto w-full max-w-7xl px-4 py-6 sm:px-6' : '' ?>">
  <?= $content ?>
</main>
</body>
</html>
