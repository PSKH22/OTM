<?php /** 404 */ ?>
<div class="flex min-h-[70vh] items-center justify-center px-4">
  <div class="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
    <p class="mb-2 text-4xl font-black text-slate-300">404</p>
    <h1 class="mb-2 text-lg font-bold text-slate-900"><?= e(t('err_404_title')) ?></h1>
    <p class="mb-6 text-sm text-slate-600"><?= e(t('err_404_body')) ?></p>
    <a href="<?= e(url('/overtime/new')) ?>"
       class="inline-flex min-h-11 items-center rounded-lg bg-sky-600 px-5 py-2 text-sm font-semibold text-white transition-colors hover:bg-sky-700">
      <?= e(t('back_to_submit')) ?>
    </a>
  </div>
</div>
