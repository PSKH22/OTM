<?php /** 500 — generic; never show stack traces, file names or exception details. */ ?>
<div class="flex min-h-[70vh] items-center justify-center px-4">
  <div class="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
    <p class="mb-2 text-4xl font-black text-slate-300">500</p>
    <h1 class="mb-2 text-lg font-bold text-slate-900"><?= e(t('err_500_title')) ?></h1>
    <p class="text-sm text-slate-600"><?= e(t('err_500_body')) ?></p>
  </div>
</div>
