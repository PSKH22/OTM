<?php

declare(strict_types=1);

use App\Core\Response;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\OvertimeController;
use App\Http\Controllers\ReportController;
use App\Http\Middleware\CsrfGuard;
use App\Http\Middleware\RequireAuth;

/**
 * Route table (§10). Default-deny: every route sits behind RequireAuth
 * unless marked public (/login only).
 *
 * Format: [method, path, handler, [route middleware…]]
 */
return [
    ['GET', '/', static fn (): Response => Response::redirect(
        \App\Core\Session::userId() !== null ? url('/overtime/new') : url('/login')
    )],

    ['GET',  '/login',  [AuthController::class, 'showLogin']],
    ['POST', '/login',  [AuthController::class, 'login'], [CsrfGuard::class]],
    ['POST', '/logout', [AuthController::class, 'logout'], [RequireAuth::class, CsrfGuard::class]],

    ['GET',  '/overtime/new',    [OvertimeController::class, 'create'], [RequireAuth::class]],
    ['POST', '/overtime',        [OvertimeController::class, 'store'],  [RequireAuth::class, CsrfGuard::class]],
    ['POST', '/overtime/delete', [OvertimeController::class, 'delete'], [RequireAuth::class, CsrfGuard::class]],

    ['GET', '/reports',        [ReportController::class, 'index'],  [RequireAuth::class]],
    ['GET', '/reports/export', [ReportController::class, 'export'], [RequireAuth::class]],
];
