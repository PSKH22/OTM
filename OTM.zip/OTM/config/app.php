<?php

declare(strict_types=1);

/**
 * Application config: reads .env values (via env()) with safe defaults.
 */
return [
    'env'                     => env('APP_ENV', 'production'),
    'debug'                   => env('APP_DEBUG', '0') === '1',
    'url'                     => env('APP_URL', 'http://localhost:8000'),
    'timezone'                => env('APP_TIMEZONE', 'Asia/Tehran'),
    'locale'                  => env('APP_LOCALE', 'fa'),
    'persian_digits'          => env('UI_PERSIAN_DIGITS', '1') === '1',

    'session_name'            => env('SESSION_NAME', '__Host-ot_sid'),
    'cookie_secure'           => env('COOKIE_SECURE', '1') === '1',
    'session_idle_minutes'    => (int) env('SESSION_IDLE_MINUTES', '30'),
    'session_absolute_hours'  => (int) env('SESSION_ABSOLUTE_HOURS', '8'),

    'login_window_minutes'    => (int) env('LOGIN_WINDOW_MINUTES', '15'),
    'login_max_user_ip'       => (int) env('LOGIN_MAX_FAILURES_PER_USER_IP', '5'),
    'login_max_ip'            => (int) env('LOGIN_MAX_FAILURES_PER_IP', '20'),

    'overtime_max_hours'        => (float) env('OVERTIME_MAX_HOURS', '8'),
    'overtime_hours_step'       => (float) env('OVERTIME_HOURS_STEP', '0.25'),
    'overtime_date_window_days' => (int) env('OVERTIME_DATE_WINDOW_DAYS', '366'),
    'weekend_days'              => array_map(
        static fn (string $d): string => strtolower(trim($d)),
        explode(',', env('WEEKEND_DAYS', 'thu,fri')),
    ),
    'report_page_size'          => (int) env('REPORT_PAGE_SIZE', '50'),
];
