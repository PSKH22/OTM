<?php

declare(strict_types=1);

/**
 * All user-visible strings (Persian). Placeholders use {name} syntax and are
 * interpolated by t() via str_replace.
 *
 * @return array<string, string>
 */
return [
    // ── General ──────────────────────────────────────────────────────────
    'app_name'           => 'مدیریت اضافه‌کاری',
    'login'              => 'ورود',
    'logout'             => 'خروج',
    'username'           => 'نام کاربری',
    'password'           => 'گذرواژه',
    'nav_submit'         => 'ثبت اضافه‌کاری',
    'nav_reports'        => 'گزارش‌ها',
    'type'               => 'نوع اضافه‌کاری',
    'division'           => 'واحد',
    'all_divisions'      => 'همه واحدها',
    'all_types'          => 'همه انواع',
    'date'               => 'تاریخ',
    'hours'              => 'ساعت',
    'description'        => 'توضیحات',
    'optional'           => '(اختیاری)',
    'personnel'          => 'پرسنل',
    'personnel_id'       => 'کد پرسنلی',
    'name'               => 'نام و نام خانوادگی',
    'cycle'              => 'دور',
    'status'             => 'وضعیت',
    'actions'            => 'عملیات',
    'search_placeholder' => 'جستجوی نام یا کد پرسنلی',
    'selected_count'     => '{count} نفر انتخاب شده',
    'selected_count_hidden' => '({count} مخفی)',
    'submit'             => 'ثبت',
    'delete'             => 'حذف',
    'cancel'             => 'انصراف',
    'export_csv'         => 'خروجی CSV',
    'from_date'          => 'از تاریخ',
    'to_date'            => 'تا تاریخ',
    'apply'              => 'اعمال',
    'reset'              => 'بازنشانی',
    'today'              => 'امروز',
    'no_records'         => 'رکوردی یافت نشد.',
    'login_title'        => 'ورود به سامانه',
    'back_to_submit'     => 'بازگشت به ثبت اضافه‌کاری',

    // ── Status labels (Submit page) ──────────────────────────────────────
    'status_available'   => 'آزاد',
    'status_done_cycle'  => 'انجام‌شده در دور {n}',
    'read_only'          => 'فقط مشاهده',
    'status_locked'      => '🔒 فقط مشاهده',

    // ── Type names (mirror of overtime_types seed, for reference) ────────
    'type_weekdays'      => 'روزهای کاری',
    'type_weekend'       => 'آخر هفته',
    'type_out_of_quota'  => 'خارج از سهمیه',

    // ── Division names (mirror of divisions seed, for reference) ─────────
    'division_hardware'  => 'پشتیبانی سخت‌افزار',
    'division_network'   => 'شبکه و زیرساخت',
    'division_database'  => 'پایگاه داده و امنیت اطلاعات',

    // ── Cycle summary strip ──────────────────────────────────────────────
    'cycle_chip'         => '{name}: دور {n} · {done}/{total}',

    // ── Auth errors ──────────────────────────────────────────────────────
    'err_login'          => 'نام کاربری یا گذرواژه نادرست است.',
    'err_throttle'       => 'تعداد تلاش‌ها از حد مجاز گذشته است؛ چند دقیقه بعد دوباره تلاش کنید.',
    'err_csrf'           => 'نشست شما منقضی شده است؛ صفحه را دوباره بارگیری کنید.',
    'err_forbidden'      => 'دسترسی مجاز نیست.',

    // ── Validation errors ────────────────────────────────────────────────
    'err_required'           => 'این فیلد الزامی است.',
    'err_invalid_date'       => 'تاریخ معتبر نیست.',
    'err_date_window'        => 'تاریخ باید حداکثر {days} روز قبل یا بعد از امروز باشد.',
    'err_date_order'         => '«تا تاریخ» نباید قبل از «از تاریخ» باشد.',
    'err_invalid_hours'      => 'ساعت واردشده معتبر نیست.',
    'err_hours_step'         => 'ساعت باید مضربی از {step} باشد.',
    'err_hours_max'          => 'حداکثر ساعت مجاز برای هر ثبت {max} ساعت است.',
    'err_personnel_count'    => 'حداقل یک نفر و حداکثر {max} نفر باید انتخاب شوند.',
    'err_unknown_personnel'  => 'برخی پرسنل انتخاب‌شده یافت نشدند یا غیرفعال هستند.',
    'err_inactive_personnel' => 'این افراد غیرفعال هستند: {names}',
    'err_already_used_cycle' => 'این افراد در دور جاری قبلاً اضافه‌کاری ثبت کرده‌اند: {names}',
    'err_batch_rejected'     => 'هیچ رکوردی ثبت نشد.',
    'err_duplicate_submit'   => 'این فرم قبلاً ارسال شده است؛ لطفاً صفحه را دوباره بارگیری کنید.',
    'err_invalid_choice'     => 'گزینهٔ انتخاب‌شده معتبر نیست.',
    'err_entry_not_found'    => 'رکورد دیگر وجود ندارد.',
    'err_invalid_back'       => 'مسیر بازگشت معتبر نیست.',

    // ── Day-rule messages (weekday name interpolated) ────────────────────
    'err_day_workday'    => 'روز انتخاب‌شده ({weekday}) روز کاری نیست.',
    'err_day_weekend'    => 'روز انتخاب‌شده ({weekday}) جزو آخر هفته نیست.',

    // ── Flash messages ───────────────────────────────────────────────────
    'flash_submit_success'  => 'اضافه‌کاری برای {count} نفر ثبت شد — {type}، {date}، {hours} ساعت',
    'flash_cycle_closed'    => 'دور {n} تکمیل شد؛ دور {next} آغاز شد.',
    'flash_delete_success'  => 'رکورد حذف شد.',
    'flash_cycle_reopened'  => 'دور {n} دوباره باز شد.',
    'flash_logout'          => 'با موفقیت خارج شدید.',

    // ── Pagination ───────────────────────────────────────────────────────
    'pagination_prev'    => 'قبلی',
    'pagination_next'    => 'بعدی',
    'pagination_info'    => 'صفحه {current} از {total}',

    // ── Report summary ───────────────────────────────────────────────────
    'report_summary'     => '{count} رکورد · {hours} ساعت',

    // ── Delete dialog ────────────────────────────────────────────────────
    'confirm_delete'       => 'آیا از حذف این رکورد اضافه‌کاری مطمئن هستید؟',
    'confirm_delete_title' => 'حذف رکورد اضافه‌کاری',
    'confirm_delete_body'  => 'آیا از حذف این رکورد اضافه‌کاری مطمئن هستید؟',
    'btn_delete_confirm'   => 'حذف',
    'btn_delete_cancel'    => 'انصراف',

    // ── Error pages ──────────────────────────────────────────────────────
    'err_403_title'      => 'دسترسی مجاز نیست',
    'err_403_body'       => 'شما اجازهٔ انجام این عملیات را ندارید.',
    'err_404_title'      => 'صفحه پیدا نشد',
    'err_404_body'       => 'صفحه‌ای که دنبال آن بودید وجود ندارد.',
    'err_500_title'      => 'خطای داخلی سرور',
    'err_500_body'       => 'لطفاً بعداً دوباره تلاش کنید.',
];
