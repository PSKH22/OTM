<?php

declare(strict_types=1);

namespace App\Services;

/**
 * Division-scoped authorization (§8.6). The single place that decides;
 * both checks compare against user.division_id loaded from the DB in the
 * current request. Stateless; no hardcoded division IDs.
 */
final class AccessPolicy
{
    public static function canSubmitFor(array $user, int $divisionId): bool
    {
        return (int) $user['division_id'] === $divisionId;
    }

    public static function canDelete(array $user, array $entry): bool
    {
        return (int) $user['division_id'] === (int) $entry['division_id'];
    }
}
