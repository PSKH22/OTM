<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Session;
use App\Repositories\LoginAttemptRepository;
use App\Repositories\UserRepository;

/**
 * Credential check, throttling, session fixation defence (§8.1–§8.3).
 */
final class AuthService
{
    /** Argon2id parameters (OWASP minimum profile). */
    private const HASH_OPTIONS = ['memory_cost' => 19456, 'time_cost' => 2, 'threads' => 1];

    /**
     * Dummy hash used when the account is missing/inactive so response time
     * does not reveal whether the account exists.
     */
    private const DUMMY_HASH = '$argon2id$v=19$m=19456,t=2,p=1$T0kjGMkCa/C0RwvaBk9D6g$N0Wlqcw4+9Z4/py34d1WAZ7aBTV/iTgj2j2/+Ex25rc';

    public function __construct(
        private readonly UserRepository $users,
        private readonly LoginAttemptRepository $attempts,
    ) {}

    /**
     * @return array{success: bool, user?: array, error?: string}
     */
    public function attempt(string $username, string $password, string $ip): array
    {
        $username = mb_substr(strtolower(trim($username)), 0, 64);
        $window = (int) config('app.login_window_minutes', 15);

        // 1. Throttle: ≥5 per (user, IP) or ≥20 per IP within the window.
        $userIpFails = $this->attempts->countRecent($username, $ip, $window);
        $ipFails = $this->attempts->countRecentByIp($ip, $window);
        if ($userIpFails >= (int) config('app.login_max_user_ip', 5)
            || $ipFails >= (int) config('app.login_max_ip', 20)) {
            app_log('warn', "Login throttle: user={$username} ip={$ip}");
            return ['success' => false, 'error' => 'err_throttle'];
        }

        // 2. Look up the user; verify against a dummy hash if missing/inactive.
        $user = $this->users->findByUsername($username);
        $active = $user !== null && (int) $user['is_active'] === 1;
        $hash = $active ? (string) $user['password_hash'] : self::DUMMY_HASH;

        // 3. Verify.
        if (!$active || !password_verify($password, $hash)) {
            $this->attempts->record($username, $ip, false);
            app_log('info', "Failed login: user={$username} ip={$ip}");
            return ['success' => false, 'error' => 'err_login'];
        }

        // 4. Success — regenerate the session id (fixation defence), then store state.
        Session::regenerate();
        Session::setUserId((int) $user['id']);
        Session::setCreatedAt(time());
        Session::setLastActivity(time());

        if (password_needs_rehash($hash, self::hashAlgo(), self::HASH_OPTIONS)) {
            $this->users->updatePasswordHash((int) $user['id'], self::hashPassword($password));
        }
        $this->users->updateLastLogin((int) $user['id']);
        $this->attempts->clearForUserIp($username, $ip);
        app_log('info', "Login: user={$username} ip={$ip}");

        return ['success' => true, 'user' => $user];
    }

    public static function hashAlgo(): string
    {
        return defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
    }

    public static function hashPassword(string $password): string
    {
        return password_hash($password, self::hashAlgo(), self::HASH_OPTIONS);
    }
}
