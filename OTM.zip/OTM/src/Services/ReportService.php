<?php

declare(strict_types=1);

namespace App\Services;

use App\Input\ReportFilter;
use App\Repositories\OvertimeRepository;

/** Filtered report queries, totals, pagination (§9.3). */
final class ReportService
{
    public function __construct(private readonly OvertimeRepository $entries) {}

    /**
     * @return array{rows: array, page: int, totalPages: int, total: int}
     */
    public function query(ReportFilter $f, int $pageSize): array
    {
        $totals = $this->entries->filteredTotals($f);
        $totalPages = max(1, (int) ceil($totals['count'] / $pageSize));
        $page = min(max(1, $f->page), $totalPages); // clamp out-of-range pages

        return [
            'rows'       => $this->entries->filteredQuery($f, $page, $pageSize),
            'page'       => $page,
            'totalPages' => $totalPages,
            'total'      => $totals['count'],
        ];
    }

    /** @return array{count: int, hours: float} */
    public function totals(ReportFilter $f): array
    {
        return $this->entries->filteredTotals($f);
    }

    /** Unbuffered stream for the CSV export (no pagination). */
    public function stream(ReportFilter $f): \Generator
    {
        return $this->entries->streamForCsv($f);
    }
}
