<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Response;
use App\Input\ReportFilter;
use App\Support\JalaliDate;

/**
 * CSV export for Excel (§9.5): UTF-8 BOM, Persian headers, Latin digits,
 * formula-injection guard, streamed from an unbuffered query.
 */
final class CsvExporter
{
    public function __construct(private readonly ReportService $reports) {}

    public function export(ReportFilter $f, string $todayJalali): Response
    {
        // ASCII filename with today's Jalali date, e.g. overtime-report-1405-07-11.csv
        $filename = 'overtime-report-' . str_replace('/', '-', $todayJalali) . '.csv';

        return Response::csv($filename, function ($out) use ($f): void {
            fputcsv($out, [
                'تاریخ', 'کد پرسنلی', 'نام و نام خانوادگی', 'واحد',
                'نوع اضافه‌کاری', 'ساعت', 'دور', 'توضیحات',
            ], ',', '"', '');

            foreach ($this->reports->stream($f) as $row) {
                fputcsv($out, [
                    JalaliDate::fromGregorian((string) $row['overtime_date']), // Latin digits
                    $this->personnelCode((string) $row['personnel_code']),
                    $this->guard((string) $row['full_name']),
                    $this->guard((string) $row['division']),
                    $this->guard((string) $row['type']),
                    $this->hours((string) $row['hours']),
                    $row['cycle_number'] === null ? '' : (string) (int) $row['cycle_number'],
                    $this->guard((string) ($row['description'] ?? '')),
                ], ',', '"', '');
            }
        });
    }

    /**
     * Formula-injection guard: cells starting with =, +, -, @, tab or CR
     * are prefixed with a single quote.
     */
    private function guard(string $cell): string
    {
        if ($cell !== '' && preg_match('/^[=+\-@\t\r]/', $cell) === 1) {
            return "'" . $cell;
        }
        return $cell;
    }

    /**
     * Codes are validated to ^[0-9A-Za-z]+$ on write, so they can never start
     * with a formula character. Codes starting with 0 are wrapped as ="0123"
     * so Excel keeps the leading zero.
     */
    private function personnelCode(string $code): string
    {
        if (str_starts_with($code, '0')) {
            return '="' . $code . '"';
        }
        return $code;
    }

    /** '2.50' → '2.5' (dot decimal, Latin digits). */
    private function hours(string $hours): string
    {
        $trimmed = rtrim(rtrim($hours, '0'), '.');
        return $trimmed === '' ? '0' : $trimmed;
    }
}
