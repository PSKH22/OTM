<?php

declare(strict_types=1);

namespace App\Services;

use App\Input\OvertimeSubmission;
use App\Repositories\AuditLogRepository;
use App\Repositories\CycleRepository;
use App\Repositories\LookupRepository;
use App\Repositories\OvertimeRepository;
use App\Repositories\PersonnelRepository;
use App\Support\JalaliDate;
use PDO;
use PDOException;

/**
 * Submit (§5.4) and delete (§5.5) — all business rules and transactions.
 */
final class OvertimeService
{
    private readonly CycleService $cycleService;
    private readonly CycleRepository $cycles;
    private readonly PersonnelRepository $personnel;
    private readonly OvertimeRepository $entries;
    private readonly AuditLogRepository $audit;
    private readonly LookupRepository $lookup;

    public function __construct(private readonly PDO $pdo)
    {
        $this->cycleService = new CycleService($pdo);
        $this->cycles = new CycleRepository($pdo);
        $this->personnel = new PersonnelRepository($pdo);
        $this->entries = new OvertimeRepository($pdo);
        $this->audit = new AuditLogRepository($pdo);
        $this->lookup = new LookupRepository($pdo);
    }

    /**
     * §5.4. The division is taken from the logged-in user, never the form.
     *
     * @return array{success: bool, count?: int, cycleClosed?: bool, newCycleNumber?: ?int,
     *               errors?: array<string, string>, forbidden?: bool}
     */
    public function submitBatch(OvertimeSubmission $input, array $user, array $type): array
    {
        $divisionId = (int) $user['division_id'];
        $weekendDays = (array) config('app.weekend_days', ['thu', 'fri']);
        $gregorian = $input->dateGregorian;

        // 2. Day rule (the client check is advisory; re-check here).
        if ($gregorian !== null) {
            $isWeekend = JalaliDate::isWeekendDay($gregorian, $weekendDays);
            $weekday = JalaliDate::weekdayName($gregorian);
            if ($type['day_rule'] === 'workday' && $isWeekend) {
                return ['success' => false, 'errors' => ['date' => t('err_day_workday', ['weekday' => $weekday])]];
            }
            if ($type['day_rule'] === 'weekend' && !$isWeekend) {
                return ['success' => false, 'errors' => ['date' => t('err_day_weekend', ['weekday' => $weekday])]];
            }
        }

        $usesCycle = (int) $type['uses_cycle'] === 1;

        $this->pdo->beginTransaction();
        try {
            $cycleId = null;

            if ($usesCycle) {
                // 3a. Lock the open cycle FIRST (serialises concurrent submits).
                $cycle = $this->cycleService->open($divisionId);
                $cycleId = $cycle['id'];

                // 3b. Reject the whole batch if anyone is already used in this cycle.
                $existing = $this->entries->existingInCycle($cycleId, $input->personnelIds);
                if ($existing !== []) {
                    $names = $this->namesFor($existing);
                    $this->pdo->rollBack();
                    return ['success' => false, 'errors' => [
                        'personnel_ids' => t('err_already_used_cycle', ['names' => implode('، ', $names)]),
                    ]];
                }
            }

            // 4. Verify all personnel: exist, active, in the user's division.
            $people = $this->personnel->findByIds($input->personnelIds);
            if (count($people) !== count($input->personnelIds)) {
                $this->pdo->rollBack();
                return ['success' => false, 'errors' => ['personnel_ids' => t('err_unknown_personnel')]];
            }
            $inactive = [];
            foreach ($people as $person) {
                if ((int) $person['is_active'] !== 1) {
                    $inactive[] = $person['full_name'];
                }
                if (!AccessPolicy::canSubmitFor($user, (int) $person['division_id'])) {
                    $this->pdo->rollBack();
                    app_log('warn', sprintf(
                        'Authorization failure (tampering): user=%s ip=n/a route=/overtime target_personnel=%s',
                        $user['id'],
                        $person['id'],
                    ));
                    return ['success' => false, 'forbidden' => true];
                }
            }
            if ($inactive !== []) {
                $this->pdo->rollBack();
                return ['success' => false, 'errors' => [
                    'personnel_ids' => t('err_inactive_personnel', ['names' => implode('، ', $inactive)]),
                ]];
            }

            // 5. INSERT one row per person (division_id = user's division snapshot).
            $rows = [];
            foreach ($input->personnelIds as $personnelId) {
                $rows[] = [
                    'personnel_id'     => $personnelId,
                    'division_id'      => $divisionId,
                    'overtime_type_id' => (int) $type['id'],
                    'overtime_date'    => $gregorian,
                    'hours'            => $input->hoursNormalized,
                    'description'      => $input->description,
                    'cycle_id'         => $cycleId,
                    'created_by'       => (int) $user['id'],
                ];
            }
            $this->entries->insertBatch($rows);

            // 6. Close/open the cycle when everyone has had one.
            $newCycleNumber = null;
            if ($usesCycle) {
                $newCycleNumber = $this->cycleService->checkAndClose($divisionId, $cycleId);
            }

            $this->pdo->commit();

            return [
                'success'        => true,
                'count'          => count($rows),
                'cycleClosed'    => $newCycleNumber !== null,
                'newCycleNumber' => $newCycleNumber,
            ];
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            // 8. Duplicate-key backstop (SQLSTATE 23000 / errno 1062).
            if ($e->getCode() === '23000' || ($e->errorInfo[1] ?? null) === 1062) {
                return ['success' => false, 'errors' => [
                    'personnel_ids' => t('err_already_used_cycle', ['names' => '']) . ' ' . t('err_batch_rejected'),
                ]];
            }
            throw $e;
        }
    }

    /**
     * §5.5. Same lock order as submit: division's open cycle first.
     *
     * @return array{success: bool, cycleReopened?: bool, reopenedNumber?: ?int,
     *               notFound?: bool, forbidden?: bool}
     */
    public function deleteEntry(int $entryId, array $user, string $ip): array
    {
        $divisionId = (int) $user['division_id'];

        $this->pdo->beginTransaction();
        try {
            // 2. Lock the division's open cycle first.
            $open = $this->cycles->openCycleForUpdate($divisionId);

            // 3. Load the entry under lock.
            $entry = $this->entries->findByIdForUpdate($entryId);
            if ($entry === null) {
                $this->pdo->rollBack();
                return ['success' => false, 'notFound' => true];
            }
            if (!AccessPolicy::canDelete($user, $entry)) {
                $this->pdo->rollBack();
                app_log('warn', sprintf(
                    'Authorization failure (IDOR attempt): user=%s ip=%s route=/overtime/delete target_entry=%d',
                    $user['id'],
                    $ip,
                    $entryId,
                ));
                return ['success' => false, 'forbidden' => true];
            }

            // 4. Hard delete.
            $this->entries->delete($entryId);

            // 5. Cycle semantics (§5.5): undo-close only when the entry belonged
            //    to the most recent closed cycle AND the open cycle is empty.
            $cycleReopened = false;
            $reopenedNumber = null;
            $entryCycleId = $entry['cycle_id'] === null ? null : (int) $entry['cycle_id'];
            if ($entryCycleId !== null && ($open === null || $entryCycleId !== (int) $open['id'])) {
                $prev = $this->cycles->mostRecentClosedCycle($divisionId);
                if ($prev !== null
                    && $entryCycleId === (int) $prev['id']
                    && $open !== null
                    && $this->cycles->entryCount((int) $open['id']) === 0) {
                    // Order matters (unique one-open-cycle-per-division key):
                    // discard the empty open cycle FIRST, then re-open the previous.
                    $this->cycles->deleteCycle((int) $open['id']);
                    $this->cycles->reopenCycle((int) $prev['id']);
                    $cycleReopened = true;
                    $reopenedNumber = (int) $prev['cycle_number'];
                }
            }

            // 6. Audit snapshot of the deleted row.
            $person = $this->personnel->findByIds([(int) $entry['personnel_id']])[(int) $entry['personnel_id']] ?? null;
            $type = $this->lookup->findType((int) $entry['overtime_type_id']);
            $this->audit->log((int) $user['id'], 'overtime.delete', $entryId, [
                'entry'          => $entry,
                'personnel_code' => $person['personnel_code'] ?? null,
                'full_name'      => $person['full_name'] ?? null,
                'date_jalali'    => JalaliDate::fromGregorian((string) $entry['overtime_date']),
                'type'           => $type['name'] ?? null,
            ], $ip);

            $this->pdo->commit();

            return [
                'success'        => true,
                'cycleReopened'  => $cycleReopened,
                'reopenedNumber' => $reopenedNumber,
            ];
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    /**
     * @param int[] $ids
     * @return string[]
     */
    private function namesFor(array $ids): array
    {
        $people = $this->personnel->findByIds($ids);
        $names = [];
        foreach ($ids as $id) {
            $names[] = $people[$id]['full_name'] ?? ('#' . $id);
        }
        return $names;
    }
}
