<?php

declare(strict_types=1);

namespace App\Services;

use App\Repositories\CycleRepository;
use PDO;
use RuntimeException;

/**
 * Per-division cycle rules (§5.1, §5.3). All methods assume the caller
 * already holds a transaction; open() MUST be its first statement.
 */
final class CycleService
{
    private readonly CycleRepository $cycles;

    public function __construct(private readonly PDO $pdo)
    {
        $this->cycles = new CycleRepository($pdo);
    }

    /**
     * Lock the division's open cycle (SELECT … FOR UPDATE — first statement
     * in the transaction) and lazily close/open when the open cycle has
     * ≥ 1 entries but 0 remaining active personnel (§5.3).
     *
     * @return array{id: int, cycle_number: int}
     */
    public function open(int $divisionId): array
    {
        $cycle = $this->cycles->openCycleForUpdate($divisionId);
        if ($cycle === null) {
            // Should not happen (seed guarantees one open cycle per division);
            // recover by opening cycle 1.
            $id = $this->cycles->openNextCycle($divisionId, 1);
            return ['id' => $id, 'cycle_number' => 1];
        }

        $cycleId = (int) $cycle['id'];
        $hasEntries = $this->cycles->entryCount($cycleId) > 0;
        $remaining = $this->cycles->remainingCount($divisionId, $cycleId);

        if ($hasEntries && $remaining === 0) {
            // Lazy close (e.g. the last remaining person was deactivated).
            $this->cycles->closeCycle($cycleId);
            $nextNumber = (int) $cycle['cycle_number'] + 1;
            $newId = $this->cycles->openNextCycle($divisionId, $nextNumber);
            return ['id' => $newId, 'cycle_number' => $nextNumber];
        }

        return ['id' => $cycleId, 'cycle_number' => (int) $cycle['cycle_number']];
    }

    /** Cycle summary strip data (one row per division). */
    public function summaryStrip(): array
    {
        return $this->cycles->summaryStrip();
    }

    /**
     * After an insert: if no active person of the division remains without an
     * entry in this cycle, close it and open the next.
     *
     * @return ?int the NEW cycle number when the cycle closed, null otherwise
     */
    public function checkAndClose(int $divisionId, int $cycleId): ?int
    {
        $cycle = $this->cycles->openCycleForUpdate($divisionId);
        if ($cycle === null || (int) $cycle['id'] !== $cycleId) {
            throw new RuntimeException('Cycle lock lost during submit.');
        }

        if ($this->cycles->remainingCount($divisionId, $cycleId) > 0) {
            return null;
        }

        $this->cycles->closeCycle($cycleId);
        $nextNumber = (int) $cycle['cycle_number'] + 1;
        $this->cycles->openNextCycle($divisionId, $nextNumber);
        return $nextNumber;
    }
}
