<?php

declare(strict_types=1);

namespace App\Input;

/**
 * Delete-entry input (§9.4). `back` must be a local /reports URL
 * (open-redirect defence, §8.7).
 */
final class DeleteEntryInput
{
    private function __construct(
        public readonly int $entryId,
        public readonly string $back,
    ) {}

    public static function fromPost(array $post): self
    {
        $entryId = filter_var($post['entry_id'] ?? null, FILTER_VALIDATE_INT);
        return new self(
            is_int($entryId) ? $entryId : 0,
            (string) ($post['back'] ?? ''),
        );
    }

    /** @return array<string, string> field => translated error message */
    public function validate(): array
    {
        $errors = [];
        if ($this->entryId <= 0) {
            $errors['entry_id'] = t('err_entry_not_found');
        }
        if (!str_starts_with($this->back, '/reports')) {
            $errors['back'] = t('err_invalid_back');
        }
        return $errors;
    }
}
