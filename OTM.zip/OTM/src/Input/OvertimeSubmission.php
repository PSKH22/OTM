<?php

declare(strict_types=1);

namespace App\Input;

use App\Support\JalaliDate;

/**
 * Submit-overtime input DTO (§9.2). Division is NEVER taken from the form.
 */
final class OvertimeSubmission
{
    /** @var int[] */
    public readonly array $personnelIds;
    public readonly ?string $description;
    public readonly string $hoursNormalized; // Latin digits, '.' decimal
    public readonly string $dateJalali;

    /** Set by validate() once the Jalali date converts cleanly. */
    public ?string $dateGregorian = null;

    private function __construct(
        public readonly int $typeId,
        string $dateJalali,
        string $hoursNormalized,
        ?string $description,
        array $personnelIds,
        private readonly float $maxHours,
        private readonly float $hoursStep,
        private readonly int $windowDays,
    ) {
        $this->dateJalali = $dateJalali;
        $this->hoursNormalized = $hoursNormalized;
        $this->description = $description;
        $this->personnelIds = $personnelIds;
    }

    public static function fromPost(array $post, array $config = []): self
    {
        $maxHours   = (float) ($config['max_hours'] ?? config('app.overtime_max_hours', 8));
        $hoursStep  = (float) ($config['hours_step'] ?? config('app.overtime_hours_step', 0.25));
        $windowDays = (int) ($config['window_days'] ?? config('app.overtime_date_window_days', 366));

        $typeId = filter_var($post['type_id'] ?? null, FILTER_VALIDATE_INT);
        $typeId = is_int($typeId) ? $typeId : 0;

        $date = JalaliDate::normalizeDigits(trim((string) ($post['date'] ?? '')));

        $hours = JalaliDate::normalizeDigits(trim((string) ($post['hours'] ?? '')));
        $hours = str_replace(["\u{066B}", ','], '.', $hours); // ٫ and , → .

        $description = trim((string) ($post['description'] ?? ''));
        $description = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $description) ?? $description;
        $description = $description === '' ? null : $description;

        $ids = [];
        foreach ((array) ($post['personnel_ids'] ?? []) as $raw) {
            $id = filter_var($raw, FILTER_VALIDATE_INT);
            if (is_int($id) && $id > 0) {
                $ids[$id] = $id; // deduplicate
            }
        }

        return new self($typeId, $date, $hours, $description, array_values($ids), $maxHours, $hoursStep, $windowDays);
    }

    /** @return array<string, string> field => translated error message */
    public function validate(): array
    {
        $errors = [];

        if ($this->typeId <= 0) {
            $errors['type_id'] = t('err_required');
        }

        if ($this->dateJalali === '') {
            $errors['date'] = t('err_required');
        } else {
            $gregorian = JalaliDate::toGregorian($this->dateJalali);
            if ($gregorian === null) {
                $errors['date'] = t('err_invalid_date');
            } else {
                $today = new \DateTimeImmutable('today', new \DateTimeZone('Asia/Tehran'));
                $date = new \DateTimeImmutable($gregorian . ' 00:00:00', new \DateTimeZone('Asia/Tehran'));
                $diff = abs((int) $today->diff($date)->format('%a'));
                if ($diff > $this->windowDays) {
                    $errors['date'] = t('err_date_window', ['days' => num($this->windowDays)]);
                } else {
                    $this->dateGregorian = $gregorian;
                }
            }
        }

        if ($this->hoursNormalized === '') {
            $errors['hours'] = t('err_required');
        } elseif (!preg_match('/^\d+(\.\d{1,2})?$/', $this->hoursNormalized)) {
            $errors['hours'] = t('err_invalid_hours');
        } else {
            $hours = (float) $this->hoursNormalized;
            $steps = round($hours / $this->hoursStep);
            if ($hours < $this->hoursStep) {
                $errors['hours'] = t('err_invalid_hours');
            } elseif ($hours > $this->maxHours) {
                $errors['hours'] = t('err_hours_max', ['max' => num($this->maxHours)]);
            } elseif (abs($hours - $steps * $this->hoursStep) >= 1e-9) {
                $errors['hours'] = t('err_hours_step', ['step' => num($this->hoursStep)]);
            }
        }

        if ($this->description !== null && mb_strlen($this->description) > 255) {
            $errors['description'] = t('err_invalid_choice');
        }

        $count = count($this->personnelIds);
        if ($count < 1 || $count > 500) {
            $errors['personnel_ids'] = t('err_personnel_count', ['max' => num(500)]);
        }

        return $errors;
    }
}
