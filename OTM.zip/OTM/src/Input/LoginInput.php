<?php

declare(strict_types=1);

namespace App\Input;

/**
 * Login form input: username (required, ≤64), password (required, ≤128).
 */
final class LoginInput
{
    private function __construct(
        public readonly string $username,
        public readonly string $password,
    ) {}

    public static function fromPost(array $post): self
    {
        return new self(
            trim((string) ($post['username'] ?? '')),
            (string) ($post['password'] ?? ''),
        );
    }

    /** @return array<int, string> list of error message keys */
    public function validate(): array
    {
        $errors = [];
        if ($this->username === '' || mb_strlen($this->username) > 64) {
            $errors[] = 'err_login';
        }
        if ($this->password === '' || mb_strlen($this->password) > 128) {
            $errors[] = 'err_login';
        }
        return array_values(array_unique($errors));
    }
}
