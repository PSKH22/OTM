<?php

declare(strict_types=1);

namespace App\Input;

use App\Support\JalaliDate;
use App\Support\TextNormalizer;

/**
 * Report filter DTO (§9.3). Parsed and validated once, used by both the
 * report page and the CSV export so they always show the same set.
 * Reports have NO date limit (C5).
 */
final class ReportFilter
{
    public readonly string $fromRaw;
    public readonly string $toRaw;
    public readonly string $q;

    /** Gregorian bounds, set by validate(). */
    public ?string $fromGregorian = null;
    public ?string $toGregorian = null;

    private function __construct(
        string $fromRaw,
        string $toRaw,
        public readonly ?int $divisionId,
        public readonly ?int $typeId,
        string $q,
        public readonly int $page,
    ) {
        $this->fromRaw = $fromRaw;
        $this->toRaw = $toRaw;
        $this->q = $q;
    }

    public static function fromQuery(array $query): self
    {
        $divisionId = filter_var($query['division_id'] ?? null, FILTER_VALIDATE_INT);
        $typeId = filter_var($query['type_id'] ?? null, FILTER_VALIDATE_INT);
        $page = filter_var($query['page'] ?? null, FILTER_VALIDATE_INT);

        return new self(
            JalaliDate::normalizeDigits(trim((string) ($query['from'] ?? ''))),
            JalaliDate::normalizeDigits(trim((string) ($query['to'] ?? ''))),
            (is_int($divisionId) && $divisionId > 0) ? $divisionId : null,
            (is_int($typeId) && $typeId > 0) ? $typeId : null,
            mb_substr(trim((string) ($query['q'] ?? '')), 0, 100),
            (is_int($page) && $page >= 1) ? $page : 1,
        );
    }

    /** @return array<string, string> field => translated error message */
    public function validate(): array
    {
        $errors = [];

        if ($this->fromRaw !== '') {
            $this->fromGregorian = JalaliDate::toGregorian($this->fromRaw);
            if ($this->fromGregorian === null) {
                $errors['from'] = t('err_invalid_date');
            }
        }
        if ($this->toRaw !== '') {
            $this->toGregorian = JalaliDate::toGregorian($this->toRaw);
            if ($this->toGregorian === null) {
                $errors['to'] = t('err_invalid_date');
            }
        }
        if ($this->fromGregorian !== null && $this->toGregorian !== null
            && $this->toGregorian < $this->fromGregorian) {
            $errors['to'] = t('err_date_order');
        }

        return $errors;
    }

    /**
     * Whitelist WHERE conditions joined with AND; all values bound (§6.5).
     *
     * @return array{where: string, params: array<string, mixed>}
     */
    public function toSqlConditions(): array
    {
        $where = [];
        $params = [];

        if ($this->fromGregorian !== null) {
            $where[] = 'e.overtime_date >= :from';
            $params['from'] = $this->fromGregorian;
        }
        if ($this->toGregorian !== null) {
            $where[] = 'e.overtime_date <= :to';
            $params['to'] = $this->toGregorian;
        }
        if ($this->divisionId !== null) {
            $where[] = 'e.division_id = :division_id';
            $params['division_id'] = $this->divisionId;
        }
        if ($this->typeId !== null) {
            $where[] = 'e.overtime_type_id = :type_id';
            $params['type_id'] = $this->typeId;
        }
        if ($this->q !== '') {
            $needle = '%' . $this->escapeLike(TextNormalizer::normalize($this->q)) . '%';
            // Two distinct placeholders: native prepares forbid reusing one name.
            $where[] = "(p.name_search LIKE :q_name ESCAPE '\\\\' OR p.personnel_code LIKE :q_code ESCAPE '\\\\')";
            $params['q_name'] = $needle;
            $params['q_code'] = $needle;
        }

        return [
            'where'  => $where === [] ? '' : ' WHERE ' . implode(' AND ', $where),
            'params' => $params,
        ];
    }

    /** Escape LIKE wildcards (% and _) and the escape char itself. */
    private function escapeLike(string $s): string
    {
        return strtr($s, ['\\' => '\\\\', '%' => '\\%', '_' => '\\_']);
    }

    /** Raw values for re-populating the filter form. */
    public function rawValues(): array
    {
        return [
            'from'        => $this->fromRaw,
            'to'          => $this->toRaw,
            'division_id' => $this->divisionId === null ? '' : (string) $this->divisionId,
            'type_id'     => $this->typeId === null ? '' : (string) $this->typeId,
            'q'           => $this->q,
        ];
    }

    /** Query-string params (without page) for pagination links. */
    public function queryBase(): array
    {
        $params = [];
        if ($this->fromRaw !== '') $params['from'] = $this->fromRaw;
        if ($this->toRaw !== '') $params['to'] = $this->toRaw;
        if ($this->divisionId !== null) $params['division_id'] = (string) $this->divisionId;
        if ($this->typeId !== null) $params['type_id'] = (string) $this->typeId;
        if ($this->q !== '') $params['q'] = $this->q;
        return $params;
    }
}
