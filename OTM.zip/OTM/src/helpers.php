<?php

declare(strict_types=1);

use App\Core\Config;
use App\Core\Csrf;
use App\Core\Session;

/**
 * Global view/config helpers. Loaded by bootstrap.php.
 */

/** HTML-escape. */
function e(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Translate a lang/fa.php key, interpolating {placeholders}. */
function t(string $key, array $replacements = []): string
{
    static $lang = null;
    if ($lang === null) {
        $lang = require dirname(__DIR__) . '/lang/fa.php';
    }
    $text = $lang[$key] ?? $key;
    foreach ($replacements as $name => $value) {
        $text = str_replace('{' . $name . '}', (string) $value, $text);
    }
    return $text;
}

/** Render a number with Persian digits on screen when enabled (DB/CSV stay Latin). */
function num(string|int|float $n): string
{
    $s = (string) $n;
    if (!config('app.persian_digits')) {
        return $s;
    }
    return strtr($s, [
        '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
        '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
    ]);
}

/** Root-relative URL. */
function url(string $path): string
{
    return '/' . ltrim($path, '/');
}

/** Asset URL with ?v=filemtime cache busting. $path is relative to public/assets/. */
function asset(string $path): string
{
    $path = ltrim($path, '/');
    $file = dirname(__DIR__) . '/public/assets/' . $path;
    $version = is_file($file) ? (string) filemtime($file) : '0';
    return '/assets/' . $path . '?v=' . $version;
}

/** Old form input preserved across a validation redirect/re-render. */
function old(string $key, string $default = ''): string
{
    $old = Session::get('_old_input', []);
    $value = $old[$key] ?? $default;
    return is_scalar($value) ? (string) $value : $default;
}

/** Hidden CSRF input for POST forms. */
function csrf_field(): string
{
    return Csrf::field();
}

/** Queue a flash message ('success' | 'error'). */
function flash(string $type, string $msg): void
{
    Session::flash($type, $msg);
}

/** Consume flash messages of a type (used by templates/partials/flash.php). */
function flash_get(string $type): array
{
    return Session::getFlash($type);
}

/** Dot-notation config access. */
function config(string $key, mixed $default = null): mixed
{
    return Config::get($key, $default);
}

/** Raw .env value. */
function env(string $key, ?string $default = null): ?string
{
    return Config::env($key, $default);
}

/** Append a line to storage/logs/app.log (never log passwords or session ids). */
function app_log(string $level, string $message): void
{
    $file = dirname(__DIR__) . '/storage/logs/app.log';
    $line = sprintf("[%s] %s: %s\n", date('Y-m-d H:i:s'), strtoupper($level), $message);
    @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
}
