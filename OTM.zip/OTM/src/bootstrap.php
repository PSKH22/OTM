<?php

declare(strict_types=1);

/**
 * Bootstrap: extension check, autoloader, helpers, config, timezone,
 * error/exception handling. Required by public/index.php and every bin/ script.
 */

use App\Core\Config;

// ── 1. Required extensions — fail fast with a clear message ──
foreach (['pdo_mysql', 'intl', 'mbstring'] as $ext) {
    if (!extension_loaded($ext)) {
        $msg = "Required PHP extension missing: {$ext}. Enable it and restart PHP.";
        if (PHP_SAPI === 'cli') {
            fwrite(STDERR, $msg . PHP_EOL);
            exit(1);
        }
        http_response_code(500);
        echo $msg;
        exit(1);
    }
}
if (!defined('PASSWORD_ARGON2ID')) {
    $msg = 'PHP was built without Argon2id support (PASSWORD_ARGON2ID undefined). Rebuild PHP with Argon2.';
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, $msg . PHP_EOL);
        exit(1);
    }
    http_response_code(500);
    echo $msg;
    exit(1);
}

// ── 2. PSR-4-style autoloader: App\ → src/ ──
spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $file = __DIR__ . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

// ── 3. Global helpers (e, t, num, url, asset, old, csrf_field, flash, …) ──
require __DIR__ . '/helpers.php';

// ── 4. Config from .env ──
Config::load(dirname(__DIR__) . '/.env');

// ── 5. Timezone ──
date_default_timezone_set((string) config('app.timezone', 'Asia/Tehran'));

// ── 6. Error handling: log details, show a generic 500 ──
set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

set_exception_handler(static function (Throwable $e): void {
    $path = $_SERVER['REQUEST_URI'] ?? '(cli)';
    app_log('error', sprintf(
        '%s: %s in %s:%d | %s',
        $e::class,
        $e->getMessage(),
        $e->getFile(),
        $e->getLine(),
        $path
    ));

    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, 'Error: ' . $e->getMessage() . PHP_EOL);
        exit(1);
    }

    if (!headers_sent()) {
        http_response_code(500);
    }
    if (config('app.debug')) {
        echo '<pre>' . e($e->getMessage() . "\n" . $e->getTraceAsString()) . '</pre>';
        return;
    }
    try {
        echo \App\Core\View::render('errors/500', ['title' => t('err_500_title')], ['showNav' => false]);
    } catch (Throwable) {
        echo '<!DOCTYPE html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>500</title><body style="font-family:Tahoma;text-align:center;padding:4rem"><h1>خطای داخلی سرور</h1><p>لطفاً بعداً دوباره تلاش کنید.</p></body></html>';
    }
});
