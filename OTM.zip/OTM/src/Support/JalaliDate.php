<?php

declare(strict_types=1);

namespace App\Support;

use DateTimeImmutable;
use IntlCalendar;
use IntlDateFormatter;

/**
 * Server-side Solar Hijri dates (§7.2) — the server is the only converter
 * for persisted data; the browser sends Jalali strings, PHP converts them.
 *
 * IntlDateFormatter::TRADITIONAL is REQUIRED: otherwise the
 * '@calendar=persian' part of the locale is ignored and the Gregorian
 * calendar is used.
 */
final class JalaliDate
{
    private const WEEKDAY_INDEX = [
        'mon' => 1, 'tue' => 2, 'wed' => 3, 'thu' => 4, 'fri' => 5, 'sat' => 6, 'sun' => 7,
    ];

    /** Persian ۰-۹ and Arabic-Indic ٠-٩ → Latin 0-9. */
    public static function normalizeDigits(string $s): string
    {
        return strtr($s, [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ]);
    }

    /**
     * '1405/07/11' → '2026-10-03', or null if invalid.
     * Strict: after converting, converts back and requires an exact match,
     * so lenient IntlCalendar rollovers (e.g. 1405/07/31, 1404/12/30) fail.
     */
    public static function toGregorian(string $jalali): ?string
    {
        $normalized = self::normalizeDigits(trim($jalali));
        if (!preg_match('/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})$/', $normalized, $m)) {
            return null;
        }
        [$all, $jy, $jm, $jd] = $m;

        $cal = IntlCalendar::createInstance('UTC', 'en_US@calendar=persian');
        $cal->clear();
        $cal->setDate((int) $jy, (int) $jm - 1, (int) $jd); // IntlCalendar month is 0-based

        $iso = $cal->toDateTime()->format('Y-m-d');

        // Round-trip check — reject lenient rollovers.
        $back = self::fromGregorian($iso);
        [$by, $bm, $bd] = array_map('intval', explode('/', $back));
        if ($by !== (int) $jy || $bm !== (int) $jm || $bd !== (int) $jd) {
            return null;
        }

        return $iso;
    }

    /** '2026-10-03' → '1405/07/11' (or '۱۴۰۵/۰۷/۱۱' with $persianDigits). */
    public static function fromGregorian(string $iso, bool $persianDigits = false): string
    {
        $ts = (new DateTimeImmutable($iso . ' 00:00:00', new \DateTimeZone('UTC')))->getTimestamp();
        $result = self::persianFormatter('yyyy/MM/dd')->format($ts);
        $result = is_string($result) ? $result : '';
        return $persianDigits ? strtr($result, array_combine(range(0, 9), ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'])) : $result;
    }

    /** Persian weekday name of a Gregorian ISO date, e.g. 'پنجشنبه'. */
    public static function weekdayName(string $iso): string
    {
        $ts = (new DateTimeImmutable($iso . ' 00:00:00', new \DateTimeZone('UTC')))->getTimestamp();
        $fmt = new IntlDateFormatter(
            'fa_IR',
            IntlDateFormatter::NONE,
            IntlDateFormatter::NONE,
            'UTC',
            IntlDateFormatter::TRADITIONAL,
            'EEEE',
        );
        $name = $fmt->format($ts);
        return is_string($name) ? $name : '';
    }

    /** Is the Gregorian ISO date a weekend day per config (['thu','fri']) ? */
    public static function isWeekendDay(string $iso, array $weekendDays): bool
    {
        $isoWeekday = (int) (new DateTimeImmutable($iso . ' 00:00:00', new \DateTimeZone('UTC')))->format('N');
        foreach ($weekendDays as $day) {
            if ((self::WEEKDAY_INDEX[strtolower(trim((string) $day))] ?? null) === $isoWeekday) {
                return true;
            }
        }
        return false;
    }

    /** Today as Jalali 'YYYY/MM/DD' in Asia/Tehran. */
    public static function today(): string
    {
        $now = new DateTimeImmutable('now', new \DateTimeZone('Asia/Tehran'));
        $result = self::persianFormatter('yyyy/MM/dd')->format($now->getTimestamp());
        return is_string($result) ? $result : '';
    }

    /** Add/subtract days from a Jalali date; returns Jalali 'YYYY/MM/DD'. */
    public static function addDays(string $jalali, int $days): ?string
    {
        $iso = self::toGregorian($jalali);
        if ($iso === null) {
            return null;
        }
        $shifted = (new DateTimeImmutable($iso . ' 00:00:00', new \DateTimeZone('UTC')))
            ->modify(($days >= 0 ? '+' : '') . $days . ' days');
        return self::fromGregorian($shifted->format('Y-m-d'));
    }

    private static function persianFormatter(string $pattern): IntlDateFormatter
    {
        return new IntlDateFormatter(
            'en_US@calendar=persian',   // Latin digits; era ignored by the pattern
            IntlDateFormatter::NONE,
            IntlDateFormatter::NONE,
            'UTC',
            IntlDateFormatter::TRADITIONAL, // REQUIRED — see class docblock
            $pattern,
        );
    }
}
