<?php

declare(strict_types=1);

namespace App\Support;

/**
 * Tiny validation helpers.
 */
final class Validator
{
    public static function required(mixed $v): bool
    {
        return !($v === null || (is_string($v) && trim($v) === '') || (is_array($v) && $v === []));
    }

    public static function intRange(int $v, int $min, int $max): bool
    {
        return $v >= $min && $v <= $max;
    }

    public static function strLength(string $s, int $max): bool
    {
        return mb_strlen($s) <= $max;
    }

    public static function inArray(mixed $v, array $allowed): bool
    {
        return in_array($v, $allowed, true);
    }

    /** Decimal string (Latin digits, dot separator) on a given step, e.g. 0.25. */
    public static function isDecimalStep(string $v, float $step): bool
    {
        if (!preg_match('/^\d+(\.\d{1,2})?$/', $v)) {
            return false;
        }
        $value = (float) $v;
        $steps = round($value / $step);
        return abs($value - $steps * $step) < 1e-9;
    }

    /** Format check only — real validity is enforced by JalaliDate::toGregorian(). */
    public static function jalaliDate(string $s): bool
    {
        return preg_match('/^\d{4}[\/-]\d{1,2}[\/-]\d{1,2}$/', JalaliDate::normalizeDigits(trim($s))) === 1;
    }
}
