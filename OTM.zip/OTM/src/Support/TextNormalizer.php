<?php

declare(strict_types=1);

namespace App\Support;

use InvalidArgumentException;

/**
 * Persian-aware text normalisation (§7.5) — identical rules to normalize.js.
 * Used for the report `q` filter and for personnel.name_search.
 */
final class TextNormalizer
{
    /**
     * 1. Arabic ي (U+064A) → ی (U+06CC); Arabic ك (U+0643) → ک (U+06A9)
     * 2. Persian/Arabic-Indic digits → Latin
     * 3. ZWNJ (U+200C) → space; remove tatweel (U+0640) and Arabic diacritics (U+064B–U+065F)
     * 4. Collapse whitespace, trim, lower-case Latin letters
     */
    public static function normalize(string $s): string
    {
        $s = str_replace(["\u{064A}", "\u{0643}"], ["\u{06CC}", "\u{06A9}"], $s);
        $s = JalaliDate::normalizeDigits($s);
        $s = str_replace("\u{200C}", ' ', $s);
        $s = preg_replace('/[\x{0640}\x{064B}-\x{065F}]/u', '', $s) ?? $s;
        $s = preg_replace('/\s+/u', ' ', $s) ?? $s;
        return mb_strtolower(trim($s));
    }

    /** Trim + validate ^[0-9A-Za-z]+$ (codes may start with 0). */
    public static function normalizePersonnelCode(string $code): string
    {
        $code = JalaliDate::normalizeDigits(trim($code));
        if ($code === '' || !preg_match('/^[0-9A-Za-z]+$/', $code)) {
            throw new InvalidArgumentException('Invalid personnel code: must be Latin digits/letters only.');
        }
        return $code;
    }
}
