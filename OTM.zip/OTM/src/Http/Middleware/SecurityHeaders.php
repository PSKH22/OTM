<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;

/**
 * Global security response headers (§8.7).
 */
final class SecurityHeaders
{
    private const CSP = "default-src 'self'; script-src 'self'; style-src 'self'; "
        . "img-src 'self' data:; font-src 'self'; base-uri 'self'; "
        . "form-action 'self'; frame-ancestors 'none'";

    public function handle(Request $request, callable $next): Response
    {
        $response = $next($request);

        $response->withHeader('Content-Security-Policy', self::CSP);
        $response->withHeader('X-Content-Type-Options', 'nosniff');
        $response->withHeader('X-Frame-Options', 'DENY');
        $response->withHeader('Referrer-Policy', 'same-origin');

        if ($request->isSecure()) {
            $response->withHeader('Strict-Transport-Security', 'max-age=31536000');
        }

        if (Session::userId() !== null) {
            $response->withHeader('Cache-Control', 'no-store');
        }

        return $response;
    }
}
