<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Core\Csrf;
use App\Core\Request;
use App\Core\Response;
use App\Core\View;

/**
 * Verifies the CSRF token on every POST request (§8.5).
 */
final class CsrfGuard
{
    public function handle(Request $request, callable $next): Response
    {
        if ($request->method() === 'POST') {
            $token = (string) $request->input('csrf_token', '');
            if (!Csrf::validate($token)) {
                app_log('warn', 'CSRF failure on ' . $request->path() . ' from ' . $request->ip());
                return Response::html(View::render('errors/403', [
                    'title' => t('err_403_title'),
                ], ['showNav' => false]), 403);
            }
        }

        return $next($request);
    }
}
