<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;

/**
 * Idle (30 min) and absolute (8 h) session timeouts (§8.4).
 */
final class SessionTimeout
{
    public function handle(Request $request, callable $next): Response
    {
        if (Session::userId() !== null) {
            $now = time();
            $idleLimit = (int) config('app.session_idle_minutes', 30) * 60;
            $absoluteLimit = (int) config('app.session_absolute_hours', 8) * 3600;

            $lastActivity = Session::lastActivity() ?? $now;
            $createdAt = Session::createdAt() ?? $now;

            if (($now - $lastActivity) > $idleLimit || ($now - $createdAt) > $absoluteLimit) {
                app_log('info', 'Session expired for user ' . Session::userId());
                Session::destroy();
                Session::start();
                return Response::redirect(url('/login'));
            }

            Session::setLastActivity($now);
        }

        return $next($request);
    }
}
