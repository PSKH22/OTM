<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Repositories\UserRepository;

/**
 * Requires an authenticated user. The user (with division) is re-loaded from
 * the DB on EVERY request so deactivation and division changes apply at once
 * (§8.4). The division is never cached in the session.
 */
final class RequireAuth
{
    public function handle(Request $request, callable $next): Response
    {
        $userId = Session::userId();

        if ($userId === null) {
            $this->storeIntended($request);
            return Response::redirect(url('/login'));
        }

        $user = (new UserRepository(Database::pdo()))->findById($userId);

        if ($user === null || (int) $user['is_active'] !== 1) {
            app_log('info', "Rejected inactive/missing user id {$userId}");
            Session::destroy();
            Session::start();
            return Response::redirect(url('/login'));
        }

        $request->setUser($user);
        return $next($request);
    }

    /** Remember the intended page — local paths only (single leading '/', never '//'). */
    private function storeIntended(Request $request): void
    {
        $target = $request->path();
        $qs = (string) ($_SERVER['QUERY_STRING'] ?? '');
        if ($qs !== '') {
            $target .= '?' . $qs;
        }
        if (str_starts_with($target, '/') && !str_starts_with($target, '//')) {
            Session::set('_intended', $target);
        }
    }
}
