<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\View;
use App\Input\LoginInput;
use App\Repositories\LoginAttemptRepository;
use App\Repositories\UserRepository;
use App\Services\AuthService;

/**
 * Login / logout (§8.1, §9.1). No SQL or business rules here.
 */
final class AuthController
{
    public function showLogin(Request $req): Response
    {
        if (Session::userId() !== null) {
            return Response::redirect(url('/overtime/new'));
        }
        Session::delete('_old_input');
        return Response::html(View::render('login', [
            'title' => t('login'),
        ], ['showNav' => false]));
    }

    public function login(Request $req): Response
    {
        $auth = new AuthService(
            new UserRepository(Database::pdo()),
            new LoginAttemptRepository(Database::pdo()),
        );

        $dto = LoginInput::fromPost($req->all());
        $errors = $dto->validate();

        if ($errors === []) {
            $result = $auth->attempt($dto->username, $dto->password, $req->ip());
            if ($result['success']) {
                Session::delete('_old_input');
                // Local paths only: single leading '/', never '//' or a scheme.
                $intended = Session::get('_intended');
                Session::delete('_intended');
                $target = (is_string($intended) && str_starts_with($intended, '/') && !str_starts_with($intended, '//'))
                    ? $intended
                    : '/overtime/new';
                return Response::redirect(url($target));
            }
            $errors = [$result['error']];
        }

        // Generic failure: same message for unknown user and wrong password (422).
        Session::set('_old_input', ['username' => $dto->username]);
        $response = Response::html(View::render('login', [
            'title' => t('login'),
            'error' => $errors[0],
        ], ['showNav' => false]), 422);
        Session::delete('_old_input');
        return $response;
    }

    public function logout(Request $req): Response
    {
        $userId = Session::userId();
        app_log('info', "Logout: user_id=" . ($userId ?? 'none'));

        Session::destroy();
        Session::start();
        flash('success', t('flash_logout'));

        return Response::redirect(url('/login'));
    }
}
