<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Core\Csrf;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\View;
use App\Input\DeleteEntryInput;
use App\Input\OvertimeSubmission;
use App\Repositories\LookupRepository;
use App\Repositories\PersonnelRepository;
use App\Services\CycleService;
use App\Services\OvertimeService;
use App\Support\JalaliDate;

/**
 * Submit / delete overtime (§9.2, §9.4). No SQL or business rules here.
 */
final class OvertimeController
{
    public function create(Request $req): Response
    {
        return $this->renderForm($req);
    }

    public function store(Request $req): Response
    {
        $user = $req->user();

        // Double-submit guard: the one-time nonce is consumed (§8.5).
        $nonce = (string) $req->input('form_nonce', '');
        if (!Csrf::consumeFormNonce($nonce)) {
            return $this->renderForm($req, ['general' => t('err_duplicate_submit')], $this->oldFrom($req), 422);
        }

        $input = OvertimeSubmission::fromPost($req->all());
        $errors = $input->validate();

        $type = null;
        if (!isset($errors['type_id'])) {
            $type = (new LookupRepository(Database::pdo()))->findType($input->typeId);
            if ($type === null) {
                $errors['type_id'] = t('err_invalid_choice');
            }
        }

        if ($errors !== [] || $type === null) {
            return $this->renderForm($req, $errors, $this->oldFrom($req, $input), 422);
        }

        $result = (new OvertimeService(Database::pdo()))->submitBatch($input, $user, $type);

        if (!($result['success'] ?? false)) {
            if ($result['forbidden'] ?? false) {
                app_log('warn', sprintf(
                    'Authorization failure: user=%s ip=%s route=/overtime',
                    $user['id'],
                    $req->ip(),
                ));
                return Response::html(View::render('errors/403', ['title' => t('err_403_title')]), 403);
            }
            return $this->renderForm($req, $result['errors'] ?? ['general' => t('err_batch_rejected')], $this->oldFrom($req, $input), 422);
        }

        // Success → Post/Redirect/Get with flash (§9.2).
        flash('success', t('flash_submit_success', [
            'count' => num($result['count']),
            'type'  => $type['name'],
            'date'  => num($input->dateJalali),
            'hours' => num($input->hoursNormalized),
        ]));
        if ($result['cycleClosed'] ?? false) {
            flash('success', t('flash_cycle_closed', [
                'n'    => num($result['newCycleNumber'] - 1),
                'next' => num($result['newCycleNumber']),
            ]));
        }

        return Response::redirect(url('/overtime/new'));
    }

    public function delete(Request $req): Response
    {
        $user = $req->user();
        $input = DeleteEntryInput::fromPost($req->all());
        $errors = $input->validate();

        // A bad `back` target is downgraded to the plain reports page.
        $back = str_starts_with($input->back, '/reports') ? $input->back : '/reports';

        if (isset($errors['entry_id'])) {
            flash('error', t('err_entry_not_found'));
            return Response::redirect(url($back));
        }

        $result = (new OvertimeService(Database::pdo()))->deleteEntry($input->entryId, $user, $req->ip());

        if ($result['forbidden'] ?? false) {
            return Response::html(View::render('errors/403', ['title' => t('err_403_title')]), 403);
        }
        if ($result['notFound'] ?? false) {
            flash('error', t('err_entry_not_found'));
            return Response::redirect(url($back));
        }

        flash('success', t('flash_delete_success'));
        if ($result['cycleReopened'] ?? false) {
            flash('success', t('flash_cycle_reopened', ['n' => num($result['reopenedNumber'])]));
        }

        return Response::redirect(url($back));
    }

    /** Re-render the submit form (optionally with errors and old input). */
    private function renderForm(Request $req, array $errors = [], array $old = [], int $status = 200): Response
    {
        $pdo = Database::pdo();
        $user = $req->user();
        $windowDays = (int) config('app.overtime_date_window_days', 366);
        $today = JalaliDate::today();

        return Response::html(View::render('overtime/new', [
            'title'          => t('nav_submit'),
            'types'          => (new LookupRepository($pdo))->overtimeTypes(),
            'divisions'      => (new LookupRepository($pdo))->divisions(),
            'userDivisionId' => (int) $user['division_id'],
            'personnel'      => (new PersonnelRepository($pdo))->activeWithCycleStatus(),
            'cycleSummary'   => (new CycleService($pdo))->summaryStrip(),
            'errors'         => $errors,
            'old'            => $old,
            'weekendDays'    => (array) config('app.weekend_days', ['thu', 'fri']),
            'formNonce'      => Csrf::generateFormNonce(),
            'dateMin'        => JalaliDate::addDays($today, -$windowDays),
            'dateMax'        => JalaliDate::addDays($today, $windowDays),
            'todayJalali'    => $today,
        ], [
            'activeNav' => 'submit',
            'user'      => $user,
        ]), $status);
    }

    /** Old input for re-rendering (including ticked personnel). */
    private function oldFrom(Request $req, ?OvertimeSubmission $input = null): array
    {
        if ($input !== null) {
            return [
                'type_id'       => (string) $input->typeId,
                'date'          => $input->dateJalali,
                'hours'         => $input->hoursNormalized,
                'description'   => $input->description ?? '',
                'personnel_ids' => $input->personnelIds,
            ];
        }
        return [
            'type_id'       => (string) $req->input('type_id', ''),
            'date'          => (string) $req->input('date', ''),
            'hours'         => (string) $req->input('hours', ''),
            'description'   => (string) $req->input('description', ''),
            'personnel_ids' => array_map('intval', (array) $req->input('personnel_ids', [])),
        ];
    }
}
