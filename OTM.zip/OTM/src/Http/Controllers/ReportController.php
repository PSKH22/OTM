<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\View;
use App\Input\ReportFilter;
use App\Repositories\LookupRepository;
use App\Repositories\OvertimeRepository;
use App\Services\CsvExporter;
use App\Services\ReportService;
use App\Support\JalaliDate;

/**
 * Reports page + CSV export (§9.3, §9.5). No SQL or business rules here.
 */
final class ReportController
{
    public function index(Request $req): Response
    {
        $user = $req->user();
        $pdo = Database::pdo();

        $filter = ReportFilter::fromQuery($req->allQuery());
        $errors = $filter->validate();

        $rows = [];
        $totals = ['count' => 0, 'hours' => 0.0];
        $pagination = ['page' => 1, 'totalPages' => 1];

        // Invalid filter → error beside the field and NO query is run (§9.3).
        if ($errors === []) {
            $service = new ReportService(new OvertimeRepository($pdo));
            $result = $service->query($filter, (int) config('app.report_page_size', 50));
            $rows = array_map([self::class, 'presentRow'], $result['rows']);
            $totals = ['count' => $result['total'], 'hours' => $this->formatHours((string) $service->totals($filter)['hours'])];
            $pagination = ['page' => $result['page'], 'totalPages' => $result['totalPages']];
        }

        $lookup = new LookupRepository($pdo);

        return Response::html(View::render('reports/index', [
            'title'          => t('nav_reports'),
            'filter'         => $filter->rawValues(),
            'divisions'      => $lookup->divisions(),
            'types'          => $lookup->overtimeTypes(),
            'rows'           => $rows,
            'totals'         => $totals,
            'pagination'     => $pagination,
            'queryBase'      => $filter->queryBase(),
            'userDivisionId' => (int) $user['division_id'],
            'errors'         => $errors,
        ], [
            'activeNav' => 'reports',
            'user'      => $user,
        ]));
    }

    public function export(Request $req): Response
    {
        $filter = ReportFilter::fromQuery($req->allQuery());
        if ($filter->validate() !== []) {
            flash('error', t('err_invalid_date'));
            return Response::redirect(url('/reports'));
        }

        $service = new ReportService(new OvertimeRepository(Database::pdo()));
        return (new CsvExporter($service))->export($filter, JalaliDate::today());
    }

    /** Presentation conversion: Gregorian → Jalali, trim hour decimals. */
    private static function presentRow(array $row): array
    {
        $row['date_jalali'] = JalaliDate::fromGregorian((string) $row['overtime_date']);
        $row['hours'] = self::formatHoursStatic((string) $row['hours']);
        $row['cycle_number'] = $row['cycle_number'] === null ? null : (int) $row['cycle_number'];
        return $row;
    }

    private function formatHours(string $hours): string
    {
        return self::formatHoursStatic($hours);
    }

    private static function formatHoursStatic(string $hours): string
    {
        $trimmed = rtrim(rtrim($hours, '0'), '.');
        return $trimmed === '' ? '0' : $trimmed;
    }
}
