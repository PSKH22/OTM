<?php

declare(strict_types=1);

namespace App\Core;

use PDO;

/**
 * PDO factory. Real prepared statements, exceptions, utf8mb4, UTC session zone.
 */
final class Database
{
    private static ?PDO $pdo = null;

    public static function connect(): PDO
    {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            Config::env('DB_HOST', '127.0.0.1'),
            Config::env('DB_PORT', '3306'),
            Config::env('DB_NAME', 'overtime_mgmt'),
        );

        $pdo = new PDO($dsn, Config::env('DB_USER', ''), Config::env('DB_PASS', ''), [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);

        $pdo->exec("SET NAMES utf8mb4");
        $pdo->exec("SET time_zone = '+00:00'");

        return $pdo;
    }

    /** Shared connection for the current process. */
    public static function pdo(): PDO
    {
        return self::$pdo ??= self::connect();
    }
}
