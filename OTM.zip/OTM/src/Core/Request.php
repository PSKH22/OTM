<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Typed access to the current HTTP request. Services never see superglobals.
 */
final class Request
{
    private ?array $user = null;

    /**
     * @param array<string, mixed> $query
     * @param array<string, mixed> $body
     * @param array<string, mixed> $server
     */
    public function __construct(
        private readonly array $query,
        private readonly array $body,
        private readonly array $server,
    ) {}

    public static function fromGlobals(): self
    {
        return new self($_GET, $_POST, $_SERVER);
    }

    public function method(): string
    {
        return strtoupper((string) ($this->server['REQUEST_METHOD'] ?? 'GET'));
    }

    public function path(): string
    {
        $path = parse_url((string) ($this->server['REQUEST_URI'] ?? '/'), PHP_URL_PATH);
        $path = is_string($path) ? $path : '/';
        $path = rtrim($path, '/');
        return $path === '' ? '/' : $path;
    }

    public function query(string $key, mixed $default = null): mixed
    {
        return $this->query[$key] ?? $default;
    }

    public function input(string $key, mixed $default = null): mixed
    {
        return $this->body[$key] ?? $default;
    }

    /** All POST fields (for old-input preservation). */
    public function all(): array
    {
        return $this->body;
    }

    /** All query parameters (for filter DTOs). */
    public function allQuery(): array
    {
        return $this->query;
    }

    public function ip(): string
    {
        return (string) ($this->server['REMOTE_ADDR'] ?? '0.0.0.0');
    }

    public function isSecure(): bool
    {
        return ($this->server['HTTPS'] ?? '') === 'on'
            || (int) ($this->server['SERVER_PORT'] ?? 80) === 443;
    }

    /** Current user (loaded per request by RequireAuth). */
    public function setUser(array $user): void
    {
        $this->user = $user;
    }

    public function user(): ?array
    {
        return $this->user;
    }
}
