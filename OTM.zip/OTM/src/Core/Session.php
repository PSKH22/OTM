<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Secure native-session wrapper (§8.4).
 * Static facade — one session per request.
 */
final class Session
{
    private static bool $started = false;

    public static function start(): void
    {
        if (self::$started || PHP_SAPI === 'cli') {
            return;
        }

        $savePath = dirname(__DIR__, 2) . '/storage/sessions';
        if (!is_dir($savePath)) {
            mkdir($savePath, 0700, true);
        }

        session_name((string) config('app.session_name', 'ot_sid'));
        session_save_path($savePath);
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'secure'   => (bool) config('app.cookie_secure', true),
            'httponly'  => true,
            'samesite'  => 'Lax',
        ]);
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');

        session_start();
        self::$started = true;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        return $_SESSION[$key] ?? $default;
    }

    public static function set(string $key, mixed $value): void
    {
        $_SESSION[$key] = $value;
    }

    public static function has(string $key): bool
    {
        return isset($_SESSION[$key]);
    }

    public static function delete(string $key): void
    {
        unset($_SESSION[$key]);
    }

    public static function flash(string $type, string $msg): void
    {
        $_SESSION['_flash'][$type][] = $msg;
    }

    /** Consume (read + clear) flash messages of a type. */
    public static function getFlash(string $type): array
    {
        $messages = $_SESSION['_flash'][$type] ?? [];
        unset($_SESSION['_flash'][$type]);
        return is_array($messages) ? $messages : [];
    }

    /** Regenerate the session id (at login). */
    public static function regenerate(): void
    {
        session_regenerate_id(true);
    }

    public static function destroy(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], '', $params['secure'], $params['httponly']);
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
        self::$started = false;
    }

    public static function userId(): ?int
    {
        $id = $_SESSION['user_id'] ?? null;
        return $id === null ? null : (int) $id;
    }

    public static function setUserId(int $id): void
    {
        $_SESSION['user_id'] = $id;
    }

    public static function createdAt(): ?int
    {
        $ts = $_SESSION['created_at'] ?? null;
        return $ts === null ? null : (int) $ts;
    }

    public static function setCreatedAt(int $ts): void
    {
        $_SESSION['created_at'] = $ts;
    }

    public static function lastActivity(): ?int
    {
        $ts = $_SESSION['last_activity'] ?? null;
        return $ts === null ? null : (int) $ts;
    }

    public static function setLastActivity(int $ts): void
    {
        $_SESSION['last_activity'] = $ts;
    }
}
