<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Tiny array-based router: exact path matching only (§4.3).
 * Routes come from config/routes.php:
 *   ['GET', '/path', [Controller::class, 'method'], [Middleware::class, …]]
 */
final class Router
{
    /** @var array<int, array{method: string, path: string, handler: array, middleware: array}> */
    private array $routes = [];

    public function add(string $method, string $path, callable|array $handler, array $middleware = []): void
    {
        $this->routes[] = [
            'method'     => strtoupper($method),
            'path'       => $path,
            'handler'    => $handler,
            'middleware' => $middleware,
        ];
    }

    public function loadFromFile(string $file): void
    {
        foreach (require $file as $route) {
            [$method, $path, $handler] = $route;
            $middleware = $route[3] ?? [];
            $this->add($method, $path, $handler, $middleware);
        }
    }

    public function dispatch(Request $request): Response
    {
        $matchedPath = false;

        foreach ($this->routes as $route) {
            if ($route['path'] !== $request->path()) {
                continue;
            }
            $matchedPath = true;
            if ($route['method'] !== $request->method()) {
                continue;
            }
            return $this->runPipeline($route, $request);
        }

        if ($matchedPath) {
            return Response::html(View::render('errors/404', [
                'title' => t('err_404_title'),
            ], ['showNav' => false]), 405);
        }

        return Response::html(View::render('errors/404', [
            'title' => t('err_404_title'),
        ], ['showNav' => false]), 404);
    }

    private function runPipeline(array $route, Request $request): Response
    {
        $core = function (Request $req) use ($route): Response {
            $handler = $route['handler'];
            if ($handler instanceof \Closure) {
                return $handler($req);
            }
            [$class, $method] = $handler;
            $controller = new $class();
            return $controller->$method($req);
        };

        // Outermost first
        $next = $core;
        foreach (array_reverse($route['middleware']) as $middlewareClass) {
            $next = static function (Request $req) use ($middlewareClass, $next): Response {
                return (new $middlewareClass())->handle($req, $next);
            };
        }

        return $next($request);
    }
}
