<?php

declare(strict_types=1);

namespace App\Core;

/**
 * CSRF token + one-time form nonce (§8.5).
 */
final class Csrf
{
    /** Per-session token (64 hex chars). */
    public static function token(): string
    {
        $token = Session::get('_csrf_token');
        if (!is_string($token) || strlen($token) !== 64) {
            $token = bin2hex(random_bytes(32));
            Session::set('_csrf_token', $token);
        }
        return $token;
    }

    public static function validate(string $token): bool
    {
        return hash_equals(self::token(), $token);
    }

    /** Hidden input HTML for POST forms. */
    public static function field(): string
    {
        return '<input type="hidden" name="csrf_token" value="' . e(self::token()) . '">';
    }

    /** One-time nonce for double-submit protection on the overtime form. */
    public static function generateFormNonce(): string
    {
        $nonce = bin2hex(random_bytes(32));
        Session::set('_form_nonce', $nonce);
        return $nonce;
    }

    /** Validate + delete (single use). */
    public static function consumeFormNonce(string $nonce): bool
    {
        $stored = Session::get('_form_nonce');
        Session::delete('_form_nonce');
        return is_string($stored) && $nonce !== '' && hash_equals($stored, $nonce);
    }
}
