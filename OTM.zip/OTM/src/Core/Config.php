<?php

declare(strict_types=1);

namespace App\Core;

use RuntimeException;

/**
 * Loads .env (parse_ini_file, raw scanner) and merges config/*.php arrays.
 * Access via Config::get('app.key') or the config() helper.
 */
final class Config
{
    /** @var array<string, string> */
    private static array $env = [];

    /** @var array<string, array<string, mixed>> */
    private static array $items = [];

    public static function load(string $envPath): void
    {
        if (!is_file($envPath)) {
            throw new RuntimeException(
                "Configuration file missing: {$envPath} — copy .env.example to .env and fill in the values."
            );
        }

        $parsed = parse_ini_file($envPath, false, INI_SCANNER_RAW);
        if ($parsed === false) {
            throw new RuntimeException("Unable to parse configuration file: {$envPath}");
        }

        self::$env = $parsed;
        self::$items['app'] = require dirname(__DIR__, 2) . '/config/app.php';
    }

    /** Raw env value (string) with default. */
    public static function env(string $key, ?string $default = null): ?string
    {
        $value = self::$env[$key] ?? null;
        return ($value === null || $value === '') ? $default : $value;
    }

    /** Dot-notation access into merged config arrays, e.g. 'app.timezone'. */
    public static function get(string $key, mixed $default = null): mixed
    {
        $segments = explode('.', $key);
        $value = self::$items;
        foreach ($segments as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) {
                return $default;
            }
            $value = $value[$segment];
        }
        return $value;
    }
}
