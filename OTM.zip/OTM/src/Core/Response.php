<?php

declare(strict_types=1);

namespace App\Core;

/**
 * HTTP response: HTML, redirect, or streamed CSV.
 */
final class Response
{
    /** @var array<string, string> */
    private array $headers = [];

    /** @var callable|null streams the body (CSV) instead of $body */
    private mixed $writer = null;

    private function __construct(
        private string $body = '',
        private int $status = 200,
    ) {}

    public static function html(string $body, int $status = 200): self
    {
        $r = new self($body, $status);
        $r->headers['Content-Type'] = 'text/html; charset=utf-8';
        return $r;
    }

    public static function redirect(string $url, int $status = 302): self
    {
        $r = new self('', $status);
        $r->headers['Location'] = $url;
        return $r;
    }

    /**
     * CSV download: sets headers, writes the UTF-8 BOM, then calls $writer
     * with an open php://output handle.
     */
    public static function csv(string $filename, callable $writer): self
    {
        $r = new self('', 200);
        $r->headers['Content-Type'] = 'text/csv; charset=utf-8';
        $r->headers['Content-Disposition'] = 'attachment; filename="' . $filename . '"';
        $r->headers['Cache-Control'] = 'no-store';
        $r->writer = $writer;
        return $r;
    }

    public function withHeader(string $name, string $value): self
    {
        $this->headers[$name] = $value;
        return $this;
    }

    public function status(): int
    {
        return $this->status;
    }

    /** @return array<string, string> */
    public function headers(): array
    {
        return $this->headers;
    }

    public function send(): void
    {
        if (!headers_sent()) {
            http_response_code($this->status);
            foreach ($this->headers as $name => $value) {
                header($name . ': ' . $value);
            }
        }

        if ($this->writer !== null) {
            $out = fopen('php://output', 'wb');
            fwrite($out, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel reads Persian correctly
            ($this->writer)($out);
            fclose($out);
            return;
        }

        echo $this->body;
    }
}
