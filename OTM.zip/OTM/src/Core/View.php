<?php

declare(strict_types=1);

namespace App\Core;

use RuntimeException;

/**
 * PHP-template renderer. Templates live in templates/ and use e()/t()/num().
 */
final class View
{
    private const TEMPLATE_DIR = __DIR__ . '/../../templates';

    /**
     * Render a page template wrapped in the layout.
     *
     * @param array<string, mixed> $data    template data (should include 'title')
     * @param array<string, mixed> $layout  layout options: activeNav, showNav, user
     */
    public static function render(string $template, array $data = [], array $layout = []): string
    {
        $content = self::renderPartial($template, $data);
        return self::renderPartial('layout', $layout + [
            'title'   => $data['title'] ?? t('app_name'),
            'content' => $content,
        ]);
    }

    /** Render a template/partial without the layout. */
    public static function renderPartial(string $partial, array $data = []): string
    {
        $file = self::TEMPLATE_DIR . '/' . $partial . '.php';
        if (!is_file($file)) {
            throw new RuntimeException("Template not found: {$partial}");
        }
        ob_start();
        try {
            extract($data, EXTR_SKIP);
            require $file;
            return (string) ob_get_clean();
        } catch (\Throwable $e) {
            ob_end_clean();
            throw $e;
        }
    }
}
