<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

/**
 * Per-division cycles (§5.1). Locking methods assume the caller holds a
 * transaction — openCycleForUpdate() must be its FIRST statement.
 */
final class CycleRepository
{
    public function __construct(private readonly PDO $pdo) {}

    /** Lock and return the division's open cycle. FIRST statement in the transaction. */
    public function openCycleForUpdate(int $divisionId): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT id, division_id, cycle_number
               FROM cycles
              WHERE division_id = :div AND closed_at IS NULL
              FOR UPDATE'
        );
        $stmt->execute(['div' => $divisionId]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    public function closeCycle(int $cycleId): void
    {
        $stmt = $this->pdo->prepare('UPDATE cycles SET closed_at = UTC_TIMESTAMP() WHERE id = :id');
        $stmt->execute(['id' => $cycleId]);
    }

    /** @return int the new cycle id */
    public function openNextCycle(int $divisionId, int $nextNumber): int
    {
        $stmt = $this->pdo->prepare(
            'INSERT INTO cycles (division_id, cycle_number) VALUES (:div, :num)'
        );
        $stmt->execute(['div' => $divisionId, 'num' => $nextNumber]);
        return (int) $this->pdo->lastInsertId();
    }

    public function deleteCycle(int $cycleId): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM cycles WHERE id = :id');
        $stmt->execute(['id' => $cycleId]);
    }

    public function reopenCycle(int $cycleId): void
    {
        $stmt = $this->pdo->prepare('UPDATE cycles SET closed_at = NULL WHERE id = :id');
        $stmt->execute(['id' => $cycleId]);
    }

    public function mostRecentClosedCycle(int $divisionId): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT id, division_id, cycle_number
               FROM cycles
              WHERE division_id = :div AND closed_at IS NOT NULL
              ORDER BY cycle_number DESC
              LIMIT 1'
        );
        $stmt->execute(['div' => $divisionId]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    /**
     * One row per division: name · cycle number · done/total (§6.5).
     *
     * @return array<int, array{division_id: int, name: string, cycle_id: int, cycle_number: int, total_active: int, done: int}>
     */
    public function summaryStrip(): array
    {
        return $this->pdo->query(
            'SELECT d.id AS division_id, d.name, c.id AS cycle_id, c.cycle_number,
                    COUNT(p.id) AS total_active,
                    COALESCE(SUM(EXISTS (SELECT 1 FROM overtime_entries e
                                          WHERE e.cycle_id = c.id AND e.personnel_id = p.id)), 0) AS done
               FROM divisions d
               JOIN cycles c ON c.division_id = d.id AND c.closed_at IS NULL
               LEFT JOIN personnel p ON p.division_id = d.id AND p.is_active = 1
              GROUP BY d.id, d.name, c.id, c.cycle_number
              ORDER BY d.id'
        )->fetchAll();
    }

    /** Active personnel of the division with NO entry in the given cycle. */
    public function remainingCount(int $divisionId, int $cycleId): int
    {
        $stmt = $this->pdo->prepare(
            'SELECT COUNT(*)
               FROM personnel p
              WHERE p.division_id = :div AND p.is_active = 1
                AND NOT EXISTS (SELECT 1 FROM overtime_entries e
                                 WHERE e.cycle_id = :cycle AND e.personnel_id = p.id)'
        );
        $stmt->execute(['div' => $divisionId, 'cycle' => $cycleId]);
        return (int) $stmt->fetchColumn();
    }

    /** Entries count in a cycle. */
    public function entryCount(int $cycleId): int
    {
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM overtime_entries WHERE cycle_id = :cycle');
        $stmt->execute(['cycle' => $cycleId]);
        return (int) $stmt->fetchColumn();
    }
}
