<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

/** Deletion audit trail (§5.5). */
final class AuditLogRepository
{
    public function __construct(private readonly PDO $pdo) {}

    public function log(int $userId, string $action, ?int $entityId, array $details, string $ip): void
    {
        $stmt = $this->pdo->prepare(
            'INSERT INTO audit_log (user_id, action, entity_id, details, ip_address, created_at)
             VALUES (:user_id, :action, :entity_id, :details, INET6_ATON(:ip), UTC_TIMESTAMP())'
        );
        $stmt->execute([
            'user_id'   => $userId,
            'action'    => $action,
            'entity_id' => $entityId,
            'details'   => json_encode($details, JSON_UNESCAPED_UNICODE),
            'ip'        => $ip,
        ]);
    }
}
