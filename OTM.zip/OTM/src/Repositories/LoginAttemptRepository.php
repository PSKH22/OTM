<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

/**
 * Brute-force bookkeeping (§8.3). IPs stored via INET6_ATON (VARBINARY(16)).
 */
final class LoginAttemptRepository
{
    public function __construct(private readonly PDO $pdo) {}

    public function record(string $username, string $ip, bool $success): void
    {
        $stmt = $this->pdo->prepare(
            'INSERT INTO login_attempts (username, ip_address, was_successful, attempted_at)
             VALUES (:username, INET6_ATON(:ip), :success, UTC_TIMESTAMP())'
        );
        $stmt->execute([
            'username' => mb_substr(strtolower($username), 0, 64),
            'ip'       => $ip,
            'success'  => $success ? 1 : 0,
        ]);
    }

    /** Failed attempts for one (username, IP) in the last N minutes. */
    public function countRecent(string $username, string $ip, int $minutes): int
    {
        $stmt = $this->pdo->prepare(
            'SELECT COUNT(*) FROM login_attempts
              WHERE username = :username
                AND ip_address = INET6_ATON(:ip)
                AND was_successful = 0
                AND attempted_at >= UTC_TIMESTAMP() - INTERVAL :minutes MINUTE'
        );
        $stmt->bindValue('username', mb_substr(strtolower($username), 0, 64));
        $stmt->bindValue('ip', $ip);
        $stmt->bindValue('minutes', $minutes, PDO::PARAM_INT);
        $stmt->execute();
        return (int) $stmt->fetchColumn();
    }

    /** Failed attempts from one IP in the last N minutes. */
    public function countRecentByIp(string $ip, int $minutes): int
    {
        $stmt = $this->pdo->prepare(
            'SELECT COUNT(*) FROM login_attempts
              WHERE ip_address = INET6_ATON(:ip)
                AND was_successful = 0
                AND attempted_at >= UTC_TIMESTAMP() - INTERVAL :minutes MINUTE'
        );
        $stmt->bindValue('ip', $ip);
        $stmt->bindValue('minutes', $minutes, PDO::PARAM_INT);
        $stmt->execute();
        return (int) $stmt->fetchColumn();
    }

    public function clearForUserIp(string $username, string $ip): void
    {
        $stmt = $this->pdo->prepare(
            'DELETE FROM login_attempts
              WHERE username = :username AND ip_address = INET6_ATON(:ip) AND was_successful = 0'
        );
        $stmt->execute([
            'username' => mb_substr(strtolower($username), 0, 64),
            'ip'       => $ip,
        ]);
    }

    /** Drop rows older than N days (called by bin/prune-login-attempts.php). */
    public function prune(int $daysOld): int
    {
        $stmt = $this->pdo->prepare(
            'DELETE FROM login_attempts WHERE attempted_at < UTC_TIMESTAMP() - INTERVAL :days DAY'
        );
        $stmt->bindValue('days', $daysOld, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->rowCount();
    }
}
