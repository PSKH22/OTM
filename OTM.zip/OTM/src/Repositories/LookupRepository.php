<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

/** Divisions + overtime types reference data. */
final class LookupRepository
{
    public function __construct(private readonly PDO $pdo) {}

    /** @return array<int, array{id: int, name: string}> */
    public function divisions(): array
    {
        return $this->pdo->query('SELECT id, name FROM divisions ORDER BY id')->fetchAll();
    }

    /** @return array<int, array{id: int, code: string, name: string, uses_cycle: int, day_rule: string}> */
    public function overtimeTypes(): array
    {
        return $this->pdo->query(
            'SELECT id, code, name, uses_cycle, day_rule FROM overtime_types ORDER BY sort_order'
        )->fetchAll();
    }

    public function findType(int $id): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT id, code, name, uses_cycle, day_rule FROM overtime_types WHERE id = :id'
        );
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }
}
