<?php

declare(strict_types=1);

namespace App\Repositories;

use Collator;
use PDO;

final class PersonnelRepository
{
    public function __construct(private readonly PDO $pdo) {}

    /**
     * All active personnel with cycle status measured against THEIR OWN
     * division's open cycle (§6.5). Sorted in PHP with Collator('fa_IR').
     *
     * @return array<int, array<string, mixed>>
     */
    public function activeWithCycleStatus(): array
    {
        $rows = $this->pdo->query(
            'SELECT p.id, p.personnel_code, p.full_name, p.division_id, d.name AS division_name,
                    EXISTS (SELECT 1
                              FROM overtime_entries e
                              JOIN cycles c ON c.id = e.cycle_id
                                           AND c.closed_at IS NULL
                                           AND c.division_id = p.division_id
                             WHERE e.personnel_id = p.id) AS used_in_open_cycle
               FROM personnel p
               JOIN divisions d ON d.id = p.division_id
              WHERE p.is_active = 1'
        )->fetchAll();

        $collator = new Collator('fa_IR');
        usort(
            $rows,
            static fn (array $a, array $b): int => $collator->compare($a['full_name'], $b['full_name']),
        );

        return $rows;
    }

    /**
     * @param int[] $ids
     * @return array<int, array<string, mixed>> keyed by id
     */
    public function findByIds(array $ids): array
    {
        if ($ids === []) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $this->pdo->prepare(
            "SELECT id, personnel_code, full_name, division_id, is_active
               FROM personnel
              WHERE id IN ($placeholders)"
        );
        $stmt->execute(array_values($ids));
        $rows = [];
        foreach ($stmt->fetchAll() as $row) {
            $rows[(int) $row['id']] = $row;
        }
        return $rows;
    }

    /** @return array<int, array<string, mixed>> */
    public function activeByDivision(int $divisionId): array
    {
        $stmt = $this->pdo->prepare(
            'SELECT id, personnel_code, full_name, division_id
               FROM personnel
              WHERE division_id = :div AND is_active = 1'
        );
        $stmt->execute(['div' => $divisionId]);
        return $stmt->fetchAll();
    }
}
