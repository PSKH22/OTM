<?php

declare(strict_types=1);

namespace App\Repositories;

use App\Input\ReportFilter;
use PDO;

final class OvertimeRepository
{
    public function __construct(private readonly PDO $pdo) {}

    /** One INSERT per row (inside the caller's transaction). */
    public function insertBatch(array $rows): void
    {
        $stmt = $this->pdo->prepare(
            'INSERT INTO overtime_entries
                 (personnel_id, division_id, overtime_type_id, overtime_date, hours, description, cycle_id, created_by)
             VALUES
                 (:personnel_id, :division_id, :type_id, :date, :hours, :description, :cycle_id, :created_by)'
        );
        foreach ($rows as $row) {
            $stmt->execute([
                'personnel_id' => $row['personnel_id'],
                'division_id'  => $row['division_id'],
                'type_id'      => $row['overtime_type_id'],
                'date'         => $row['overtime_date'],
                'hours'        => $row['hours'],
                'description'  => $row['description'],
                'cycle_id'     => $row['cycle_id'],
                'created_by'   => $row['created_by'],
            ]);
        }
    }

    /**
     * Personnel ids that already have an entry in the cycle.
     *
     * @param int[] $personnelIds
     * @return int[]
     */
    public function existingInCycle(int $cycleId, array $personnelIds): array
    {
        if ($personnelIds === []) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($personnelIds), '?'));
        $stmt = $this->pdo->prepare(
            "SELECT personnel_id FROM overtime_entries
              WHERE cycle_id = ? AND personnel_id IN ($placeholders)"
        );
        $stmt->execute(array_merge([$cycleId], array_values($personnelIds)));
        return array_map('intval', array_column($stmt->fetchAll(), 'personnel_id'));
    }

    public function findById(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM overtime_entries WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    public function findByIdForUpdate(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM overtime_entries WHERE id = :id FOR UPDATE');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    public function delete(int $id): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM overtime_entries WHERE id = :id');
        $stmt->execute(['id' => $id]);
    }

    private const REPORT_SELECT =
        'SELECT e.id, e.overtime_date, p.personnel_code, p.full_name, d.name AS division, e.division_id,
                t.name AS type, e.hours, c.cycle_number, e.description
           FROM overtime_entries e
           JOIN personnel       p ON p.id = e.personnel_id
           JOIN divisions       d ON d.id = e.division_id
           JOIN overtime_types  t ON t.id = e.overtime_type_id
           LEFT JOIN cycles     c ON c.id = e.cycle_id';

    /** Report rows (§6.5), newest first; paginated unless $paginated = false. */
    public function filteredQuery(ReportFilter $f, int $page, int $pageSize, bool $paginated = true): array
    {
        ['where' => $where, 'params' => $params] = $f->toSqlConditions();

        $sql = self::REPORT_SELECT . $where . ' ORDER BY e.overtime_date DESC, e.id DESC';
        if ($paginated) {
            $sql .= ' LIMIT :limit OFFSET :offset';
        }

        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        if ($paginated) {
            $stmt->bindValue('limit', $pageSize, PDO::PARAM_INT);
            $stmt->bindValue('offset', ($page - 1) * $pageSize, PDO::PARAM_INT);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /** @return array{count: int, hours: float} totals for the whole filtered set */
    public function filteredTotals(ReportFilter $f): array
    {
        ['where' => $where, 'params' => $params] = $f->toSqlConditions();

        $sql = 'SELECT COUNT(*) AS cnt, COALESCE(SUM(e.hours), 0) AS total_hours
                  FROM overtime_entries e
                  JOIN personnel p ON p.id = e.personnel_id' . $where;

        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $stmt->execute();
        $row = $stmt->fetch();
        return ['count' => (int) ($row['cnt'] ?? 0), 'hours' => (float) ($row['total_hours'] ?? 0)];
    }

    /** Unbuffered stream of the filtered set for CSV export (no pagination). */
    public function streamForCsv(ReportFilter $f): \Generator
    {
        ['where' => $where, 'params' => $params] = $f->toSqlConditions();

        $this->pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
        try {
            $stmt = $this->pdo->prepare(
                self::REPORT_SELECT . $where . ' ORDER BY e.overtime_date DESC, e.id DESC'
            );
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
            }
            $stmt->execute();
            while (($row = $stmt->fetch()) !== false) {
                yield $row;
            }
        } finally {
            $this->pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
        }
    }
}
