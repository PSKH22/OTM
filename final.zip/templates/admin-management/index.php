<div class="page-head">
  <div>
    <h1 class="page-title">مدیریت مدیران</h1>
    <p class="page-subtitle">ایجاد و مدیریت حساب‌های مدیر واحد. مدیران این صفحه به مدیر اصلی دسترسی ندارند و فقط به واحد تعیین‌شده محدود هستند.</p>
  </div>
</div>
<?php if (!empty($errors)): ?><div class="notice notice-danger" style="margin-bottom:15px"><?php foreach ($errors as $error): ?><div><?= e($error) ?></div><?php endforeach; ?></div>
<?php elseif (isset($_GET['success'])): ?><div class="flash">حساب مدیر واحد با موفقیت ایجاد شد.</div>
<?php elseif (($_GET['removed'] ?? '') === 'deactivated'): ?><div class="flash">حساب مدیر غیرفعال شد و سوابق حفظ شد.</div>
<?php elseif (($_GET['removed'] ?? '') === 'deleted'): ?><div class="flash">حساب مدیر حذف شد؛ سوابق مرتبط حفظ شدند.</div>
<?php elseif (isset($_GET['updated'])): ?><div class="flash"><?= ($_GET['updated'] ?? '') === 'activated' ? 'حساب مدیر فعال شد.' : 'حساب مدیر غیرفعال شد.' ?></div>
<?php elseif (isset($_GET['error'])): ?><div class="notice notice-danger"><?= ($_GET['error'] ?? '') === 'invalid_remove' ? 'عملیات انتخاب‌شده معتبر نیست.' : 'حساب مدیر پیدا نشد.' ?></div><?php endif; ?>
<div class="card card-pad">
  <form method="post" action="/admin-management" class="admin-management-create-form">
    <input type="hidden" name="csrf_token" value="<?= e(\App\Core\Csrf::token()) ?>">
    <div class="form-grid personnel-create-grid admin-management-form-grid">
      <div class="field"><label for="display_name">نام و نام خانوادگی</label><input class="control" id="display_name" name="display_name" value="<?= e($old['display_name'] ?? '') ?>" maxlength="120" required placeholder="نام مدیر"></div>
      <div class="field"><label for="username">نام کاربری</label><input class="control" id="username" name="username" value="<?= e($old['username'] ?? '') ?>" maxlength="64" autocomplete="off" required placeholder="مثلاً admin_hw"></div>
      <div class="field"><label for="password">گذرواژه</label><input class="control" id="password" name="password" type="password" minlength="12" autocomplete="new-password" required placeholder="حداقل ۱۲ کاراکتر"></div>
      <div class="field"><label for="division_id">واحد</label><select class="control" id="division_id" name="division_id" required><option value="">انتخاب واحد…</option><?php foreach ($divisions as $d): ?><option value="<?= e($d['id']) ?>" <?= (string)($old['division_id'] ?? '') === (string)$d['id'] ? 'selected' : '' ?>><?= e($d['name']) ?></option><?php endforeach; ?></select></div>
      <div class="field personnel-form-action"><label aria-hidden="true">&nbsp;</label><button class="btn btn-primary" type="submit">افزودن مدیر</button></div>
    </div>
  </form>
</div>
<div class="card card-pad personnel-list-card">
  <form method="get" action="/admin-management" class="personnel-toolbar" style="margin-top:0"><input type="hidden" name="limit" value="<?= e($adminLimit ?? 50) ?>">
    <div class="search"><span class="search-icon">⌕</span><input name="q" class="control" type="search" value="<?= e($search ?? '') ?>" placeholder="جستجوی نام، نام کاربری یا واحد…" autocomplete="off"></div>
    <div class="actions"><button class="btn btn-secondary" type="submit">اعمال فیلتر</button></div>
  </form>
  <div class="table-wrap"><table class="table"><thead><tr><th>نام کاربری</th><th>نام مدیر</th><th>واحد</th><th>وضعیت</th><th>آخرین ورود</th><th>عملیات</th></tr></thead><tbody>
    <?php foreach ($admins as $admin): ?><tr><td dir="ltr"><?= e($admin['username']) ?></td><td><?= e($admin['display_name']) ?></td><td><?= e($admin['division_name']) ?></td><td><?php if ((int)$admin['is_active'] === 1): ?><span class="status status-ok">فعال</span><?php else: ?><span class="status status-lock">غیرفعال</span><?php endif; ?></td><td dir="ltr"><?= e($admin['last_login_at'] ?: '—') ?></td><td><?php if ((int)$admin['is_active'] === 1): ?><button class="btn btn-danger btn-sm admin-remove-btn" type="button" data-id="<?= e($admin['id']) ?>" data-name="<?= e($admin['display_name']) ?>" data-username="<?= e($admin['username']) ?>">حذف</button><?php else: ?><form method="post" action="/admin-management/toggle" style="display:inline"><input type="hidden" name="csrf_token" value="<?= e(\App\Core\Csrf::token()) ?>"><input type="hidden" name="admin_id" value="<?= e($admin['id']) ?>"><input type="hidden" name="active" value="1"><button class="btn btn-secondary btn-sm" type="submit">فعال‌سازی مجدد</button></form><?php endif; ?></td></tr><?php endforeach; ?>
    <?php if (!$admins): ?><tr><td colspan="6" class="muted">مدیر واحدی ثبت نشده است.</td></tr><?php endif; ?>
  </tbody></table></div>
  <?php $currentPage=(int)($adminPage??1);$totalPages=(int)($adminPages??1);$pageSize=(int)($adminLimit??50);$adminPageUrl=fn(int $page)=>'/admin-management?'.http_build_query(array_filter(['q'=>$search??'','page'=>$page,'limit'=>$pageSize],static fn($v)=>$v!=='')); ?>
  <div class="pagination" aria-label="صفحه‌بندی مدیران">
    <div class="pagination-nav"><a class="btn btn-secondary btn-sm pagination-btn <?= $currentPage>1?'':'pagination-btn-hidden' ?>" href="<?= e($adminPageUrl(max(1,$currentPage-1))) ?>">قبلی</a><span class="page-number">صفحه <?= e(num($currentPage)) ?> از <?= e(num($totalPages)) ?></span><a class="btn btn-secondary btn-sm pagination-btn <?= $currentPage<$totalPages?'':'pagination-btn-hidden' ?>" href="<?= e($adminPageUrl(min($totalPages,$currentPage+1))) ?>">بعدی</a>
    </div>
  <div class="page-size-control" aria-label="تنظیم تعداد ردیف در صفحه">
    <label class="page-size-label"><select class="control page-size-select" aria-label="تعداد ردیف در هر صفحه"><option value="" <?= (int)($adminLimit ?? 50) === 50 ? 'selected' : '' ?>>تعداد در صفحه</option><?php foreach ([10,25,50,75,100] as $size): ?><option value="<?= $size ?>" <?= ((int)($adminLimit ?? 50) === $size && $size !== 50) ? 'selected' : '' ?>><?= $size ?></option><?php endforeach; ?></select></label>
  </div>
  </div>
</div>

<div id="adminRemoveDialog" class="dialog-backdrop hidden" role="dialog" aria-modal="true" aria-labelledby="adminRemoveTitle">
  <div class="dialog">
    <h3 id="adminRemoveTitle">حذف مدیر واحد</h3>
    <p id="adminRemoveMessage">برای این مدیر یک عملیات انتخاب کنید.</p>
    <form method="post" action="/admin-management/remove" id="adminRemoveForm">
      <input type="hidden" name="csrf_token" value="<?= e(\App\Core\Csrf::token()) ?>">
      <input type="hidden" name="admin_id" id="adminRemoveId" value="">
      <div class="dialog-actions personnel-remove-actions">
        <button type="submit" class="btn btn-delete-records" name="remove_mode" value="delete">حذف حساب مدیر و حفظ سوابق</button>
        <button type="submit" class="btn btn-keep-records" name="remove_mode" value="deactivate">غیرفعال‌سازی و حفظ سوابق</button>
        <button type="button" class="btn btn-cancel" id="adminRemoveCancel">انصراف</button>
      </div>
    </form>
  </div>
</div>
