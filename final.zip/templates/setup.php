<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>راه‌اندازی اولیه · مدیریت اضافه‌کاری</title>
  <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body>
  <button type="button" class="theme-toggle login-theme" id="themeToggle" aria-label="حالت تاریک" title="حالت تاریک">☾</button>
  <div class="login-page">
    <section class="card login-card" style="max-width:620px">
      <div class="login-brand">
        <div class="brand-text">پارس خودرو</div>
        <h1>مدیریت مدیران اصلی</h1>
        <p><?= !empty($syncEnabled) ? 'همگام‌سازی حساب‌های مدیر اصلی با فهرست فایل <code>.env</code>' : 'ایجاد چند حساب مدیر اصلی از تنظیمات فایل <code>.env</code>' ?></p>
      </div>
      <?php if (!empty($error)): ?><div class="notice notice-warning"><?= e($error) ?></div><?php endif; ?>
      <?php if (empty($admins)): ?>
        <div class="notice notice-warning">هیچ حسابی با الگوی <code>MAIN_ADMIN_n_*</code> در فایل <code>.env</code> پیدا نشد. برای مثال از <code>MAIN_ADMIN_1_USERNAME</code>، <code>MAIN_ADMIN_1_PASSWORD</code> و <code>MAIN_ADMIN_1_DISPLAY_NAME</code> استفاده کنید.</div>
      <?php else: ?>
        <?php if (!empty($syncEnabled)): ?>
          <div class="notice notice-warning">حالت همگام‌سازی فعال است. با تأیید، حساب‌های مدیر اصلی موجود جایگزین فهرست زیر می‌شوند؛ حساب‌هایی که در .env نیستند حذف می‌شوند. سوابق اضافه‌کاری و گزارش حسابرسی حفظ خواهند شد.</div>
        <?php else: ?>
          <div class="notice">می‌توانید چند حساب مدیر اصلی را در راه‌اندازی اولیه تعریف کنید. پس از ایجاد اولین مدیر اصلی، این صفحه قفل می‌شود و دیگر قابل استفاده نیست.</div>
        <?php endif; ?>
        <div style="overflow:auto;margin:18px 0">
          <table class="data-table">
            <thead><tr><th>حساب</th><th>نام مدیر اصلی</th><th>دسترسی</th></tr></thead>
            <tbody>
            <?php foreach ($admins as $number => $admin): ?>
              <tr>
                <td><?= e($admin['username'] ?? '—') ?></td>
                <td><?= e($admin['display_name'] ?? '—') ?></td>
                <td>همه واحدها</td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <form method="post" action="/setup">
          <input type="hidden" name="csrf_token" value="<?= e($csrf ?? '') ?>">
          <button class="btn btn-primary" type="submit"><?= !empty($syncEnabled) ? 'جایگزینی و همگام‌سازی مدیران اصلی' : 'ایجاد حساب‌های جدید مدیر اصلی' ?></button>
        </form>
      <?php endif; ?>
      <div class="login-help"><?= !empty($syncEnabled) ? 'برای امنیت، پس از اتمام همگام‌سازی مقدار SETUP_SYNC_MAIN_ADMINS را در .env به 0 تغییر دهید. مدیران واحد از صفحه «مدیریت مدیران» ساخته می‌شوند.' : 'این صفحه فقط برای راه‌اندازی اولیه و ایجاد یک یا چند مدیر اصلی است. پس از ایجاد اولین مدیر اصلی، دسترسی به این صفحه بسته می‌شود. مدیران واحد از صفحه «مدیریت مدیران» ساخته می‌شوند.' ?></div>
    </section>
  </div>
  <script src="<?= e(asset('js/app.js') . '?v=20261005-setup1') ?>"></script>
</body>
</html>
