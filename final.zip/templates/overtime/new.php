<div class="page-head">
  <div>
    <h1 class="page-title">ثبت اضافه‌کاری</h1>
    <p class="page-subtitle"><?= !empty($isMainAdmin) ? 'مدیر اصلی می‌تواند برای هر واحد اضافه‌کاری ثبت کند.' : 'برای پرسنل واحد خود، اضافه‌کاری را ثبت کنید.' ?></p>
  </div>
</div>
<div class="card card-pad">
  <form method="post" action="/overtime" id="overtimeSubmitForm">
    <input type="hidden" name="limit" value="<?= e($limit ?? 50) ?>">
    <input type="hidden" name="csrf_token" value="<?= e(\App\Core\Csrf::token()) ?>">
    <input type="hidden" name="form_nonce" value="<?= e($form_nonce) ?>">
    <div class="form-grid <?= !empty($isMainAdmin) ? 'main-admin-form-grid' : '' ?>">
      <?php if (!empty($isMainAdmin)): ?><div class="field"><label for="division_id">واحد ثبت</label><select class="control" id="division_id" name="division_id"><option value="">انتخاب واحد…</option><?php foreach($divisions as $d): ?><option value="<?= e($d['id']) ?>" <?= (int)($selectedDivisionId??0)===(int)$d['id']?'selected':'' ?>><?= e($d['name']) ?></option><?php endforeach; ?></select></div><?php endif; ?>
      <div class="field"><label for="type">نوع اضافه‌کاری</label><select id="type" name="type_id"
          class="control"><?php foreach ($types as $t): ?>
            <option value="<?= e($t['id']) ?>" data-code="<?= e($t['code']) ?>" data-day-rule="<?= e($t['day_rule']) ?>"
              data-uses-cycle="<?= e($t['uses_cycle']) ?>"><?= e($t['name']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="field"><label for="date">تاریخ</label>
        <div class="date-wrap"><input id="date" name="date" class="control" data-date value="<?= e($today) ?>" dir="ltr"
            inputmode="numeric" autocomplete="off"><button type="button" class="calendar-btn" id="calendarBtn"
            aria-label="انتخاب تاریخ">▣</button></div>
      </div>
      <div class="field"><label for="hours">ساعت</label><input id="hours" name="hours" class="control" value="2"
          dir="ltr" inputmode="decimal" maxlength="5"></div>
      <div class="field"><label for="description">توضیحات (اختیاری)</label><input id="description" name="description"
          class="control" maxlength="255" placeholder="مثلاً پشتیبانی خارج از ساعت اداری"></div>
      <div id="dayMessage" class="form-grid-message" role="alert" aria-live="polite"></div>
    </div>
    <section class="cycle-strip" aria-label="وضعیت دورها">
      <?php foreach ($cycles as $c): ?>  <?php $total = (int) $c['total_active'];
            $done = max(0, min((int) $c['done'], $total)); ?>
        <div class="cycle <?= (int)$c['division_id'] === (int)(!empty($isMainAdmin) ? ($selectedDivisionId ?? 0) : ($user['division_id'] ?? 0)) ? 'own' : '' ?>">
          <div class="cycle-top"><span><?= e($c['name']) ?></span><span>دور <?= e(num($c['cycle_number'])) ?></span></div>
          <div class="cycle-count"><?= e(num($done)) ?> از <?= e(num($total)) ?> نفر انجام شده</div>
          <div class="progress" data-progress-done="<?= e($done) ?>" data-progress-total="<?= e($total) ?>"
            role="progressbar" aria-valuemin="0" aria-valuemax="<?= e($total) ?>" aria-valuenow="<?= e($done) ?>"
            aria-label="<?= e(num($done)) ?> از <?= e(num($total)) ?> نفر"><span class="progress-fill" style="width:<?= $total > 0 ? e(($done / $total) * 100) : 0 ?>%"></span></div>
        </div><?php endforeach; ?>
    </section>
    <div class="personnel-toolbar overtime-selection-toolbar">
      <div class="overtime-filter-form">
        <div class="search-filter-group">
          <div class="search"><span class="search-icon">⌕</span><input id="search" name="q" class="control"
              type="search" value="<?= e($search ?? "") ?>" placeholder="جستجوی نام یا کد پرسنلی…"
              aria-label="جستجوی نام یا کد پرسنلی" autocomplete="off"></div>
          <button class="btn btn-secondary" id="applyPersonnelFilter" type="button">اعمال فیلتر</button>
        </div>
      </div>
      <div class="selection-count"><strong id="selectedCount">0 نفر انتخاب شده</strong></div>
      <div class="actions"><button class="btn btn-primary" id="submitBtn" type="submit" disabled>ثبت</button></div>
    </div>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th><input id="selectAll" class="check" type="checkbox" aria-label="انتخاب همه"></th>
            <th>نام و نام خانوادگی</th>
            <th>کد پرسنلی</th>
            <th>واحد</th>
            <th>وضعیت</th>
          </tr>
        </thead>
        <tbody id="personnelBody">
          <?php foreach ($personnel as $p): ?>  <?php $own = !empty($isMainAdmin) ? ((int)($selectedDivisionId??0)===0 || (int)$p['division_id']===(int)$selectedDivisionId) : ((int) $p['division_id'] === (int) ($user['division_id'] ?? 0));
                $selectedUsesCycle = false; // JavaScript derives eligibility from the currently selected overtime type.
                $disabled = !$own || !empty($p['submitted_on_date']) || ($selectedUsesCycle && !empty($p['used_in_open_cycle'])); ?>
            <tr class="<?= $disabled ? 'locked' : '' ?>" data-personnel-row data-division-id="<?= e($p['division_id']) ?>"
              data-name-search="<?= e($p['full_name']) ?>" data-personnel-code="<?= e($p['personnel_code']) ?>"
              data-used-in-cycle="<?= !empty($p['used_in_open_cycle']) ? '1' : '0' ?>" data-submitted-on-date="<?= !empty($p['submitted_on_date']) ? '1' : '0' ?>"
              data-own-division="<?= $own ? '1' : '0' ?>">
              <td><input class="check person-check" type="checkbox" name="personnel_ids[]" value="<?= e($p['id']) ?>"
                  data-id="<?= e($p['id']) ?>" <?= $disabled ? 'disabled' : '' ?>></td>
              <td><?= e($p['full_name']) ?></td>
              <td dir="ltr"><?= e(num($p['personnel_code'])) ?></td>
              <td><?= e($p['division_name']) ?></td>
              <td><?php if (!$own): ?><span class="status status-lock"><?= !empty($isMainAdmin) && empty($selectedDivisionId) ? 'ابتدا واحد را انتخاب کنید' : '🔒 فقط مشاهده' ?></span><?php elseif (!empty($p['submitted_on_date'])): ?><span class="status status-done">ثبت‌شده در این تاریخ</span><?php elseif (!empty($selectedUsesCycle) && !empty($p['used_in_open_cycle'])): ?><span
                    class="status status-done">انجام‌شده در دور جاری</span><?php else: ?><span
                    class="status status-ok">آزاد</span><?php endif; ?></td>
            </tr><?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php
    $currentPage = (int) ($personnelPage ?? 1);
    $totalPages = (int) ($personnelPages ?? 1);
    $pageSize = (int)($limit ?? 50);
    $personnelPageUrl = function (int $page) use ($search, $isMainAdmin, $selectedDivisionId, $pageSize): string {
      $params = ['q' => $search ?? '', 'page' => $page, 'limit' => $pageSize]; if (!empty($isMainAdmin) && !empty($selectedDivisionId)) $params['division_id'] = $selectedDivisionId;
      return '/overtime/new?' . http_build_query(array_filter($params, static fn($v) => $v !== ''));
    };
    ?>
    <div class="pagination" aria-label="صفحه‌بندی پرسنل">
    <div class="pagination-nav">
      <a class="btn btn-secondary btn-sm pagination-btn <?= $currentPage > 1 ? '' : 'pagination-btn-hidden' ?>"
        href="<?= e($personnelPageUrl(max(1, $currentPage - 1))) ?>">قبلی</a>
      <span class="page-number">صفحه <?= e(num($currentPage)) ?> از <?= e(num($totalPages)) ?></span>
      
      <a class="btn btn-secondary btn-sm pagination-btn <?= $currentPage < $totalPages ? '' : 'pagination-btn-hidden' ?>"
        href="<?= e($personnelPageUrl(min($totalPages, $currentPage + 1))) ?>">بعدی</a>
    </div>
  <div class="page-size-control" aria-label="تنظیم تعداد ردیف در صفحه">
    <label class="page-size-label"><select class="control page-size-select" aria-label="تعداد ردیف در هر صفحه"><option value="" <?= (int)($limit ?? 50) === 50 ? 'selected' : '' ?>>تعداد در صفحه</option><?php foreach ([10,25,50,75,100] as $size): ?><option value="<?= $size ?>" <?= ((int)($limit ?? 50) === $size && $size !== 50) ? 'selected' : '' ?>><?= $size ?></option><?php endforeach; ?></select></label>
  </div>
  </div>
  </form>
</div>
<div class="footer-note">زمان سامانه: Asia/Tehran · تاریخ‌ها به تقویم هجری شمسی نمایش داده می‌شوند.</div>