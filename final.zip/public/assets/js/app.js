'use strict';

(() => {
  const themeKey = 'overtime-theme';

  function applyTheme() {
    const saved = localStorage.getItem(themeKey);
    const theme = saved === 'dark' || saved === 'light'
      ? saved
      : (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    document.documentElement.dataset.theme = theme;

    const button = document.querySelector('#themeToggle');
    if (button) {
      const dark = theme === 'dark';
      button.dataset.themeState = theme;
      button.title = dark ? 'حالت روشن' : 'حالت تاریک';
      button.setAttribute('aria-label', button.title);
    }
  }

  applyTheme();

  document.addEventListener('click', (event) => {
    if (event.target.closest('#themeToggle')) {
      const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
      localStorage.setItem(themeKey, next);
      applyTheme();
      return;
    }

    const button = event.target.closest('.calendar-btn');
    if (button) {
      const targetId = button.dataset.target || 'date';
      const input = document.getElementById(targetId);
      if (input) openCalendar(input);
      return;
    }

    if (!event.target.closest('.date-wrap') && !event.target.closest('.calendar')) {
      document.querySelectorAll('.calendar').forEach(calendar => calendar.remove());
    }
  });

  // Jalali calendar helpers. Weekday index: Saturday=0 ... Friday=6.
  function jalaliToGregorian(jy, jm, jd) {
    jy = Number(jy); jm = Number(jm); jd = Number(jd);
    const gy = jy <= 979 ? 621 : 1600;
    const jy2 = jy - (jy <= 979 ? 0 : 979);
    const days = 365 * jy2 + Math.floor(jy2 / 33) * 8 + Math.floor((jy2 % 33 + 3) / 4)
      + 78 + jd + (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
    let gy2 = 400 * Math.floor(days / 146097);
    let d = days % 146097;
    if (d > 36524) { gy2 += 100 * Math.floor(--d / 36524); d %= 36524; if (d >= 365) d++; }
    gy2 += 4 * Math.floor(d / 1461); d %= 1461;
    if (d > 365) { gy2 += Math.floor((d - 1) / 365); d = (d - 1) % 365; }
    const gd = d + 1;
    const leap = (gy2 % 4 === 0 && gy2 % 100 !== 0) || gy2 % 400 === 0;
    const monthLengths = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gm = 0, rem = gd;
    while (rem > monthLengths[gm]) { rem -= monthLengths[gm]; gm++; }
    return [gy2 + gy, gm + 1, rem];
  }

  function gregorianToJalali(gy, gm, gd) {
    const gDays = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    const gy2 = gy - 1600, gm2 = gm - 1, gd2 = gd - 1;
    let days = 365 * gy2 + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100)
      + Math.floor((gy2 + 399) / 400) + gd2 + gDays[gm2];
    if (gm2 > 1 && ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0)) days++;
    let jy = 979 + 33 * Math.floor(days / 12053);
    days %= 12053;
    jy += 4 * Math.floor(days / 1461);
    days %= 1461;
    if (days > 365) { jy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
    const jd = days + 1;
    const jm = jd <= 186 ? Math.ceil(jd / 31) : Math.ceil((jd - 186) / 30) + 6;
    const day = jd <= 186 ? ((jd - 1) % 31) + 1 : ((jd - 187) % 30) + 1;
    return [jy, jm, day];
  }

  function jalaliWeekday(jy, jm, jd) {
    const g = jalaliToGregorian(jy, jm, jd);
    return (new Date(g[0], g[1] - 1, g[2]).getDay() + 1) % 7;
  }

  function jalaliIsLeapYear(year) {
    return jalaliToGregorian(year, 12, 30)[2] === 30;
  }

  function jalaliDaysInMonth(year, month) {
    if (month <= 6) return 31;
    if (month <= 11) return 30;
    return jalaliIsLeapYear(year) ? 30 : 29;
  }

  function parseJalaliInput(value) {
    // Always parse the value shown in the actual input field. Accept both
    // Persian/Latin digits and slash/dash separators, then return one
    // canonical Jalali date object used by the picker.
    const normalized = String(value || '')
      .trim()
      .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
      .replace(/[-.]/g, '/');
    const parts = normalized.split('/').map(part => Number(part));
    if (parts.length !== 3 || !parts.every(Number.isFinite)) return null;
    const [year, month, day] = parts;
    if (!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day)) return null;
    if (year < 1 || month < 1 || month > 12 || day < 1 || day > jalaliDaysInMonth(year, month)) return null;
    return { year, month, day };
  }

  function todayJalali() {
    const now = new Date();
    return gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
  }

  function jalaliMonthName(month) {
    return ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'][month - 1];
  }

  function formatJalaliDate(year, month, day) {
    return `${year}/${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
  }

  function openCalendar(input) {
    document.querySelectorAll('.calendar').forEach(calendar => calendar.remove());

    // The field is the single source of truth when the picker opens. This
    // prevents the calendar from opening on today while the input displays
    // a different default date.
    let parsed = parseJalaliInput(input.value);
    if (!parsed) {
      // An empty field may have a placeholder, but opening the picker must
      // never turn that placeholder/today into a real input value. Use today
      // only as the temporary calendar view until the user explicitly picks
      // a date.
      const t = todayJalali();
      parsed = { year: t[0], month: t[1], day: t[2] };
    }

    let viewYear = parsed.year;
    let viewMonth = parsed.month;
    const selected = { year: parsed.year, month: parsed.month, day: parsed.day };
    const weekdayNames = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

    const box = document.createElement('div');
    box.className = 'calendar';
    input.parentElement.appendChild(box);

    function draw() {
      const daysInMonth = jalaliDaysInMonth(viewYear, viewMonth);
      const firstWeekday = jalaliWeekday(viewYear, viewMonth, 1);
      const cells = [];
      for (let i = 0; i < firstWeekday; i++) cells.push('<span class="cal-empty"></span>');

      for (let d = 1; d <= daysInMonth; d++) {
        const weekday = jalaliWeekday(viewYear, viewMonth, d);
        const isSelected = selected.year === viewYear && selected.month === viewMonth && selected.day === d;
        const weekend = isJalaliWeekend(weekday);
        const typeOption = input.id === 'date' ? document.querySelector('#type option:checked') : null;
        const overtimeType = typeOption?.dataset.code || 'weekdays';
        const invalidType = overtimeType === 'weekdays' ? weekend : overtimeType === 'weekend' ? !weekend : false;
        cells.push(`<button type="button" ${invalidType ? 'disabled' : ''} class="cal-day ${isSelected ? 'selected' : ''} ${weekend ? 'weekend' : ''} ${invalidType ? 'invalid-type' : ''}" data-day="${d}" aria-label="${d} ${weekdayNames[weekday]}">${d}</button>`);
      }

      const today = todayJalali();
      const minPickerYear = today[0];
      const maxPickerYear = today[0] + 50;
      if (viewYear < minPickerYear) viewYear = minPickerYear;
      if (viewYear > maxPickerYear) viewYear = maxPickerYear;

      const years = [];
      for (let y = minPickerYear; y <= maxPickerYear; y++) {
        years.push(`<option value="${y}" ${y === viewYear ? 'selected' : ''}>${y}</option>`);
      }
      const months = Array.from({ length: 12 }, (_, i) =>
        `<option value="${i + 1}" ${i + 1 === viewMonth ? 'selected' : ''}>${jalaliMonthName(i + 1)}</option>`
      ).join('');

      const todayWeekday = jalaliWeekday(today[0], today[1], today[2]);
      const todayWeekend = isJalaliWeekend(todayWeekday);
      const currentType = input.id === 'date' ? (document.querySelector('#type option:checked')?.dataset.code || 'weekdays') : null;
      const todayInvalid = currentType === 'weekdays' ? todayWeekend : currentType === 'weekend' ? !todayWeekend : false;
      const isTodayMonth = today[0] === viewYear && today[1] === viewMonth;

      box.innerHTML = `
        <div class="cal-head">
          <button type="button" class="cal-nav" data-cal-action="prev" aria-label="ماه قبل">‹</button>
          <div class="cal-selectors">
            <select data-cal-action="month" class="cal-select" aria-label="ماه">${months}</select>
            <select data-cal-action="year" class="cal-select cal-year" aria-label="سال">${years.join('')}</select>
          </div>
          <button type="button" class="cal-nav" data-cal-action="next" aria-label="ماه بعد">›</button>
        </div>
        <div class="cal-week">${weekdayNames.map(x => `<span title="${x}">${x.slice(0, 2)}</span>`).join('')}</div>
        <div class="cal-grid">${cells.join('')}</div>
        `;

      // Use delegated events so month navigation survives every redraw of the calendar.
      // The controls are recreated by draw(), so handlers must not depend on stale nodes.
      box.querySelectorAll('[data-cal-action]').forEach(control => {
        control.addEventListener('click', event => {
          event.preventDefault();
          event.stopPropagation();
          const action = control.dataset.calAction;
          if (action === 'prev') {
            const minYear = todayJalali()[0];
            if (viewYear === minYear && viewMonth === 1) return;
            if (viewMonth === 1) { viewMonth = 12; viewYear--; } else { viewMonth--; }
            draw();
          } else if (action === 'next') {
            const maxYear = todayJalali()[0] + 50;
            if (viewYear === maxYear && viewMonth === 12) return;
            if (viewMonth === 12) { viewMonth = 1; viewYear++; } else { viewMonth++; }
            draw();
          } else if (action === 'today') {
            const t = todayJalali();
            input.value = formatJalaliDate(t[0], t[1], t[2]);
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
            box.remove();
          }
        });
        control.addEventListener('change', event => {
          const action = control.dataset.calAction;
          if (action === 'month') {
            viewMonth = Number(event.target.value);
            if (selected.day > jalaliDaysInMonth(viewYear, viewMonth)) selected.day = jalaliDaysInMonth(viewYear, viewMonth);
            draw();
          } else if (action === 'year') {
            viewYear = Number(event.target.value);
            if (selected.day > jalaliDaysInMonth(viewYear, viewMonth)) selected.day = jalaliDaysInMonth(viewYear, viewMonth);
            draw();
          }
        });
      });

      box.querySelectorAll('.cal-day').forEach(button => {
        button.onclick = () => {
          if (button.disabled) return;
          const d = Number(button.dataset.day);
          input.value = formatJalaliDate(viewYear, viewMonth, d);
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
          box.remove();
        };
      });

    }

    draw();
  }

  function normalizeDigits(value) {
    return String(value || '').replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
  }

  function selectedOvertimeRule() {
    const type = document.querySelector('#type');
    const option = type?.options[type.selectedIndex];
    return {
      code: option?.dataset.code || '',
      dayRule: option?.dataset.dayRule || 'any'
    };
  }

  function isJalaliWeekend(weekday) {
    // jalaliWeekday(): Saturday=0 ... Thursday=5, Friday=6.
    return weekday === 5 || weekday === 6;
  }

  function getOvertimeDateTypeMismatch() {
    const input = document.querySelector('#date');
    const type = document.querySelector('#type');
    if (!input || !type) return false;

    const parsed = parseJalaliInput(normalizeDigits(input.value));
    if (!parsed) return false;

    const weekday = jalaliWeekday(parsed.year, parsed.month, parsed.day);
    const weekend = isJalaliWeekend(weekday);
    const { dayRule } = selectedOvertimeRule();
    return (dayRule === 'workday' && weekend) || (dayRule === 'weekend' && !weekend);
  }

  function validateOvertimeDateType() {
    const message = document.querySelector('#dayMessage');
    const mismatch = getOvertimeDateTypeMismatch();
    if (message) {
      message.innerHTML = mismatch
        ? '<div class="notice notice-warning">تاریخ انتخاب‌شده با نوع اضافه‌کاری سازگار نیست؛ برای «روزهای کاری» شنبه تا چهارشنبه و برای «آخر هفته» پنج‌شنبه و جمعه را انتخاب کنید.</div>'
        : '';
      message.classList.toggle('is-visible', mismatch);
    }
    return !mismatch;
  }

  function validateOvertimeForm() {
    const date = document.querySelector('#date');
    const type = document.querySelector('#type');
    const hours = document.querySelector('#hours');
    const selected = document.querySelectorAll('.person-check:checked').length;
    if (!date || !type || !hours) return false;

    const parsed = parseJalaliInput(normalizeDigits(date.value));
    const hoursValue = Number(normalizeDigits(hours.value).replace(',', '.'));
    const dateTypeOk = validateOvertimeDateType();
    const valid = !!parsed && dateTypeOk && hoursValue >= 0.25 && hoursValue <= 8 && selected > 0;
    const submit = document.querySelector('#submitBtn');
    if (submit) submit.disabled = !valid;
    return valid;
  }

  function refreshOpenCalendar() {
    const calendar = document.querySelector('.calendar');
    const input = calendar?.parentElement?.querySelector('.control');
    if (calendar && input) {
      calendar.remove();
      openCalendar(input);
    }
  }

  function normalizeSearchText(value) {
    return String(value || '')
      .replace(/[يى]/g, 'ی')
      .replace(/ك/g, 'ک')
      .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
      .replace(/\u200c/g, '')
      .replace(/ـ/g, '')
      .replace(/[\u064B-\u065F\u0670]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function bindSubmitPersonnelFiltering() {
    const form = document.querySelector('form[action="/overtime"]');
    const body = document.querySelector('#personnelBody');
    const type = document.querySelector('#type');
    const selectedCount = document.querySelector('#selectedCount');
    const selectAll = document.querySelector('#selectAll');
    const searchInput = document.querySelector('#search');
    const applyFilter = document.querySelector('#applyPersonnelFilter');
    if (!form || !body || !selectedCount) return;

    applyFilter?.addEventListener('click', () => {
      const q = (searchInput?.value || '').trim();
      const url = new URL('/overtime/new', window.location.origin);
      const division = document.querySelector('#division_id')?.value || '';
      if (q) url.searchParams.set('q', q);
      if (division) url.searchParams.set('division_id', division);
      window.location.assign(url.toString());
    });
    searchInput?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        applyFilter?.click();
      }
    });

    const rows = Array.from(body.querySelectorAll('[data-personnel-row]'));
    const checks = rows.map(row => row.querySelector('.person-check')).filter(Boolean);
    const divisionSelect = document.querySelector('#division_id');
    divisionSelect?.addEventListener('change', () => {
      const url = new URL('/overtime/new', window.location.origin);
      if (divisionSelect.value) url.searchParams.set('division_id', divisionSelect.value);
      const q = (searchInput?.value || '').trim();
      if (q) url.searchParams.set('q', q);
      window.location.assign(url.toString());
    });

    const refreshEligibility = () => {
      const selectedOption = type?.options[type.selectedIndex];
      const usesCycle = selectedOption?.dataset.usesCycle === '1';
      const dateTypeMismatch = getOvertimeDateTypeMismatch();
      rows.forEach(row => {
        const checkbox = row.querySelector('.person-check');
        if (!checkbox) return;
        const own = row.dataset.ownDivision === '1';
        const used = row.dataset.usedInCycle === '1';
        const submitted = row.dataset.submittedOnDate === '1';
        const shouldDisable = !own || dateTypeMismatch || submitted || (usesCycle && used);
        checkbox.disabled = shouldDisable;
        if (shouldDisable) checkbox.checked = false;
        row.classList.toggle('locked', shouldDisable);
        row.classList.toggle('used', own && !submitted && usesCycle && used);
        row.classList.toggle('submitted', own && submitted);
        const status = row.querySelector('.status');
        if (status) {
          if (!own) {
            status.className = 'status status-lock';
            status.textContent = 'مجاز نیست';
          } else if (dateTypeMismatch) {
            status.className = 'status status-lock';
            status.textContent = 'تاریخ با نوع ناسازگار است';
          } else if (submitted) {
            status.className = 'status status-done';
            status.textContent = 'ثبت‌شده در این تاریخ';
          } else if (usesCycle && used) {
            status.className = 'status status-done';
            status.textContent = 'انجام‌شده در دور جاری';
          } else {
            status.className = 'status status-ok';
            status.textContent = 'آزاد';
          }
        }
      });
    };

    const refresh = () => {
      refreshEligibility();
      const totalSelected = checks.filter(cb => cb.checked).length;
      selectedCount.textContent = `${totalSelected} نفر انتخاب شده`;
      if (selectAll) {
        const visibleEnabled = checks.filter(cb => !cb.disabled);
        const checkedVisible = visibleEnabled.filter(cb => cb.checked).length;
        selectAll.checked = visibleEnabled.length > 0 && checkedVisible === visibleEnabled.length;
        selectAll.indeterminate = checkedVisible > 0 && checkedVisible < visibleEnabled.length;
        selectAll.disabled = visibleEnabled.length === 0;
      }
      validateOvertimeForm();
    };

    const dateInput = document.querySelector('#date');
    if (dateInput) {
      dateInput.addEventListener('input', refresh);
      dateInput.addEventListener('change', refresh);
      let submittedLookupSequence = 0;
      const refreshSubmittedForDate = async () => {
        const dateValue = (dateInput.value || '').trim();
        if (!dateValue) return;
        const sequence = ++submittedLookupSequence;
        const url = new URL('/overtime/submitted-personnel', window.location.origin);
        url.searchParams.set('date', dateValue);
        try {
          const response = await fetch(url.toString(), { credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store' });
          if (!response.ok) return;
          const payload = await response.json();
          if (sequence !== submittedLookupSequence || !Array.isArray(payload.ids)) return;
          const submitted = new Set(payload.ids.map(String));
          rows.forEach(row => { row.dataset.submittedOnDate = submitted.has(String(row.querySelector('.person-check')?.dataset.id || '')) ? '1' : '0'; });
          refresh();
        } catch (_) { /* Keep the server-rendered status if the lookup is temporarily unavailable. */ }
      };
      dateInput.addEventListener('change', refreshSubmittedForDate);
    }
    type?.addEventListener('change', refresh);
    checks.forEach(cb => cb.addEventListener('change', refresh));

    if (selectAll) {
      selectAll.addEventListener('change', () => {
        checks.forEach(cb => {
          if (!cb.disabled) cb.checked = selectAll.checked;
        });
        refresh();
      });
    }

    refresh();
  }

  function refreshPersonnelEligibility() {
    const type = document.querySelector('#type');
    const dateTypeMismatch = getOvertimeDateTypeMismatch();
    const selectedOption = type?.options[type.selectedIndex];
    const usesCycle = selectedOption?.dataset.usesCycle === '1';
    document.querySelectorAll('[data-personnel-row]').forEach(row => {
      const checkbox = row.querySelector('.person-check');
      if (!checkbox) return;
      const own = row.dataset.ownDivision === '1';
      const used = row.dataset.usedInCycle === '1';
      const submitted = row.dataset.submittedOnDate === '1';
      const disabled = !own || dateTypeMismatch || submitted || (usesCycle && used);
      checkbox.disabled = disabled;
      if (disabled) checkbox.checked = false;
      row.classList.toggle('locked', disabled);
      row.classList.toggle('used', own && !submitted && usesCycle && used && !dateTypeMismatch);
      row.classList.toggle('submitted', own && submitted);
      const status = row.querySelector('.status');
      if (status) {
        if (!own) { status.className = 'status status-lock'; status.textContent = 'مجاز نیست'; }
        else if (dateTypeMismatch) { status.className = 'status status-lock'; status.textContent = 'تاریخ با نوع ناسازگار است'; }
        else if (submitted) { status.className = 'status status-done'; status.textContent = 'ثبت‌شده در این تاریخ'; }
        else if (usesCycle && used) { status.className = 'status status-done'; status.textContent = 'انجام‌شده در دور جاری'; }
        else { status.className = 'status status-ok'; status.textContent = 'آزاد'; }
      }
    });
  }

  function bindOvertimeValidation() {
    const form = document.querySelector('form[action="/overtime"]');
    const type = document.querySelector('#type');
    const date = document.querySelector('#date');
    const hours = document.querySelector('#hours');
    if (!form || !type || !date || !hours) return;

    [type, date, hours].forEach(el => {
      el.addEventListener('input', validateOvertimeForm);
      el.addEventListener('change', validateOvertimeForm);
    });
    [type, date].forEach(el => {
      el.addEventListener('input', refreshPersonnelEligibility);
      el.addEventListener('change', refreshPersonnelEligibility);
    });
    type.addEventListener('change', () => {
      const selectedOption = type.options[type.selectedIndex];
      const typeCode = selectedOption?.dataset.code || 'weekdays';
      const defaultHours = { weekdays: '2', weekend: '8', out_of_quota: '8' };
      if (Object.prototype.hasOwnProperty.call(defaultHours, typeCode)) {
        hours.value = defaultHours[typeCode];
      }
      const usesCycle = selectedOption?.dataset.usesCycle === '1';
      const dateTypeMismatch = getOvertimeDateTypeMismatch();
      document.querySelectorAll('[data-personnel-row]').forEach(row => {
        const checkbox = row.querySelector('.person-check');
        if (!checkbox) return;
        const own = row.dataset.ownDivision === '1';
        const used = row.dataset.usedInCycle === '1';
        const submitted = row.dataset.submittedOnDate === '1';
        const disabled = !own || dateTypeMismatch || submitted || (usesCycle && used);
        checkbox.disabled = disabled;
        if (disabled) checkbox.checked = false;
        row.classList.toggle('locked', disabled);
        row.classList.toggle('used', own && !submitted && usesCycle && used);
        row.classList.toggle('submitted', own && submitted);
        const status = row.querySelector('.status');
        if (status) {
          if (!own) { status.className = 'status status-lock'; status.textContent = 'مجاز نیست'; }
          else if (dateTypeMismatch) { status.className = 'status status-lock'; status.textContent = 'تاریخ با نوع ناسازگار است'; }
          else if (submitted) { status.className = 'status status-done'; status.textContent = 'ثبت‌شده در این تاریخ'; }
          else if (usesCycle && used) { status.className = 'status status-done'; status.textContent = 'انجام‌شده در دور جاری'; }
          else { status.className = 'status status-ok'; status.textContent = 'آزاد'; }
        }
      });
      refreshOpenCalendar();
      validateOvertimeForm();
    });

    document.querySelectorAll('.person-check').forEach(cb => {
      cb.addEventListener('change', validateOvertimeForm);
    });

    form.addEventListener('submit', event => {
      if (!validateOvertimeForm()) {
        event.preventDefault();
        alert('لطفاً نوع، تاریخ، ساعت و حداقل یک نفر را به‌درستی انتخاب کنید.');
      }
    });

    validateOvertimeForm();
  }

  function jalaliStringToNumber(value) {
    const p = parseJalaliInput(normalizeDigits(value));
    return p ? (p.year * 10000 + p.month * 100 + p.day) : null;
  }

  function bindReportFiltering() {
    const form = document.querySelector('#reportForm');
    const from = document.querySelector('#from');
    const to = document.querySelector('#to');
    if (!form) return;

    form.addEventListener('submit', event => {
      const fromN = jalaliStringToNumber(from?.value);
      const toN = jalaliStringToNumber(to?.value);
      if (from?.value && fromN === null) {
        event.preventDefault();
        alert('تاریخ «از تاریخ» معتبر نیست.');
      } else if (to?.value && toN === null) {
        event.preventDefault();
        alert('تاریخ «تا تاریخ» معتبر نیست.');
      } else if (fromN !== null && toN !== null && toN < fromN) {
        event.preventDefault();
        alert('تاریخ «تا تاریخ» باید بزرگ‌تر یا مساوی «از تاریخ» باشد.');
      }
    });
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[char]));
  }

  function bindReportPdf() {
    const button = document.querySelector('#reportPdfBtn');
    const body = document.querySelector('#reportBody');
    const table = body?.closest('table');
    if (!button || !body || !table) return;

    const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
    }[char]));

    const labelValue = (label, value) => {
      const text = String(value ?? '').trim();
      return text ? `<span><strong>${esc(label)}:</strong> ${esc(text)}</span>` : '';
    };

    button.addEventListener('click', () => {
      const popup = window.open('', 'overtimePdfPreview', 'width=1200,height=850,resizable=yes,scrollbars=yes');
      if (!popup) {
        alert('پنجره خروجی PDF توسط مرورگر مسدود شده است. لطفاً اجازه بازشدن پنجره‌های جدید را فعال کنید.');
        return;
      }

      const clone = table.cloneNode(true);
      const rows = Array.from(clone.querySelectorAll('tbody tr'));
      rows.forEach(row => {
        if (row.classList.contains('client-empty') || row.style.display === 'none') row.remove();
      });

      clone.querySelectorAll('tr').forEach(row => {
        row.lastElementChild?.remove();
      });

      const from = document.querySelector('#from')?.value || '';
      const to = document.querySelector('#to')?.value || '';
      const division = document.querySelector('#division_id');
      const type = document.querySelector('#type_id');
      const search = document.querySelector('#reportSearch')?.value || '';
      const count = clone.querySelectorAll('tbody tr').length;
      const pageNumber = document.querySelector('.pagination .page-number')?.textContent?.trim() || '';
      const hours = Array.from(body.querySelectorAll('tr[data-entry]'))
        .filter(row => row.style.display !== 'none')
        .reduce((sum, row) => sum + (Number((row.dataset.hours || '0').replace(',', '.')) || 0), 0);

      const filters = [
        labelValue('از تاریخ', from),
        labelValue('تا تاریخ', to),
        labelValue('واحد', division?.selectedOptions?.[0]?.textContent || ''),
        labelValue('نوع', type?.selectedOptions?.[0]?.textContent || ''),
        labelValue('جستجو', search)
      ].filter(Boolean).join('');

      const now = new Date();
      const generatedAt = now.toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' });
      const title = 'گزارش اضافه‌کاری';

      popup.document.open();
      popup.document.write(`<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)}</title>
<link rel="stylesheet" href="${window.location.origin}/assets/css/report-print.css">
</head>
<body>
<main class="report">
  <div class="head"><div><h1>${esc(title)}</h1><div class="meta">گزارش ایجادشده از فیلترهای فعلی صفحه</div></div><div class="meta">${esc(generatedAt)}</div></div>
  <div class="filters">${filters || '<span>بدون فیلتر اضافی</span>'}</div>
  <div class="summary"><span><strong>${esc(count)}</strong> رکورد</span><span><strong>${esc(hours.toFixed(1))}</strong> ساعت</span>${pageNumber ? `<span>${esc(pageNumber)}</span>` : ''}</div>
  ${clone.outerHTML}
  <div class="footer">Overtime Management</div>
</main>
</body>
</html>`);
      popup.document.close();

      const printWhenReady = async () => {
        try {
          const styleSheets = Array.from(popup.document.querySelectorAll('link[rel=\"stylesheet\"]'));
          await Promise.all(styleSheets.map(link => new Promise(resolve => {
            if (link.sheet) { resolve(); return; }
            link.addEventListener('load', resolve, { once: true });
            link.addEventListener('error', resolve, { once: true });
          })));
          if (popup.document.fonts?.ready) await popup.document.fonts.ready;
          await new Promise(resolve => popup.requestAnimationFrame(() => popup.requestAnimationFrame(resolve)));
          popup.focus();
          popup.print();
        } catch (_) {
          try { popup.focus(); popup.print(); } catch (__) { }
        }
      };
      printWhenReady();
    });
  }

  function bindPageSizeSelect() {
    document.querySelectorAll('.page-size-select').forEach(select => {
      select.addEventListener('change', () => {
        const url = new URL(window.location.href);
        url.searchParams.set('limit', select.value || '50');
        url.searchParams.set('page', '1');
        window.location.assign(url.pathname + '?' + url.searchParams.toString());
      });
    });
  }

  function bindReportExcel() {
    const button = document.querySelector('#reportExcelBtn');
    const body = document.querySelector('#reportBody');
    const table = body?.closest('table');
    if (!button || !body || !table) return;

    const xmlEscape = value => String(value ?? '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&apos;')
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');

    // Create a genuine .xlsx (OOXML ZIP package), without third-party libraries.
    const makeZip = files => {
      const encoder = new TextEncoder();
      const crcTable = new Uint32Array(256);
      for (let n = 0; n < 256; n++) {
        let c = n;
        for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        crcTable[n] = c >>> 0;
      }
      const crc32 = bytes => {
        let crc = 0xFFFFFFFF;
        for (const byte of bytes) crc = crcTable[(crc ^ byte) & 0xFF] ^ (crc >>> 8);
        return (crc ^ 0xFFFFFFFF) >>> 0;
      };
      const localParts = [], centralParts = [];
      let offset = 0;
      const u16 = (view, at, value) => view.setUint16(at, value, true);
      const u32 = (view, at, value) => view.setUint32(at, value >>> 0, true);
      for (const file of files) {
        const name = encoder.encode(file.name), data = encoder.encode(file.content), crc = crc32(data);
        const local = new Uint8Array(30 + name.length + data.length), lv = new DataView(local.buffer);
        u32(lv, 0, 0x04034B50); u16(lv, 4, 20); u16(lv, 6, 0x0800); u16(lv, 8, 0);
        u16(lv, 10, 0); u16(lv, 12, 0); u32(lv, 14, crc); u32(lv, 18, data.length); u32(lv, 22, data.length);
        u16(lv, 26, name.length); u16(lv, 28, 0); local.set(name, 30); local.set(data, 30 + name.length);
        localParts.push(local);
        const dir = new Uint8Array(46 + name.length), dv = new DataView(dir.buffer);
        u32(dv, 0, 0x02014B50); u16(dv, 4, 20); u16(dv, 6, 20); u16(dv, 8, 0x0800); u16(dv, 10, 0);
        u16(dv, 12, 0); u16(dv, 14, 0); u32(dv, 16, crc); u32(dv, 20, data.length); u32(dv, 24, data.length);
        u16(dv, 28, name.length); u16(dv, 30, 0); u16(dv, 32, 0); u16(dv, 34, 0); u16(dv, 36, 0);
        u32(dv, 38, 0); u32(dv, 42, offset); dir.set(name, 46); centralParts.push(dir); offset += local.length;
      }
      const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0);
      const end = new Uint8Array(22), ev = new DataView(end.buffer);
      u32(ev, 0, 0x06054B50); u16(ev, 4, 0); u16(ev, 6, 0); u16(ev, 8, files.length); u16(ev, 10, files.length);
      u32(ev, 12, centralSize); u32(ev, 16, offset); u16(ev, 20, 0);
      return new Blob([...localParts, ...centralParts, end], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    };

    button.addEventListener('click', () => {
      const headers = Array.from(table.querySelectorAll('thead th')).slice(0, -1).map(cell => cell.textContent.trim());
      const rows = Array.from(body.querySelectorAll('tr'))
        .filter(row => !row.classList.contains('client-empty') && row.style.display !== 'none')
        .map(row => Array.from(row.querySelectorAll('td')).slice(0, headers.length).map(cell => cell.textContent.trim()));
      const allRows = [headers, ...rows];
      const columnName = index => {
        let result = '';
        for (let n = index + 1; n > 0; n = Math.floor((n - 1) / 26)) result = String.fromCharCode(65 + ((n - 1) % 26)) + result;
        return result;
      };
      const cellsXml = (row, rowIndex) => `<row r="${rowIndex + 1}">${row.map((value, colIndex) => {
        const ref = `${columnName(colIndex)}${rowIndex + 1}`;
        return `<c r="${ref}" t="inlineStr"${rowIndex === 0 ? ' s="1"' : ''}><is><t xml:space="preserve">${xmlEscape(value)}</t></is></c>`;
      }).join('')}</row>`;
      const sheetRows = allRows.map(cellsXml).join('');
      const lastCell = `${columnName(Math.max(headers.length - 1, 0))}${Math.max(allRows.length, 1)}`;
      const files = [
        {
          name: '[Content_Types].xml', content: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' +
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
            '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' +
            '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>'
        },
        { name: '_rels/.rels', content: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>' },
        { name: 'xl/workbook.xml', content: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="گزارش اضافه‌کاری" sheetId="1" r:id="rId1"/></sheets></workbook>' },
        { name: 'xl/_rels/workbook.xml.rels', content: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' },
        {
          name: 'xl/styles.xml', content: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
            '<fonts count="2"><font><sz val="10"/><name val="Tahoma"/><family val="2"/></font><font><b/><sz val="10"/><name val="Tahoma"/><family val="2"/></font></fonts>' +
            '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE8EEF1"/><bgColor indexed="64"/></patternFill></fill></fills>' +
            '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
            '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center" readingOrder="2" wrapText="1"/></xf>' +
            '<xf numFmtId="0" fontId="1" fillId="1" borderId="0" xfId="0" applyAlignment="1" applyFill="1"><alignment horizontal="center" vertical="center" readingOrder="2" wrapText="1"/></xf></cellXfs>' +
            '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'
        },
        {
          name: 'xl/worksheets/sheet1.xml', content: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
            `<dimension ref="A1:${lastCell}"/><sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>` +
            `<sheetFormatPr defaultRowHeight="18"/><cols>${headers.map((_, i) => `<col min="${i + 1}" max="${i + 1}" width="20" customWidth="1"/>`).join('')}</cols><sheetData>${sheetRows}</sheetData><autoFilter ref="A1:${lastCell}"/></worksheet>`
        }
      ];
      const url = URL.createObjectURL(makeZip(files));
      const link = document.createElement('a'); link.href = url; link.download = 'overtime-report.xlsx'; link.style.display = 'none';
      document.body.appendChild(link); link.click(); link.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  }

  function bindReportDelete() {
    const dialog = document.getElementById('reportDeleteDialog');
    const form = document.getElementById('reportDeleteForm');
    const idInput = document.getElementById('reportDeleteId');
    const backInput = document.getElementById('reportDeleteBack');
    const message = document.getElementById('reportDeleteMessage');
    const cancel = document.getElementById('reportDeleteCancel');
    if (!dialog || !form || !idInput || !backInput || !message || !cancel) return;

    const close = () => {
      dialog.classList.add('hidden');
      idInput.value = '';
      backInput.value = '';
    };

    document.querySelectorAll('.delete-btn').forEach(button => {
      button.addEventListener('click', () => {
        const row = button.closest('tr');
        const id = button.dataset.id;
        if (!id || !row) return;
        const cells = row.querySelectorAll('td');
        const name = cells[2]?.textContent?.trim() || '';
        const date = cells[0]?.textContent?.trim() || '';
        const type = cells[4]?.textContent?.trim() || '';
        const hours = cells[5]?.textContent?.trim() || '';
        idInput.value = id;
        backInput.value = window.location.pathname + window.location.search;
        message.innerHTML = `آیا از حذف این رکورد اضافه‌کاری مطمئن هستید؟<br><strong>${escapeHtml(name)}</strong> · ${escapeHtml(date)} · ${escapeHtml(type)} · ${escapeHtml(hours)} ساعت`;
        dialog.classList.remove('hidden');
      });
    });

    cancel.addEventListener('click', close);
    dialog.addEventListener('click', event => {
      if (event.target === dialog) close();
    });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && !dialog.classList.contains('hidden')) close();
    });
  }

  function bindAdminRemove() {
    const dialog = document.getElementById('adminRemoveDialog');
    const form = document.getElementById('adminRemoveForm');
    const idInput = document.getElementById('adminRemoveId');
    const message = document.getElementById('adminRemoveMessage');
    const cancel = document.getElementById('adminRemoveCancel');
    if (!dialog || !form || !idInput || !message || !cancel) return;
    const close = () => { dialog.classList.add('hidden'); idInput.value = ''; };
    document.querySelectorAll('.admin-remove-btn').forEach(button => {
      button.addEventListener('click', () => {
        idInput.value = button.dataset.id || '';
        message.textContent = `آیا می‌خواهید برای «${button.dataset.name || 'این مدیر'}» (${button.dataset.username || ''}) یکی از گزینه‌های زیر را اجرا کنید؟`;
        dialog.classList.remove('hidden');
      });
    });
    cancel.addEventListener('click', close);
    dialog.addEventListener('click', event => { if (event.target === dialog) close(); });
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && !dialog.classList.contains('hidden')) close(); });
    form.addEventListener('submit', event => { if (!idInput.value) event.preventDefault(); });
  }

  function bindPersonnelRemove() {
    const dialog = document.getElementById('personnelRemoveDialog');
    const form = document.getElementById('personnelRemoveForm');
    const idInput = document.getElementById('personnelRemoveId');
    const message = document.getElementById('personnelRemoveMessage');
    const cancel = document.getElementById('personnelRemoveCancel');
    if (!dialog || !form || !idInput || !message || !cancel) return;

    const close = () => {
      dialog.classList.add('hidden');
      idInput.value = '';
    };

    document.querySelectorAll('.personnel-remove-btn').forEach(button => {
      button.addEventListener('click', () => {
        idInput.value = button.dataset.id || '';
        message.textContent = `آیا می‌خواهید «${button.dataset.name || 'این پرسنل'}» را حذف کنید؟`;
        dialog.classList.remove('hidden');
      });
    });

    cancel.addEventListener('click', close);
    dialog.addEventListener('click', event => {
      if (event.target === dialog) close();
    });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && !dialog.classList.contains('hidden')) close();
    });

    form.addEventListener('submit', event => {
      if (!idInput.value) event.preventDefault();
    });
  }

  function bindCycleProgressBars() {
    document.querySelectorAll('.progress[data-progress-total]').forEach(bar => {
      const total = Number(bar.dataset.progressTotal);
      const done = Number(bar.dataset.progressDone);

      const safeTotal = Number.isFinite(total) && total > 0 ? total : 0;
      const safeDone = Number.isFinite(done) && done > 0 ? Math.min(done, safeTotal) : 0;
      const percent = safeTotal === 0 ? 0 : (safeDone / safeTotal) * 100;

      // Keep the fill as a real element so it renders consistently in all themes.
      const fill = bar.querySelector('.progress-fill');
      if (fill) fill.style.width = `${percent}%`;
      bar.style.setProperty('--progress-percent', `${percent}%`);
      bar.setAttribute('aria-valuemax', String(safeTotal));
      bar.setAttribute('aria-valuenow', String(safeDone));
    });
  }

  // PWA: register the service worker and expose the native install prompt when supported.
  let deferredInstallPrompt = null;
  const installButton = document.getElementById('pwaInstallButton');
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/service-worker.js', { scope: '/' }).catch(() => {
        // The app remains fully usable if service-worker registration is unavailable.
      });
    });
  }
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    deferredInstallPrompt = event;
    if (installButton) installButton.hidden = false;
  });
  window.addEventListener('appinstalled', () => {
    deferredInstallPrompt = null;
    if (installButton) installButton.hidden = true;
  });
  if (installButton) {
    installButton.addEventListener('click', async () => {
      if (!deferredInstallPrompt) return;
      deferredInstallPrompt.prompt();
      await deferredInstallPrompt.userChoice;
      deferredInstallPrompt = null;
      installButton.hidden = true;
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    bindCycleProgressBars();
    bindSubmitPersonnelFiltering();
    bindOvertimeValidation();
    bindReportFiltering();
    bindReportPdf();
    bindPageSizeSelect();
    bindReportExcel();
    bindReportDelete();
    bindPersonnelRemove();
    bindAdminRemove();
  });

})();

