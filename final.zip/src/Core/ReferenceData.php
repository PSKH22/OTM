<?php
namespace App\Core;

use PDO;

/**
 * Creates the small set of reference records required by the application.
 * This is intentionally idempotent: existing records are never overwritten.
 */
final class ReferenceData
{
    public static function ensure(PDO $pdo): void
    {
        self::renameHardwareSupportDivision($pdo);
        // Only create the canonical row on a fresh database where neither label exists.
        $pdo->exec("INSERT INTO divisions (name)
            SELECT 'پشتیبانی تجهیزات و سیستم‌های فناوری اطلاعات' FROM DUAL
            WHERE NOT EXISTS (SELECT 1 FROM divisions WHERE name = 'پشتیبانی تجهیزات و سیستم‌های فناوری اطلاعات')");
        $pdo->exec("INSERT INTO divisions (name)
            SELECT 'شبکه و زیرساخت' FROM DUAL
            WHERE NOT EXISTS (SELECT 1 FROM divisions WHERE name = 'شبکه و زیرساخت')");
        $pdo->exec("INSERT INTO divisions (name)
            SELECT 'پایگاه داده و امنیت اطلاعات' FROM DUAL
            WHERE NOT EXISTS (SELECT 1 FROM divisions WHERE name = 'پایگاه داده و امنیت اطلاعات')");

        $types = [
            ['weekdays', 'روزهای کاری', 0, 'workday', 1],
            ['weekend', 'آخر هفته', 1, 'weekend', 2],
            ['out_of_quota', 'خارج از سهمیه', 0, 'any', 3],
        ];

        $stmt = $pdo->prepare(
            'INSERT INTO overtime_types (code, name, uses_cycle, day_rule, sort_order)
             SELECT :code, :name, :uses_cycle, :day_rule, :sort_order FROM DUAL
             WHERE NOT EXISTS (SELECT 1 FROM overtime_types WHERE code = :code_check)'
        );
        foreach ($types as [$code, $name, $usesCycle, $dayRule, $sortOrder]) {
            $stmt->execute([
                'code' => $code,
                'name' => $name,
                'uses_cycle' => $usesCycle,
                'day_rule' => $dayRule,
                'sort_order' => $sortOrder,
                'code_check' => $code,
            ]);
        }

        // Keep existing reference rows aligned with the application's canonical
        // rules too. Older installations may already contain these codes with
        // stale uses_cycle/day_rule values.
        $update = $pdo->prepare(
            'UPDATE overtime_types
             SET name = :name, uses_cycle = :uses_cycle, day_rule = :day_rule, sort_order = :sort_order
             WHERE code = :code'
        );
        foreach ($types as [$code, $name, $usesCycle, $dayRule, $sortOrder]) {
            $update->execute([
                'code' => $code,
                'name' => $name,
                'uses_cycle' => $usesCycle,
                'day_rule' => $dayRule,
                'sort_order' => $sortOrder,
            ]);
        }

        // Cycles now apply only to cycle-enabled overtime types (currently weekend).
        // Detach any historical non-cycle entries so they cannot affect progress.
        $pdo->exec("UPDATE overtime_entries e JOIN overtime_types t ON t.id = e.overtime_type_id
                    SET e.cycle_id = NULL WHERE t.uses_cycle = 0 AND e.cycle_id IS NOT NULL");

        // Every division starts with cycle 1. Existing cycles are preserved.
        $pdo->exec(
            'INSERT INTO cycles (division_id, cycle_number)
             SELECT d.id, 1
             FROM divisions d
             WHERE NOT EXISTS (
                 SELECT 1 FROM cycles c
                 WHERE c.division_id = d.id AND c.cycle_number = 1
             )'
        );
    }
    /**
     * Renames the old division without changing its ID. If an earlier deployment
     * already created a second row with the new name, merge that duplicate into
     * the old row and preserve references to personnel, users, entries, and cycles.
     */
    private static function renameHardwareSupportDivision(PDO $pdo): void
    {
        $oldName = 'پشتیبانی سخت‌افزار';
        $newName = 'پشتیبانی تجهیزات و سیستم‌های فناوری اطلاعات';

        $find = $pdo->prepare('SELECT id FROM divisions WHERE name = :name LIMIT 1');
        $find->execute(['name' => $oldName]);
        $oldId = $find->fetchColumn();
        $find->execute(['name' => $newName]);
        $newId = $find->fetchColumn();

        if ($oldId === false) {
            // The canonical row already exists, or this is a fresh database.
            return;
        }

        $oldId = (int)$oldId;
        if ($newId === false) {
            $rename = $pdo->prepare('UPDATE divisions SET name = :new_name WHERE id = :id');
            $rename->execute(['new_name' => $newName, 'id' => $oldId]);
            return;
        }

        $newId = (int)$newId;
        if ($oldId === $newId) {
            return;
        }

        // Recover safely if a prior version inserted the new label as a separate row.
        $pdo->beginTransaction();
        try {
            $cyclesStmt = $pdo->prepare(
                'SELECT id, cycle_number, closed_at FROM cycles WHERE division_id = :division_id ORDER BY cycle_number'
            );
            $cyclesStmt->execute(['division_id' => $newId]);
            $newCycles = $cyclesStmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($newCycles as $newCycle) {
                $oldCycleStmt = $pdo->prepare(
                    'SELECT id FROM cycles WHERE division_id = :division_id AND cycle_number = :cycle_number LIMIT 1'
                );
                $oldCycleStmt->execute([
                    'division_id' => $oldId,
                    'cycle_number' => $newCycle['cycle_number'],
                ]);
                $oldCycleId = $oldCycleStmt->fetchColumn();

                if ($oldCycleId !== false) {
                    $moveEntries = $pdo->prepare('UPDATE overtime_entries SET cycle_id = :old_cycle WHERE cycle_id = :new_cycle');
                    $moveEntries->execute(['old_cycle' => (int)$oldCycleId, 'new_cycle' => (int)$newCycle['id']]);
                    $deleteCycle = $pdo->prepare('DELETE FROM cycles WHERE id = :id');
                    $deleteCycle->execute(['id' => (int)$newCycle['id']]);
                    continue;
                }

                if ($newCycle['closed_at'] === null) {
                    $openCycle = $pdo->prepare('SELECT id FROM cycles WHERE division_id = :division_id AND closed_at IS NULL LIMIT 1');
                    $openCycle->execute(['division_id' => $oldId]);
                    if ($openCycle->fetchColumn() !== false) {
                        // A division may only have one open cycle. Preserve this cycle as history.
                        $closeCycle = $pdo->prepare('UPDATE cycles SET closed_at = CURRENT_TIMESTAMP WHERE id = :id');
                        $closeCycle->execute(['id' => (int)$newCycle['id']]);
                    }
                }

                $moveCycle = $pdo->prepare('UPDATE cycles SET division_id = :old_division WHERE id = :cycle_id');
                $moveCycle->execute(['old_division' => $oldId, 'cycle_id' => (int)$newCycle['id']]);
            }

            foreach (['users', 'personnel', 'overtime_entries'] as $table) {
                $moveRows = $pdo->prepare("UPDATE {$table} SET division_id = :old_division WHERE division_id = :new_division");
                $moveRows->execute(['old_division' => $oldId, 'new_division' => $newId]);
            }

            $deleteDivision = $pdo->prepare('DELETE FROM divisions WHERE id = :id');
            $deleteDivision->execute(['id' => $newId]);
            $rename = $pdo->prepare('UPDATE divisions SET name = :new_name WHERE id = :id');
            $rename->execute(['new_name' => $newName, 'id' => $oldId]);
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

}
