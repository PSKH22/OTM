<?php
namespace App\Core;

final class SessionSecurity
{
    public static function start(string $root): void
    {
        $storage = $root . '/storage/sessions';
        if (!is_dir($storage) && !mkdir($storage, 0700, true) && !is_dir($storage)) {
            throw new \RuntimeException('Unable to create session storage directory.');
        }
        @chmod($storage, 0700);
        ini_set('session.save_handler', 'files');
        ini_set('session.save_path', $storage);
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.use_trans_sid', '0');
        ini_set('session.cookie_httponly', '1');
        ini_set('session.cookie_samesite', 'Lax');
        ini_set('session.gc_maxlifetime', (string) max(60, (int)($_ENV['SESSION_ABSOLUTE_HOURS'] ?? 8) * 3600));

        $secure = (($_ENV['COOKIE_SECURE'] ?? '0') === '1') || (($_ENV['APP_ENV'] ?? 'local') === 'production');
        $defaultCookieName = (($_ENV['APP_ENV'] ?? 'local') === 'production') ? '__Host-ot_sid' : 'overtime_sid';
        $cookieName = (string)($_ENV['SESSION_NAME'] ?? $defaultCookieName);
        // __Host- cookies are valid only with Secure, Path=/ and no Domain attribute.
        if (str_starts_with($cookieName, '__Host-') && !$secure) {
            $cookieName = 'overtime_sid';
        }
        session_name($cookieName);
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
    }

    /** Returns true when the current authenticated session has expired. */
    public static function enforceTimeout(): bool
    {
        if (empty($_SESSION['user']['id'])) {
            return false;
        }
        $now = time();
        $idleSeconds = max(1, (int)($_ENV['SESSION_IDLE_MINUTES'] ?? 30)) * 60;
        $absoluteSeconds = max(1, (int)($_ENV['SESSION_ABSOLUTE_HOURS'] ?? 8)) * 3600;
        $lastActivity = (int)($_SESSION['_last_activity'] ?? 0);
        $createdAt = (int)($_SESSION['_auth_created_at'] ?? 0);
        $expired = $lastActivity <= 0 || $createdAt <= 0
            || ($now - $lastActivity) >= $idleSeconds
            || ($now - $createdAt) >= $absoluteSeconds;
        if ($expired) {
            self::destroyCurrent();
            return true;
        }
        $_SESSION['_last_activity'] = $now;
        return false;
    }

    public static function markAuthenticated(): void
    {
        $now = time();
        $_SESSION['_auth_created_at'] = $now;
        $_SESSION['_last_activity'] = $now;
    }

    public static function destroyCurrent(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => $params['path'] ?: '/',
                'secure' => (bool)$params['secure'],
                'httponly' => (bool)$params['httponly'],
                'samesite' => $params['samesite'] ?? 'Lax',
            ]);
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
    }
}
