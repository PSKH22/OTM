<?php
namespace App\Repositories;
use App\Core\Database;

final class UserRepository
{
    private const SELECT_USER = "SELECT u.*, CASE WHEN u.role='main_admin' THEN 'همه واحدها' ELSE d.name END division_name FROM users u LEFT JOIN divisions d ON d.id=u.division_id";
    public function findByUsername(string $username): ?array { $s=Database::connection()->prepare(self::SELECT_USER.' WHERE u.username=:u LIMIT 1'); $s->execute(['u'=>$username]); return $s->fetch() ?: null; }
    public function countAll(): int { return (int)Database::connection()->query('SELECT COUNT(*) FROM users')->fetchColumn(); }
    public function countMainAdmins(): int { return (int)Database::connection()->query("SELECT COUNT(*) FROM users WHERE role='main_admin'")->fetchColumn(); }
    public function find(int $id): ?array { $s=Database::connection()->prepare(self::SELECT_USER.' WHERE u.id=:id LIMIT 1'); $s->execute(['id'=>$id]); return $s->fetch() ?: null; }
    public function allDivisionAdmins(string $q='', int $limit=10, int $offset=0): array {
        $where = "u.role='division_admin'"; $params=[];
        if ($q !== '') { $where .= ' AND (u.username LIKE :q1 OR u.display_name LIKE :q2 OR d.name LIKE :q3)'; $like='%'.$q.'%'; $params=['q1'=>$like,'q2'=>$like,'q3'=>$like]; }
        $pdo=Database::connection(); $c=$pdo->prepare("SELECT COUNT(*) FROM users u LEFT JOIN divisions d ON d.id=u.division_id WHERE {$where}"); $c->execute($params); $total=(int)$c->fetchColumn();
        $s=$pdo->prepare("SELECT u.id,u.username,u.display_name,u.division_id,u.is_active,u.last_login_at,u.created_at,d.name division_name FROM users u JOIN divisions d ON d.id=u.division_id WHERE {$where} ORDER BY d.id,u.display_name,u.id LIMIT :lim OFFSET :off");
        foreach($params as $k=>$v)$s->bindValue(':'.$k,$v); $s->bindValue(':lim',max(1,min(100,$limit)),\PDO::PARAM_INT);$s->bindValue(':off',max(0,$offset),\PDO::PARAM_INT);$s->execute();return ['rows'=>$s->fetchAll(),'total'=>$total];
    }
    public function touchLogin(int $id): void { $s=Database::connection()->prepare('UPDATE users SET last_login_at=UTC_TIMESTAMP() WHERE id=:id'); $s->execute(['id'=>$id]); }
    public function create(string $username,string $passwordHash,string $displayName,?int $divisionId, string $role='division_admin'): int { $s=Database::connection()->prepare('INSERT INTO users(username,password_hash,display_name,division_id,role) VALUES(:u,:p,:n,:d,:r)'); $s->execute(['u'=>$username,'p'=>$passwordHash,'n'=>$displayName,'d'=>$divisionId,'r'=>$role]); return (int)Database::connection()->lastInsertId(); }
    public function removeDivisionAdmin(int $id, string $mode, int $actorId, ?string $ip): bool
    {
        if (!in_array($mode, ['deactivate', 'delete'], true)) {
            throw new \RuntimeException('invalid_remove_mode');
        }
        return Database::transaction(function ($pdo) use ($id, $mode, $actorId, $ip): bool {
            $stmt = $pdo->prepare("SELECT id,username,display_name,division_id,is_active,last_login_at,created_at FROM users WHERE id=:id AND role='division_admin' FOR UPDATE");
            $stmt->execute(['id' => $id]);
            $admin = $stmt->fetch();
            if (!$admin) return false;
            $audit = new AuditLogRepository($pdo);
            if ($mode === 'deactivate') {
                if ((int)$admin['is_active'] === 1) {
                    $update = $pdo->prepare("UPDATE users SET is_active=0 WHERE id=:id AND role='division_admin'");
                    $update->execute(['id' => $id]);
                }
                $audit->add($actorId, 'division_admin_deactivated', $id, ['admin' => $admin], $ip);
                return true;
            }

            // Preserve overtime and audit history while removing the login account.
            $reassignEntries = $pdo->prepare('UPDATE overtime_entries SET created_by=:actor WHERE created_by=:id');
            $reassignEntries->execute(['actor' => $actorId, 'id' => $id]);
            $reassignAudit = $pdo->prepare('UPDATE audit_log SET user_id=:actor WHERE user_id=:id');
            $reassignAudit->execute(['actor' => $actorId, 'id' => $id]);
            $delete = $pdo->prepare("DELETE FROM users WHERE id=:id AND role='division_admin'");
            $delete->execute(['id' => $id]);
            if ($delete->rowCount() !== 1) return false;
            $audit->add($actorId, 'division_admin_deleted', $id, ['admin' => $admin, 'history_preserved' => true, 'history_reassigned_to' => $actorId], $ip);
            return true;
        });
    }

    public function setActiveDivisionAdmin(int $id, bool $active): bool { $s=Database::connection()->prepare("UPDATE users SET is_active=:active WHERE id=:id AND role='division_admin'"); $s->execute(['active'=>$active?1:0,'id'=>$id]); return $s->rowCount()>0; }
}
