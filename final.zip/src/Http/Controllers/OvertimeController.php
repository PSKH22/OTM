<?php
namespace App\Http\Controllers;
use App\Core\Request;
use App\Core\View;
use App\Repositories\AuditLogRepository;
use App\Repositories\CycleRepository;
use App\Repositories\LookupRepository;
use App\Repositories\OvertimeRepository;
use App\Repositories\PersonnelRepository;
use App\Services\CycleService;
use App\Services\OvertimeService;
use App\Support\JalaliDate;
use App\Core\Database;
use RuntimeException;
use Throwable;
use PDOException;
use App\Core\ErrorHandler;

final class OvertimeController
{
    private function service(): OvertimeService { $pdo=Database::connection();return new OvertimeService(new OvertimeRepository($pdo),new PersonnelRepository(),new LookupRepository(),new CycleRepository($pdo),new AuditLogRepository($pdo),new CycleService($pdo,new CycleRepository($pdo))); }
    public function create(Request $request): string
    {
        $user = $_SESSION['user'];
        $lookups = new LookupRepository();
        $divisions = $lookups->divisions();
        $isMainAdmin = strtolower(trim((string)($user['role'] ?? 'division_admin'))) === 'main_admin';
        $q = \App\Support\TextNormalizer::normalize((string)$request->input('q', ''));
        $page = max(1, (int)$request->input('page', 1));
        $allowedPageSizes = [10, 25, 50, 75, 100];
        $requestedLimit = (int)$request->input('limit', 50);
        $limit = in_array($requestedLimit, $allowedPageSizes, true) ? $requestedLimit : 50;

        // For main admins, an empty division selection means all divisions.
        // Division admins remain scoped to their assigned division.
        $selectedDivision = $isMainAdmin
            ? max(0, (int)$request->input('division_id', 0))
            : (int)($user['division_id'] ?? 0);

        $personnelRepo = new PersonnelRepository();
        $personnelResult = $personnelRepo->activeWithCycleStatus(
            $q, $selectedDivision, $limit, ($page - 1) * $limit,
            $isMainAdmin ? $selectedDivision : 0
        );
        $totalPersonnel = (int)$personnelResult['total'];
        $totalPersonnelPages = max(1, (int)ceil($totalPersonnel / $limit));
        if ($page > $totalPersonnelPages) {
            $page = $totalPersonnelPages;
            $personnelResult = $personnelRepo->activeWithCycleStatus(
                $q, $selectedDivision, $limit, ($page - 1) * $limit,
                $isMainAdmin ? $selectedDivision : 0
            );
        }

        $selectedDate = (string)$request->input('date', JalaliDate::today());
        try { $gregorianSelectedDate = JalaliDate::toGregorianDate($selectedDate); } catch (RuntimeException) { $selectedDate = JalaliDate::today(); $gregorianSelectedDate = JalaliDate::toGregorianDate($selectedDate); }
        $submittedIds = (new OvertimeRepository(Database::connection()))->submittedPersonnelIdsForDate($gregorianSelectedDate, $isMainAdmin ? 0 : (int)($user['division_id'] ?? 0));
        $submittedIdSet = array_fill_keys($submittedIds, true);
        foreach ($personnelResult['rows'] as &$personRow) { $personRow['submitted_on_date'] = isset($submittedIdSet[(int)$personRow['id']]); }
        unset($personRow);

        $cycles = (new CycleRepository(Database::connection()))->summary();
        return View::render('overtime/new', [
            'title' => 'ثبت اضافه‌کاری',
            'user' => $user,
            'divisions' => $divisions,
            'types' => $lookups->overtimeTypes(),
            'personnel' => $personnelResult['rows'],
            'cycles' => $cycles,
            'today' => $selectedDate,
            'submittedPersonnelIds' => $submittedIds,
            'search' => $q,
            'personnelPage' => $page,
            'personnelPages' => $totalPersonnelPages,
            'personnelTotal' => $totalPersonnel,
            'limit' => $limit,
            'selectedDivisionId' => $selectedDivision,
            'isMainAdmin' => $isMainAdmin,
            'form_nonce' => \App\Core\Csrf::formNonce(),
        ]);
    }
    public function submittedPersonnel(Request $request): string
    {
        $user = $_SESSION['user'] ?? null;
        if (!$user) { http_response_code(401); header('Content-Type: application/json; charset=utf-8'); return json_encode(['error' => 'unauthorized']); }
        try {
            $date = JalaliDate::toGregorianDate((string)$request->input('date', ''));
        } catch (RuntimeException) {
            http_response_code(422); header('Content-Type: application/json; charset=utf-8'); return json_encode(['error' => 'invalid_date']);
        }
        $isMainAdmin = strtolower(trim((string)($user['role'] ?? 'division_admin'))) === 'main_admin';
        $divisionId = $isMainAdmin ? 0 : (int)($user['division_id'] ?? 0);
        $ids = (new OvertimeRepository(Database::connection()))->submittedPersonnelIdsForDate($date, $divisionId);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        return json_encode(['ids' => $ids], JSON_UNESCAPED_UNICODE);
    }

    public function store(Request $request): string
    {
        $user=$_SESSION['user'];
        if (!\App\Core\Csrf::check($request->input('csrf_token'))) {
            http_response_code(419);
            return $this->create($request);
        }
        if (!\App\Core\Csrf::consumeFormNonce($request->input('form_nonce'))) {
            http_response_code(422);
            return $this->create($request);
        }
        $type=(int)$request->input('type_id',$request->input('type',0));$ids=(array)$request->input('personnel_ids',[]);$date=(string)$request->input('date','');$hours=(float)str_replace(['٫','،',','],'.',(string)$request->input('hours','0'));
        try {
            $isMainAdmin = strtolower(trim((string)($user['role'] ?? 'division_admin'))) === 'main_admin';
            $user['selected_division_id'] = $isMainAdmin ? (int)$request->input('division_id', 0) : (int)($user['division_id'] ?? 0);
            $this->service()->submitBatch(
                $user, $type, $date, $hours,
                trim((string)$request->input('description','')),
                $ids, (string)($_SERVER['REMOTE_ADDR'] ?? '')
            );
            header('Location: /overtime/new?success=1');
            exit;
        } catch (RuntimeException $e) {
            // Validation and authorization failures should not become HTTP 500s.
            http_response_code($e->getMessage() === 'forbidden_division' ? 403 : 422);
            return $this->create($request);
        } catch (PDOException $e) {
            // Keep the full database exception in storage/logs/app.log while
            // avoiding an unhandled exception on the submission endpoint.
            ErrorHandler::log(dirname(__DIR__, 3), $e);
            http_response_code(500);
            return View::render('errors/500', [], false);
        } catch (Throwable $e) {
            ErrorHandler::log(dirname(__DIR__, 3), $e);
            http_response_code(500);
            return View::render('errors/500', [], false);
        }
    }
    public function delete(Request $request): never {
        if (!\App\Core\Csrf::check($request->input('csrf_token',''))) { http_response_code(419); echo 'توکن امنیتی نامعتبر است.'; exit; }
        try {
            $this->service()->delete($_SESSION['user'],(int)$request->input('entry_id'),$_SERVER['REMOTE_ADDR']??null);
            header('Location: '.(str_starts_with((string)$request->input('back',''),'/reports')?$request->input('back'):'/reports'));
        } catch (\RuntimeException $e) {
            http_response_code($e->getMessage()==='forbidden_division'?403:422);
            echo $e->getMessage()==='not_found' ? 'رکورد موردنظر پیدا نشد.' : 'حذف رکورد انجام نشد.';
        }
        exit;
    }
}
