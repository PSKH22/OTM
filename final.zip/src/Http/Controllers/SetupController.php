<?php
namespace App\Http\Controllers;

use App\Core\Csrf;
use App\Core\Database;
use App\Core\Response;
use App\Core\View;
use App\Repositories\AuditLogRepository;
use App\Repositories\UserRepository;
use App\Support\PasswordHasher;
use PDO;
use Throwable;

final class SetupController
{
    public function show(): string
    {
        $users = new UserRepository();
        if (!$this->syncEnabled() && $users->countMainAdmins() > 0) Response::redirect('/login');

        return View::render('setup', [
            'title' => 'مدیریت مدیران اصلی',
            'csrf' => Csrf::token(),
            'admins' => $this->configuredAdmins(),
            'existingMainAdmins' => $users->countMainAdmins(),
            'syncEnabled' => $this->syncEnabled(),
        ], false);
    }

    public function store(): string
    {
        $users = new UserRepository();
        $syncEnabled = $this->syncEnabled();
        if (!$syncEnabled && $users->countMainAdmins() > 0) Response::redirect('/login');

        $admins = $this->configuredAdmins();
        $render = function (string $error, array $configured = null) use ($users, $admins, $syncEnabled): string {
            return View::render('setup', [
                'title' => 'مدیریت مدیران اصلی',
                'csrf' => Csrf::token(),
                'admins' => $configured ?? $admins,
                'existingMainAdmins' => $users->countMainAdmins(),
                'syncEnabled' => $syncEnabled,
                'error' => $error,
            ], false);
        };

        if (!Csrf::check((string)($_POST['csrf_token'] ?? ''))) {
            http_response_code(419);
            return $render('توکن امنیتی نامعتبر است. صفحه را دوباره بارگذاری کنید.');
        }
        if (!$admins) return $render('هیچ حساب مدیر اصلی در فایل .env پیکربندی نشده است.');

        try {
            $seen = [];
            foreach ($admins as $number => $admin) {
                $this->validateAdmin($admin);
                $normalized = strtolower($admin['username']);
                if (isset($seen[$normalized])) throw new \InvalidArgumentException('نام کاربری مدیران اصلی باید یکتا باشد.');
                $seen[$normalized] = true;
            }

            if ($syncEnabled) {
                $created = $this->synchronizeMainAdmins($admins);
            } else {
                $created = $this->createInitialMainAdmins($admins);
            }
        } catch (\InvalidArgumentException $e) {
            return $render($e->getMessage());
        } catch (Throwable $e) {
            error_log('Main admin setup failed: ' . $e->getMessage());
            return $render('به‌روزرسانی مدیران اصلی انجام نشد. تنظیمات .env و پایگاه داده را بررسی کنید؛ هیچ تغییری ثبت نشده است.');
        }

        if ($users->countMainAdmins() === 0) return $render('هیچ مدیر اصلی ایجاد نشد. تنظیمات MAIN_ADMIN_n_* در فایل .env را بررسی کنید.');
        Response::redirect('/login?setup=complete&created=' . $created . ($syncEnabled ? '&synced=1' : ''));
    }

    private function createInitialMainAdmins(array $admins): int
    {
        return Database::transaction(function (PDO $pdo) use ($admins): int {
            $users = new UserRepository();
            $created = 0;
            foreach ($admins as $admin) {
                $existing = $users->findByUsername($admin['username']);
                if ($existing) continue;
                $users->create($admin['username'], PasswordHasher::hash($admin['password']), $admin['display_name'], null, 'main_admin');
                $created++;
            }
            return $created;
        });
    }

    /** Replace the main-admin account set with the exact list configured in .env. */
    private function synchronizeMainAdmins(array $admins): int
    {
        return Database::transaction(function (PDO $pdo) use ($admins): int {
            $created = 0;
            $configuredIds = [];
            $firstId = null;

            foreach ($admins as $admin) {
                $find = $pdo->prepare('SELECT id, role FROM users WHERE username = :username LIMIT 1 FOR UPDATE');
                $find->execute(['username' => $admin['username']]);
                $existing = $find->fetch();
                if ($existing && $existing['role'] !== 'main_admin') {
                    throw new \InvalidArgumentException('نام کاربری «' . $admin['username'] . '» قبلاً برای مدیر واحد استفاده شده است. ابتدا نام کاربری دیگری در .env انتخاب کنید.');
                }

                $hash = PasswordHasher::hash($admin['password']);
                if ($existing) {
                    $id = (int)$existing['id'];
                    $update = $pdo->prepare('UPDATE users SET password_hash=:password, display_name=:display_name, division_id=NULL, role=\'main_admin\', is_active=1 WHERE id=:id');
                    $update->execute(['password' => $hash, 'display_name' => $admin['display_name'], 'id' => $id]);
                } else {
                    $insert = $pdo->prepare('INSERT INTO users(username,password_hash,display_name,division_id,role,is_active) VALUES(:username,:password,:display_name,NULL,\'main_admin\',1)');
                    $insert->execute(['username' => $admin['username'], 'password' => $hash, 'display_name' => $admin['display_name']]);
                    $id = (int)$pdo->lastInsertId();
                    $created++;
                }
                $configuredIds[] = $id;
                if ($firstId === null) $firstId = $id;
            }

            $oldStmt = $pdo->query("SELECT id FROM users WHERE role='main_admin' FOR UPDATE");
            $oldIds = array_map('intval', $oldStmt->fetchAll(PDO::FETCH_COLUMN));
            $keep = array_fill_keys($configuredIds, true);
            $removeIds = array_values(array_filter($oldIds, static fn(int $id): bool => !isset($keep[$id])));

            // Keep historical records valid when an old main-admin account is removed.
            foreach ($removeIds as $oldId) {
                $entries = $pdo->prepare('UPDATE overtime_entries SET created_by=:replacement WHERE created_by=:old_id');
                $entries->execute(['replacement' => $firstId, 'old_id' => $oldId]);
                $auditRows = $pdo->prepare('UPDATE audit_log SET user_id=:replacement WHERE user_id=:old_id');
                $auditRows->execute(['replacement' => $firstId, 'old_id' => $oldId]);
            }
            if ($removeIds) {
                $marks = implode(',', array_fill(0, count($removeIds), '?'));
                $delete = $pdo->prepare("DELETE FROM users WHERE role='main_admin' AND id IN ({$marks})");
                $delete->execute($removeIds);
            }

            (new AuditLogRepository($pdo))->add($firstId, 'main_admins_synchronized', null, [
                'configured_usernames' => array_column($admins, 'username'),
                'removed_account_count' => count($removeIds),
                'created_account_count' => $created,
                'history_preserved' => true,
            ], $_SERVER['REMOTE_ADDR'] ?? null);

            return $created;
        });
    }

    private function syncEnabled(): bool
    {
        return in_array(strtolower(trim((string)($_ENV['SETUP_SYNC_MAIN_ADMINS'] ?? '0'))), ['1', 'true', 'yes', 'on'], true);
    }

    private function configuredAdmins(): array
    {
        $admins = [];
        foreach ($_ENV as $key => $value) {
            if (preg_match('/^MAIN_ADMIN_(\d+)_USERNAME$/', $key, $match)) {
                $number = (int)$match[1];
                $admins[$number] = [
                    'username' => $this->env("MAIN_ADMIN_{$number}_USERNAME"),
                    'password' => $this->env("MAIN_ADMIN_{$number}_PASSWORD"),
                    'display_name' => $this->env("MAIN_ADMIN_{$number}_DISPLAY_NAME"),
                ];
            }
        }
        ksort($admins);
        return $admins;
    }

    private function env(string $key): ?string
    {
        $value = $_ENV[$key] ?? null;
        if ($value === null) return null;
        $value = trim((string)$value);
        return $value === '' ? null : $value;
    }

    private function validateAdmin(array $admin): void
    {
        foreach (['username', 'password', 'display_name'] as $field) {
            if (empty($admin[$field])) throw new \InvalidArgumentException("فیلد {$field} در تنظیمات .env وجود ندارد.");
        }
        if (strlen($admin['username']) > 64 || !preg_match('/^[A-Za-z0-9._@-]+$/', $admin['username'])) throw new \InvalidArgumentException('نام کاربری نامعتبر است.');
        if (strlen($admin['password']) < 12) throw new \InvalidArgumentException('گذرواژه باید حداقل ۱۲ کاراکتر باشد.');
        if (mb_strlen($admin['display_name']) > 120) throw new \InvalidArgumentException('نام نمایشی بیش از حد طولانی است.');
    }
}
