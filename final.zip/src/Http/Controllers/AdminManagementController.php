<?php
namespace App\Http\Controllers;
use App\Core\Csrf; use App\Core\Database; use App\Core\Request; use App\Core\Response; use App\Core\View; use App\Repositories\LookupRepository; use App\Repositories\UserRepository; use App\Support\PasswordHasher; use App\Support\TextNormalizer; use Throwable;
final class AdminManagementController
{
    private function guard(): void { if (($_SESSION['user']['role'] ?? '') !== 'main_admin') { http_response_code(403); echo 'دسترسی مجاز نیست.'; exit; } }
    public function index(Request $request): string { $this->guard(); $q=trim((string)$request->input('q',''));$page=max(1,(int)$request->input('page',1));$allowedPageSizes=[10,25,50,75,100];$requestedLimit=(int)$request->input('limit',50);$limit=in_array($requestedLimit,$allowedPageSizes,true)?$requestedLimit:50;$repo=new UserRepository();$result=$repo->allDivisionAdmins($q,$limit,($page-1)*$limit);$pages=max(1,(int)ceil($result['total']/$limit));if($page>$pages){$page=$pages;$result=$repo->allDivisionAdmins($q,$limit,($page-1)*$limit);}return View::render('admin-management/index',['title'=>'مدیریت مدیران','active'=>'admins','user'=>$_SESSION['user'],'divisions'=>(new LookupRepository())->divisions(),'admins'=>$result['rows'],'adminPage'=>$page,'adminPages'=>$pages,'adminTotal'=>$result['total'],'adminLimit'=>$limit,'search'=>$q,'errors'=>[],'old'=>['username'=>'','display_name'=>'','password'=>'','division_id'=>'']]); }
    public function store(Request $request): string { $this->guard(); if(!Csrf::check((string)$request->input('csrf_token',''))){http_response_code(419);return 'توکن امنیتی نامعتبر است.';} $username=trim((string)$request->input('username',''));$name=trim((string)$request->input('display_name',''));$password=(string)$request->input('password','');$division=(int)$request->input('division_id',0);$errors=[];
        if(!preg_match('/^[A-Za-z0-9._@-]{1,64}$/',$username))$errors[]='نام کاربری باید ۱ تا ۶۴ کاراکتر لاتین، عدد یا . _ @ - باشد.';
        if($name===''||mb_strlen($name)>120)$errors[]='نام نمایشی الزامی است و حداکثر ۱۲۰ کاراکتر دارد.';
        if(strlen($password)<12)$errors[]='گذرواژه باید حداقل ۱۲ کاراکتر باشد.';
        $lookups=(new LookupRepository())->divisions();if(!in_array($division,array_map(fn($d)=>(int)$d['id'],$lookups),true))$errors[]='واحد انتخاب‌شده معتبر نیست.';
        $repo=new UserRepository(); if(!$errors){try{$repo->create($username,PasswordHasher::hash($password),$name,$division,'division_admin');Response::redirect('/admin-management?success=1');}catch(\PDOException $e){if((string)$e->getCode()==='23000')$errors[]='این نام کاربری قبلاً ثبت شده است.';else throw $e;}}
        $requestedLimit=(int)$request->input('limit',50);$limit=in_array($requestedLimit,[10,25,50,75,100],true)?$requestedLimit:50;$result=$repo->allDivisionAdmins('', $limit, 0);return View::render('admin-management/index',['title'=>'مدیریت مدیران','active'=>'admins','user'=>$_SESSION['user'],'divisions'=>$lookups,'admins'=>$result['rows'],'adminPage'=>1,'adminPages'=>max(1,(int)ceil($result['total']/$limit)),'adminLimit'=>$limit,'adminTotal'=>$result['total'],'search'=>'','errors'=>$errors,'old'=>['username'=>$username,'display_name'=>$name,'password'=>'','division_id'=>$division]]);
    }
    public function toggle(Request $request): never { $this->guard();if(!Csrf::check((string)$request->input('csrf_token',''))){http_response_code(419);exit('توکن امنیتی نامعتبر است.');}$id=(int)$request->input('admin_id',0);$active=(string)$request->input('active','')==='1';if($id<1||! (new UserRepository())->setActiveDivisionAdmin($id,$active)){Response::redirect('/admin-management?error=not_found');}Response::redirect('/admin-management?updated=' . ($active?'activated':'deactivated')); }
    public function remove(Request $request): never
    {
        $this->guard();
        if (!Csrf::check((string)$request->input('csrf_token',''))) { http_response_code(419); exit('توکن امنیتی نامعتبر است.'); }
        $id = (int)$request->input('admin_id', 0);
        $mode = (string)$request->input('remove_mode', '');
        if ($id < 1 || !in_array($mode, ['deactivate', 'delete'], true)) Response::redirect('/admin-management?error=invalid_remove');
        $ok = (new UserRepository())->removeDivisionAdmin($id, $mode, (int)$_SESSION['user']['id'], $_SERVER['REMOTE_ADDR'] ?? null);
        if (!$ok) Response::redirect('/admin-management?error=not_found');
        Response::redirect('/admin-management?removed=' . ($mode === 'deactivate' ? 'deactivated' : 'deleted'));
    }
}
