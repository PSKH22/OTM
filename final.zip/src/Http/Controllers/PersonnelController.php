<?php
namespace App\Http\Controllers;

use App\Core\Csrf;
use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Repositories\LookupRepository;
use App\Repositories\PersonnelRepository;
use App\Support\TextNormalizer;
use RuntimeException;
use Throwable;

final class PersonnelController
{
    public function index(Request $request): string
    {
        $user = $_SESSION['user'];
        $repository = new PersonnelRepository();
        $divisionId = (($user['role'] ?? 'division_admin') === 'main_admin') ? 0 : (int)$user['division_id'];
        $q = TextNormalizer::normalize((string)$request->input('q', ''));
        $page = max(1, (int)$request->input('page', 1));
        $allowedPageSizes = [10, 25, 50, 75, 100];
        $requestedLimit = (int)$request->input('limit', 50);
        $limit = in_array($requestedLimit, $allowedPageSizes, true) ? $requestedLimit : 50;
        $result = $repository->all($q, $divisionId, $limit, ($page - 1) * $limit);
        $totalPersonnel = (int)$result['total'];
        $totalPages = max(1, (int)ceil($totalPersonnel / $limit));
        if ($page > $totalPages) {
            $page = $totalPages;
            $result = $repository->all($q, $divisionId, $limit, ($page - 1) * $limit);
        }

        return View::render('personnel/index', [
            'title' => 'مدیریت پرسنل',
            'active' => 'personnel',
            'user' => $user,
            'divisions' => (new LookupRepository())->divisions(),
            'personnel' => $result['rows'],
            'personnelPage' => $page,
            'personnelPages' => $totalPages,
            'personnelTotal' => $totalPersonnel,
            'limit' => $limit,
            'search' => $q,
            'ownDivisionId' => (($user['role'] ?? 'division_admin') === 'main_admin') ? (int)($user['division_id'] ?? 0) : $divisionId,
            'isMainAdmin' => (($user['role'] ?? 'division_admin') === 'main_admin'),
            'errors' => [],
            'old' => [
                'personnel_code' => '',
                'full_name' => '',
            ],
        ]);
    }

    public function store(Request $request): string
    {
        $user = $_SESSION['user'];
        $code = TextNormalizer::normalize((string)$request->input('personnel_code', ''));
        $name = trim((string)$request->input('full_name', ''));
        $divisionId = (($user['role'] ?? 'division_admin') === 'main_admin') ? (int)$request->input('division_id', 0) : (int)$user['division_id'];
        $errors = [];
        $knownDivisionIds = array_map(static fn($division) => (int)$division['id'], (new LookupRepository())->divisions());
        if ($divisionId < 1 || !in_array($divisionId, $knownDivisionIds, true)) $errors[] = 'واحد انتخاب‌شده معتبر نیست.';

        if (!preg_match('/^[0-9A-Za-z\-\/]{1,32}$/', $code)) {
            $errors[] = 'کد پرسنلی باید حداکثر ۳۲ کاراکتر و شامل حروف، اعداد، خط تیره یا / باشد.';
        }
        if ($name === '' || mb_strlen($name) > 120) {
            $errors[] = 'نام و نام خانوادگی الزامی است و حداکثر ۱۲۰ کاراکتر دارد.';
        }

        $repository = new PersonnelRepository();
        if (!$errors) {
            try {
                $repository->create($code, $name, $divisionId);
                header('Location: /personnel?success=1');
                exit;
            } catch (Throwable $e) {
                if ($e instanceof \PDOException && (string)$e->getCode() === '23000') {
                    $errors[] = 'این کد پرسنلی قبلاً ثبت شده است.';
                } else {
                    throw $e;
                }
            }
        }

        $q = TextNormalizer::normalize((string)$request->input('q', ''));
        $page = max(1, (int)$request->input('page', 1));
        $allowedPageSizes = [10, 25, 50, 75, 100];
        $requestedLimit = (int)$request->input('limit', 50);
        $limit = in_array($requestedLimit, $allowedPageSizes, true) ? $requestedLimit : 50;
        $result = $repository->all($q, $divisionId, $limit, ($page - 1) * $limit);
        $totalPersonnel = (int)$result['total'];
        $totalPages = max(1, (int)ceil($totalPersonnel / $limit));
        if ($page > $totalPages) { $page = $totalPages; $result = $repository->all($q, $divisionId, $limit, ($page - 1) * $limit); }

        return View::render('personnel/index', [
            'title' => 'مدیریت پرسنل',
            'active' => 'personnel',
            'user' => $user,
            'divisions' => (new LookupRepository())->divisions(),
            'personnel' => $result['rows'],
            'personnelPage' => $page,
            'personnelPages' => $totalPages,
            'personnelTotal' => $totalPersonnel,
            'limit' => $limit,
            'search' => $q,
            'ownDivisionId' => (($user['role'] ?? 'division_admin') === 'main_admin') ? 0 : $divisionId,
            'isMainAdmin' => (($user['role'] ?? 'division_admin') === 'main_admin'),
            'errors' => $errors,
            'old' => [
                'personnel_code' => $code,
                'full_name' => $name,
                'division_id' => (($user['role'] ?? 'division_admin') === 'main_admin') ? $divisionId : '',
            ],
        ]);
    }
    public function reactivate(Request $request): string
    {
        $user = $_SESSION['user'];
        $id = (int)$request->input('personnel_id', 0);
        if ($id <= 0) {
            header('Location: /personnel?error=invalid_reactivate');
            exit;
        }

        try {
            (new PersonnelRepository())->reactivate(
                $id,
                (($user['role'] ?? 'division_admin') === 'main_admin') ? 0 : (int)$user['division_id'],
                (int)$user['id'],
                $_SERVER['REMOTE_ADDR'] ?? null
            );
            header('Location: /personnel?reactivated=1');
            exit;
        } catch (RuntimeException $e) {
            if ($e->getMessage() === 'not_found') {
                header('Location: /personnel?error=not_found');
                exit;
            }
            throw $e;
        }
    }

    public function delete(Request $request): string
    {
        $user = $_SESSION['user'];
        $id = (int)$request->input('personnel_id', 0);
        $mode = (string)$request->input('remove_mode', '');

        if ($id <= 0 || !in_array($mode, ['keep_logs', 'delete_logs'], true)) {
            header('Location: /personnel?error=invalid_remove');
            exit;
        }

        try {
            (new PersonnelRepository())->remove(
                $id,
                (($user['role'] ?? 'division_admin') === 'main_admin') ? 0 : (int)$user['division_id'],
                $mode,
                (int)$user['id'],
                $_SERVER['REMOTE_ADDR'] ?? null
            );
            header('Location: /personnel?removed=' . ($mode === 'keep_logs' ? 'kept' : 'deleted'));
            exit;
        } catch (RuntimeException $e) {
            $code = $e->getMessage();
            if ($code === 'not_found') {
                header('Location: /personnel?error=not_found');
                exit;
            }
            throw $e;
        }
    }

}
