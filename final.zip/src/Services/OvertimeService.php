<?php
namespace App\Services;
use App\Core\Database;
use App\Repositories\AuditLogRepository;
use App\Repositories\CycleRepository;
use App\Repositories\OvertimeRepository;
use App\Repositories\PersonnelRepository;
use App\Repositories\LookupRepository;
use App\Support\JalaliDate;
use RuntimeException;
use Throwable;

final class OvertimeService
{
    public function __construct(private OvertimeRepository $entries,private PersonnelRepository $personnel,private LookupRepository $lookups,private CycleRepository $cycles,private AuditLogRepository $audit,private CycleService $cycleService) {}

    public function submitBatch(array $user,int $typeId,string $jalaliDate,float $hours,?string $description,array $personnelIds,string $ip): array
    {
        $types=$this->lookups->overtimeTypes();$type=null;foreach($types as $t)if((int)$t['id']===$typeId)$type=$t;
        if(!$type)throw new RuntimeException('invalid_type');
        $cap=(float)\App\Core\Config::get('app.hours_cap',8); if($hours<0.25||$hours>$cap||abs(($hours*4)-round($hours*4))>1e-9)throw new RuntimeException('invalid_hours');
        // Validate the selected date against the overtime type on the server.
        // Cycles apply only to weekend overtime; weekdays and out-of-quota
        // overtime are stored without a cycle.
        $weekday=JalaliDate::weekday($jalaliDate);
        $dayRule=(string)($type['day_rule']??'any');
        $isWeekend=in_array($weekday,[4,5],true); // Thursday / Friday
        if($dayRule==='workday' && $isWeekend)throw new RuntimeException('day_rule');
        if($dayRule==='weekend' && !$isWeekend)throw new RuntimeException('day_rule');
        $gdate=JalaliDate::toGregorianDate($jalaliDate); $today=new \DateTimeImmutable('today',new \DateTimeZone('Asia/Tehran')); $submitted=new \DateTimeImmutable($gdate); $window=(int)\App\Core\Config::get('app.submission_window_days',366); if($submitted < $today->modify('-'.$window.' days') || $submitted > $today->modify('+'.$window.' days')) throw new RuntimeException('date_window'); $ids=array_values(array_unique(array_map('intval',$personnelIds)));if(!$ids||count($ids)>500)throw new RuntimeException('no_personnel');
        return Database::transaction(function()use($user,$type,$typeId,$jalaliDate,$gdate,$hours,$description,$ids,$ip){
            $pdo=Database::connection();$cycle=null;
            $people=$this->personnel->findActiveByIds($ids);
            if(count($people)!==count($ids))throw new RuntimeException('invalid_personnel');
            // A person may have only one overtime entry per calendar date, regardless of type.
            if ($this->entries->personnelAlreadySubmittedOnDate($ids, $gdate)) {
                throw new RuntimeException('already_submitted_on_date');
            }

            $divisionIds = array_values(array_unique(array_map(static fn($p) => (int)$p['division_id'], $people)));
            sort($divisionIds);
            $isMainAdmin = strtolower(trim((string)($user['role'] ?? 'division_admin'))) === 'main_admin';
            $usesCycle = (int)($type['uses_cycle'] ?? 0) === 1;
            $selectedDivisionId = $isMainAdmin ? (int)($user['selected_division_id'] ?? 0) : (int)($user['division_id'] ?? 0);

            // Division admins remain restricted to their assigned division.
            // Main admins may choose personnel across divisions when no single
            // division is selected. For cycle-based (weekend) overtime, each
            // division's personnel must use that division's own open cycle.
            if (!$isMainAdmin) {
                $allowedDivisionId = (int)($user['division_id'] ?? 0);
                if ($allowedDivisionId < 1 || count(array_diff($divisionIds, [$allowedDivisionId])) > 0) {
                    throw new RuntimeException('forbidden_division');
                }
            } elseif ($selectedDivisionId > 0 && count(array_diff($divisionIds, [$selectedDivisionId])) > 0) {
                throw new RuntimeException('forbidden_division');
            }

            // Resolve and validate cycles independently for each division.
            // Keeping the mapping by division ensures every inserted record
            // references a cycle owned by the same division as its personnel.
            $cyclesByDivision = [];
            if ($usesCycle) {
                $personnelByDivision = [];
                foreach ($people as $person) {
                    $personnelByDivision[(int)$person['division_id']][] = (int)$person['id'];
                }
                foreach ($divisionIds as $divisionId) {
                    $cycle = $this->cycleService->open($divisionId);
                    if (!$cycle || (int)($cycle['division_id'] ?? 0) !== $divisionId) {
                        throw new RuntimeException('cycle_unavailable');
                    }
                    $used = $this->entries->usedPersonnel((int)$cycle['id'], $personnelByDivision[$divisionId] ?? []);
                    if ($used) {
                        throw new RuntimeException('already_used');
                    }
                    $cyclesByDivision[$divisionId] = $cycle;
                }
            }

            $inserted = [];
            foreach ($people as $person) {
                $personDivisionId = (int)$person['division_id'];
                // Store the actual personnel division for correct reports and
                // division-scoped access, for both cycle and non-cycle entries.
                $cycle = $usesCycle ? ($cyclesByDivision[$personDivisionId] ?? null) : null;
                $inserted[] = $this->entries->insert([
                    'p' => (int)$person['id'],
                    'd' => $personDivisionId,
                    't' => $typeId,
                    'date' => $gdate,
                    'h' => $hours,
                    'desc' => $description ?: null,
                    'c' => $cycle['id'] ?? null,
                    'u' => $user['id'],
                ]);
            }

            // Close and advance only the divisions whose cycle is now complete.
            foreach ($cyclesByDivision as $divisionId => $cycle) {
                if ($this->cycles->remainingActive((int)$divisionId, (int)$cycle['id']) === 0) {
                    $this->cycles->close((int)$cycle['id']);
                    $this->cycles->create((int)$divisionId, (int)$cycle['cycle_number'] + 1);
                }
            }
            return ['ids' => $inserted, 'count' => count($inserted), 'date' => $jalaliDate, 'cycles' => array_map(static fn($cycle) => ['division_id' => (int)$cycle['division_id'], 'cycle_number' => (int)$cycle['cycle_number']], array_values($cyclesByDivision))];
        });
    }

    public function delete(array $user,int $entryId,string $ip): array
    {
        return Database::transaction(function()use($user,$entryId,$ip){
            $entry=$this->entries->findForUpdate($entryId);if(!$entry)throw new RuntimeException('not_found');
            $divisionId=(int)$entry['division_id']; if((($user['role']??'division_admin')!=='main_admin') && $divisionId!==(int)$user['division_id'])throw new RuntimeException('forbidden_division');
            $open=$this->cycles->openForUpdate($divisionId);
            $this->entries->delete($entryId);$undo=false;
            if($entry['cycle_id']!==null && $open && (int)$entry['cycle_id']!==(int)$open['id']){
                $prev=$this->cycles->latestClosed($divisionId);
                if($prev && (int)$prev['id']===(int)$entry['cycle_id'] && $this->cycles->entriesCount((int)$open['id'])===0){$this->cycles->delete((int)$open['id']);$this->cycles->reopen((int)$prev['id']);$undo=true;}
            }
            $entry['jalali_date']=JalaliDate::fromGregorian($entry['overtime_date']); $this->audit->add((int)$user['id'],'overtime.delete',$entryId,$entry,$ip);
            return ['deleted'=>true,'undo_close'=>$undo];
        });
    }
}
