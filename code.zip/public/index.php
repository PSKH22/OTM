<?php
require dirname(__DIR__) . '/src/bootstrap.php';
use App\Core\Request; use App\Core\Router; use App\Core\Response; use App\Http\Controllers\AuthController; use App\Http\Controllers\OvertimeController; use App\Http\Controllers\ReportController; use App\Http\Controllers\PersonnelController; use App\Http\Controllers\SetupController;
session_name($_ENV['SESSION_NAME'] ?? 'overtime_sid'); session_set_cookie_params(['httponly'=>true,'secure'=>(($_ENV['COOKIE_SECURE']??'0')==='1'),'samesite'=>'Lax','path'=>'/']); session_start();
$request=Request::capture();

// Refresh the authenticated user from the database on every request. This makes
// deactivation and division changes effective immediately instead of trusting
// stale session data.
if (!empty($_SESSION['user']['id'])) {
    $freshUser = (new \App\Repositories\UserRepository())->find((int)$_SESSION['user']['id']);
    if (!$freshUser || !(int)$freshUser['is_active']) {
        $_SESSION=[];
        if (ini_get('session.use_cookies')) {
            $params=session_get_cookie_params();
            setcookie(session_name(),'',time()-42000,$params['path'],$params['domain'] ?? '',(bool)$params['secure'],(bool)$params['httponly']);
        }
        session_destroy();
        if ($request->path !== '/login' && $request->path !== '/setup') {
            App\Core\Response::redirect('/login');
        }
    } else {
        $_SESSION['user']=$freshUser;
    }
}

$router=new Router(); $auth=new AuthController(); $overtime=new OvertimeController(); $reports=new ReportController(); $personnel=new PersonnelController(); $setup=new SetupController();
$router->get('/setup', function($r) use ($setup){ return $setup->show(); });
$router->post('/setup', function($r) use ($setup){ return $setup->store(); });
$router->get('/', function($r){ Response::redirect(isset($_SESSION['user'])?'/overtime/new':'/login'); });
$router->get('/login', fn($r)=>$auth->showLogin($r)); $router->post('/login', fn($r)=>$auth->login($r)); $router->post('/logout', fn($r)=>$auth->logout($r));
$router->get('/personnel', function($r) use ($personnel){ if(empty($_SESSION['user'])) Response::redirect('/login'); return $personnel->index($r); });
$router->post('/personnel', function($r) use ($personnel){ if(empty($_SESSION['user'])) Response::redirect('/login'); if(!\App\Core\Csrf::check($r->input('csrf_token',''))) { http_response_code(419); return 'توکن امنیتی نامعتبر است.'; } return $personnel->store($r); });
$router->post('/personnel/reactivate', function($r) use ($personnel){ if(empty($_SESSION['user'])) Response::redirect('/login'); if(!\App\Core\Csrf::check($r->input('csrf_token',''))) { http_response_code(419); return 'توکن امنیتی نامعتبر است.'; } return $personnel->reactivate($r); });
$router->post('/personnel/delete', function($r) use ($personnel){ if(empty($_SESSION['user'])) Response::redirect('/login'); if(!\App\Core\Csrf::check($r->input('csrf_token',''))) { http_response_code(419); return 'توکن امنیتی نامعتبر است.'; } return $personnel->delete($r); });
$router->get('/overtime/new', function($r) use ($overtime){ if(empty($_SESSION['user'])) Response::redirect('/login'); return $overtime->create($r); });
$router->post('/overtime', function($r) use ($overtime){ if(empty($_SESSION['user'])) Response::redirect('/login'); return $overtime->store($r); });
$router->get('/reports', function($r) use ($reports){ if(empty($_SESSION['user'])) Response::redirect('/login'); return $reports->index($r); });
$router->post('/overtime/delete', function($r) use ($overtime){ if(empty($_SESSION['user'])) Response::redirect('/login'); return $overtime->delete($r); });
echo $router->dispatch($request);
