# Overtime Management — PHP + MySQL

This version keeps the approved Persian RTL frontend and uses MySQL repositories.

## Database setup

Requirements from the project plan: PHP 8.5, MySQL 9.7 LTS or 8.4 LTS, PDO MySQL and `intl`.

1. Create the database and application account.
2. Copy `.env.example` to `.env` and set `DB_*` values.
3. Run:

```sql
SOURCE database/schema.sql;
SOURCE database/seed.sql;
```

4. For local development only, load `database/dev_sample_data.sql`.

6. Configure one or more `ADMIN_n_*` groups in `.env`, then open `/setup` in the web application. The setup page creates only missing users and locks itself once any user exists.

7. Add and manage personnel from the authenticated `/personnel` page.

Administrator passwords use Argon2id with the project plan's `memory_cost=19456`, `time_cost=2`, and `threads=1` profile. The application requires Argon2id support at startup. Existing passwords created with the previous/default hashing algorithm are transparently rehashed to Argon2id on successful login.

## Apache

Point `DocumentRoot` at `public/`, enable `mod_rewrite`, and permit `.htaccess` overrides. The included `public/.htaccess` sends application routes to `public/index.php` while serving assets directly.

## Development server

```bash
php -S localhost:8000 -t public public/index.php
```

## Automatic database table initialization

After configuring `.env`, the application now automatically loads `database/schema.sql` the first time it opens the configured MySQL database. The schema uses `CREATE TABLE IF NOT EXISTS`, so existing tables are not recreated or dropped.

The MySQL database itself must already exist and the configured database user must have permission to create tables. For example, if `.env` contains `DB_NAME=otm`, create the empty `otm` database first if necessary; then opening the application will create the application tables automatically.

This automatic initialization creates the tables only. It does not insert demo users/personnel or lookup rows. Use `database/seed.sql` and `database/dev_sample_data.sql` when you want the supplied seed/demo data.


## Initial administrator setup

Configure one or more `ADMIN_n_*` groups in `.env`, then open `/setup` in the same web application. The setup page uses the normal application PHP/MySQL runtime, creates only missing users, and locks itself once any user exists. Run `database/seed.sql` first so the configured division IDs exist. Passwords are never displayed by the setup page.
