<?php
return [
'app_name'=>'مدیریت اضافه‌کاری','login'=>'ورود','logout'=>'خروج','nav_submit'=>'ثبت اضافه‌کاری','nav_reports'=>'گزارش‌ها',
'username'=>'نام کاربری','password'=>'گذرواژه','type'=>'نوع اضافه‌کاری','division'=>'واحد','date'=>'تاریخ','hours'=>'ساعت','description'=>'توضیحات',
'personnel'=>'پرسنل','personnel_id'=>'کد پرسنلی','name'=>'نام و نام خانوادگی','cycle'=>'دور','status'=>'وضعیت','search_placeholder'=>'جستجوی نام یا کد پرسنلی',
];
