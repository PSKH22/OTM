<div class="page-head">
  <div>
    <h1 class="page-title">گزارش‌ها</h1>
    <p class="page-subtitle">مشاهده سوابق اضافه‌کاری همه واحدها</p>
  </div>
</div>
<div class="card card-pad">
  <form method="get" action="/reports" id="reportForm" class="report-toolbar">
    <div class="field"><label for="from">از تاریخ</label>
      <div class="date-wrap"><input class="control" id="from" name="from" value="<?= e($filters['from'] ?? '') ?>"
          placeholder="yyyy/mm/dd" dir="ltr"><button type="button" class="calendar-btn report-cal" data-target="from"
          aria-label="انتخاب تاریخ">▣</button></div>
    </div>
    <div class="field"><label for="to">تا تاریخ</label>
      <div class="date-wrap"><input class="control" id="to" name="to" value="<?= e($filters['to'] ?? '') ?>"
          placeholder="yyyy/mm/dd" dir="ltr"><button type="button" class="calendar-btn report-cal" data-target="to"
          aria-label="انتخاب تاریخ">▣</button></div>
    </div>
    <div class="field"><label for="division_id">واحد</label><select id="division_id" name="division_id" class="control">
        <option value="">همه واحدها</option><?php foreach ($divisions as $d): ?>
          <option value="<?= e($d['id']) ?>" <?= (string) ($filters['division_id'] ?? '') === (string) $d['id'] ? 'selected' : '' ?>>
            <?= e($d['name']) ?></option><?php endforeach; ?>
      </select></div>
    <div class="field"><label for="type_id">نوع</label><select id="type_id" name="type_id" class="control">
        <option value="">همه انواع</option><?php foreach ($types as $t): ?>
          <option value="<?= e($t['id']) ?>" <?= (string) ($filters['type_id'] ?? '') === (string) $t['id'] ? 'selected' : '' ?>>
            <?= e($t['name']) ?></option><?php endforeach; ?>
      </select></div>
    <div class="field wide"><label for="reportSearch">نام / کد پرسنلی</label><input class="control" id="reportSearch"
        name="q" value="<?= e($filters['q'] ?? '') ?>" placeholder="جستجوی نام یا کد پرسنلی…"></div>
    <button type="submit" class="btn btn-secondary">اعمال فیلترها</button><button type="button" class="btn btn-primary"
      id="reportPdfBtn">خروجی PDF</button>
  </form>
  <div class="summary" id="reportSummary"><span><strong
        data-summary="count"><?= e(num($summary['total'] ?? count($entries))) ?></strong> رکورد</span><span><strong
        data-summary="hours"><?= e(num(number_format((float) ($total_hours ?? 0), 1, '.', ''))) ?></strong> ساعت</span></div>
  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr>
          <th>تاریخ</th>
          <th>کد</th>
          <th>نام</th>
          <th>واحد</th>
          <th>نوع</th>
          <th>ساعت</th>
          <th>دور</th>
          <th>توضیحات</th>
          <th>عملیات</th>
        </tr>
      </thead>
      <tbody id="reportBody"><?php foreach ($entries as $entry): ?>
          <tr data-entry="<?= e($entry['id']) ?>" data-date="<?= e($entry['date']) ?>"
            data-division="<?= e($entry['division_id']) ?>" data-type="<?= e($entry['type_id']) ?>"
            data-type-code="<?= e($entry['type_code']) ?>" data-hours="<?= e($entry['hours']) ?>">
            <td dir="ltr"><?= e(num($entry['date'])) ?></td>
            <td dir="ltr"><?= e(num($entry['personnel_code'])) ?></td>
            <td><?= e($entry['full_name']) ?></td>
            <td><?= e($entry['division']) ?></td>
            <td><span class="pill"><?= e($entry['type']) ?></span></td>
            <td dir="ltr"><?= e($entry['hours']) ?></td>
            <td><?= e($entry['cycle_number'] === null ? '—' : num($entry['cycle_number'])) ?></td>
            <td><?= e($entry['description'] ?: '—') ?></td>
            <td><?php if ((int) $entry['division_id'] === (int) ($_SESSION['user']['division_id'] ?? 0)): ?><button
                  class="btn btn-danger btn-sm delete-btn" type="button"
                  data-id="<?= e($entry['id']) ?>">حذف</button><?php else: ?><span class="status status-lock">مجاز
                  نیست</span><?php endif; ?></td>
          </tr><?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php
  $currentPage = (int) ($summary['page'] ?? 1);
  $totalPages = (int) ($summary['pages'] ?? 1);
  $pageUrl = function (int $page) use ($filters): string {
    $params = [
      'from' => $filters['from'] ?? '',
      'to' => $filters['to'] ?? '',
      'division_id' => $filters['division_id'] ?? '',
      'type_id' => $filters['type_id'] ?? '',
      'q' => $filters['q'] ?? '',
      'page' => $page,
    ];
    return '/reports?' . http_build_query(array_filter($params, static fn($v) => $v !== ''));
  };
  ?>
  <div class="pagination" aria-label="صفحه‌بندی گزارش">
    <a class="btn btn-secondary btn-sm pagination-btn <?= $currentPage > 1 ? '' : 'pagination-btn-hidden' ?>"
      href="<?= e($pageUrl(max(1, $currentPage - 1))) ?>">قبلی</a>
    <span class="page-number">صفحه <?= e(num($currentPage)) ?> از <?= e(num($totalPages)) ?></span>
    <a class="btn btn-secondary btn-sm pagination-btn <?= $currentPage < $totalPages ? '' : 'pagination-btn-hidden' ?>"
      href="<?= e($pageUrl(min($totalPages, $currentPage + 1))) ?>">بعدی</a>
  </div>
</div>

<div id="reportDeleteDialog" class="dialog-backdrop hidden" role="dialog" aria-modal="true"
  aria-labelledby="reportDeleteTitle">
  <div class="dialog">
    <h3 id="reportDeleteTitle">حذف رکورد</h3>
    <p id="reportDeleteMessage">آیا از حذف این رکورد اضافه‌کاری مطمئن هستید؟</p>
    <form method="post" action="/overtime/delete" id="reportDeleteForm">
      <input type="hidden" name="csrf_token" value="<?= e(\App\Core\Csrf::token()) ?>">
      <input type="hidden" name="entry_id" id="reportDeleteId" value="">
      <input type="hidden" name="back" id="reportDeleteBack" value="">
      <div class="dialog-actions report-delete-actions">
        <button type="submit" class="btn btn-danger">حذف</button>
        <button type="button" class="btn btn-cancel" id="reportDeleteCancel">انصراف</button>
      </div>
    </form>
  </div>
</div>