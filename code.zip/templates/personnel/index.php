<div class="page-head">
  <div>
    <h1 class="page-title">مدیریت پرسنل</h1>
    <p class="page-subtitle">افزودن و مشاهده کارکنان. امکان افزودن کارمند به بخش دیگر وجود ندارد.</p>
  </div>
</div>
<?php if (!empty($errors)): ?>
  <div class="notice notice-danger" style="margin-bottom:15px"><?php foreach ($errors as $error): ?>
      <div><?= e($error) ?></div><?php endforeach; ?>
  </div>
<?php elseif (isset($_GET['success'])): ?>
  <div class="flash">کارمند با موفقیت اضافه شد.</div>
<?php elseif (($_GET['removed'] ?? '') === 'kept'): ?>
  <div class="flash">کارمند غیرفعال شد و سوابق اضافه‌کاری او حفظ شد.</div>
<?php elseif (($_GET['removed'] ?? '') === 'deleted'): ?>
  <div class="flash">کارمند و سوابق اضافه‌کاری او حذف شد.</div>
<?php elseif (isset($_GET['reactivated'])): ?>
  <div class="flash">کارمند با موفقیت فعال شد.</div>
<?php elseif (isset($_GET['error'])): ?>
  <div class="notice notice-danger" style="margin-bottom:15px">
    <?= ($_GET['error'] ?? '') === 'not_found' ? 'کارمند پیدا نشد یا به واحد شما تعلق ندارد.' : 'عملیات حذف معتبر نیست.' ?>
  </div>
<?php endif; ?>
<div class="card card-pad">
  <form method="post" action="/personnel">
    <input type="hidden" name="csrf_token" value="<?= e(\App\Core\Csrf::token()) ?>">
    <div class="form-grid personnel-create-grid">
      <div class="field"><label for="personnel_code">کد پرسنلی</label><input class="control" id="personnel_code"
          name="personnel_code" value="<?= e($old['personnel_code'] ?? '') ?>" maxlength="32"
          placeholder="مانند 54875" required></div>
      <div class="field"><label for="full_name">نام و نام خانوادگی</label><input class="control" id="full_name"
          name="full_name" value="<?= e($old['full_name'] ?? '') ?>" maxlength="120" placeholder="مانند سیاوش نامدار"
          required></div>
      <div class="field"><label for="division">واحد</label><select class="control" id="division"
          disabled><?php foreach ($divisions as $d): ?><?php if ((int) $d['id'] === (int) $ownDivisionId): ?>
              <option selected><?= e($d['name']) ?></option><?php endif; ?><?php endforeach; ?>
        </select>
        <div class="muted" style="font-size:11px;margin-top:5px">واحد از حساب کاربری تعیین می‌شود.</div>
      </div>
      <div class="field personnel-form-action"><label aria-hidden="true">&nbsp;</label><button class="btn btn-primary"
          type="submit">افزودن کارمند</button></div>
    </div>
  </form>
</div>
<div class="card card-pad personnel-list-card">
  <form method="get" action="/personnel" class="personnel-toolbar" style="margin-top:0">
    <div class="search"><span class="search-icon">⌕</span><input id="personnelAdminSearch" name="q" class="control"
        type="search" value="<?= e($search ?? "") ?>" placeholder="جستجوی نام یا کد پرسنلی…" autocomplete="off"></div>
    <div class="actions"><button class="btn btn-secondary" type="submit">اعمال فیلتر</button></div>
  </form>
  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr>
          <th>کد پرسنلی</th>
          <th>نام و نام خانوادگی</th>
          <th>واحد</th>
          <th>وضعیت</th>
          <th>عملیات</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($personnel as $p): ?>
          <tr data-personnel-admin-row
            data-search="<?= e($p['personnel_code'] . ' ' . $p['full_name'] . ' ' . $p['division_name']) ?>">
            <td dir="ltr"><?= e(num($p['personnel_code'])) ?></td>
            <td><?= e($p['full_name']) ?></td>
            <td><?= e($p['division_name']) ?></td>
            <td><?php if ((int) $p['is_active'] === 1): ?><span class="status status-ok">فعال</span><?php else: ?><span
                  class="status status-lock">غیرفعال</span><?php endif; ?></td>
            <td>
              <?php if ((int) $p['division_id'] === (int) $ownDivisionId): ?>    <?php if ((int) $p['is_active'] === 1): ?><button
                    class="btn btn-danger btn-sm personnel-remove-btn" type="button" data-id="<?= e($p['id']) ?>"
                    data-name="<?= e($p['full_name']) ?>">حذف</button><?php else: ?>
                  <form method="post" action="/personnel/reactivate" style="display:inline"><input type="hidden"
                      name="csrf_token" value="<?= e(\App\Core\Csrf::token()) ?>"><input type="hidden" name="personnel_id"
                      value="<?= e($p['id']) ?>"><button class="btn btn-secondary btn-sm" type="submit">فعال‌سازی
                      مجدد</button></form><?php endif; ?><?php else: ?><span class="status status-lock">مجاز
                  نیست</span><?php endif; ?>
            </td>
          </tr><?php endforeach; ?>
        <?php if (!$personnel): ?>
          <tr>
            <td colspan="5" class="muted">هنوز کارمندی ثبت نشده است.</td>
          </tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php
  $currentPage = (int) ($personnelPage ?? 1);
  $totalPages = (int) ($personnelPages ?? 1);
  $personnelPageUrl = function (int $page) use ($search): string {
    $params = ['q' => $search ?? '', 'page' => $page];
    return '/personnel?' . http_build_query(array_filter($params, static fn($v) => $v !== ''));
  };
  ?>
  <div class="pagination" aria-label="صفحه‌بندی پرسنل">
    <a class="btn btn-secondary btn-sm pagination-btn <?= $currentPage > 1 ? '' : 'pagination-btn-hidden' ?>"
      href="<?= e($personnelPageUrl(max(1, $currentPage - 1))) ?>">قبلی</a>
    <span class="page-number">صفحه <?= e(num($currentPage)) ?> از <?= e(num($totalPages)) ?></span>
    <a class="btn btn-secondary btn-sm pagination-btn <?= $currentPage < $totalPages ? '' : 'pagination-btn-hidden' ?>"
      href="<?= e($personnelPageUrl(min($totalPages, $currentPage + 1))) ?>">بعدی</a>
  </div>
</div>
<div id="personnelRemoveDialog" class="dialog-backdrop hidden" role="dialog" aria-modal="true"
  aria-labelledby="personnelRemoveTitle">
  <div class="dialog">
    <h3 id="personnelRemoveTitle">حذف پرسنل</h3>
    <p id="personnelRemoveMessage">آیا می‌خواهید این پرسنل را حذف کنید؟</p>
    <form method="post" action="/personnel/delete" id="personnelRemoveForm">
      <input type="hidden" name="csrf_token" value="<?= e(\App\Core\Csrf::token()) ?>">
      <input type="hidden" name="personnel_id" id="personnelRemoveId" value="">
      <div class="dialog-actions personnel-remove-actions">
        <button type="submit" class="btn btn-delete-records" name="remove_mode" value="delete_logs">حذف کارمند و
          سوابق</button>
        <button type="submit" class="btn btn-keep-records" name="remove_mode" value="keep_logs">غیرفعال سازی و حفظ
          سوابق</button>
        <button type="button" class="btn btn-cancel" id="personnelRemoveCancel">انصراف</button>
      </div>
    </form>
  </div>
</div>