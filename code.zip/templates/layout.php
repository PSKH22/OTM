<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#F4EEE2">
  <meta name="csrf-token" content="<?= e(\App\Core\Csrf::token()) ?>">
  <title><?= e($title ?? t('app_name')) ?> · <?= e(t('app_name')) ?></title>
  <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
  <?php $currentPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/'; ?>
</head>
<body>
  <div id="app">
    <div class="shell">
      <header class="topbar">
        <div class="topbar-inner">
          <div class="brand" aria-label="پارس خودرو">پارس خودرو</div>
          <nav class="nav" aria-label="ناوبری">
            <a href="/overtime/new" class="<?= ($currentPath === '/overtime/new' || ($active ?? '') === 'submit') ? 'active' : '' ?>">ثبت اضافه‌کاری</a>
            <a href="/reports" class="<?= ($currentPath === '/reports' || ($active ?? '') === 'reports') ? 'active' : '' ?>">بررسی / گزارش‌ها</a>
            <a href="/personnel" class="<?= ($currentPath === '/personnel' || ($active ?? '') === 'personnel') ? 'active' : '' ?>">مدیریت پرسنل</a>
          </nav>
          <div class="userbar">
            <?php if (!empty($_SESSION['user'])): ?>
              <div class="user-meta">
                <div class="user-name"><?= e($_SESSION['user']['display_name']) ?></div>
                <div class="user-division"><?= e($_SESSION['user']['division_name']) ?></div>
              </div>
              <form method="post" action="/logout"><input type="hidden" name="csrf_token" value="<?= e(\App\Core\Csrf::token()) ?>">
                <button class="logout" title="خروج" type="submit">خروج</button>
              </form>
            <?php endif; ?>
          </div>
          <button type="button" class="theme-toggle" id="themeToggle" aria-label="حالت تاریک" title="حالت تاریک">
            <span class="theme-icon theme-icon-sun" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"></path></svg></span>
            <span class="theme-icon theme-icon-moon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M20.5 15.5A8.5 8.5 0 0 1 8.5 3.5 8.7 8.7 0 1 0 20.5 15.5Z"></path></svg></span>
            <span class="theme-switch-thumb" aria-hidden="true"></span>
          </button>
        </div>
      </header>
      <main class="main">
        <?php if (!empty($flash)): ?>
          <div class="flash"><?= e($flash) ?></div>
        <?php endif; ?>
        <?= $content ?>
      </main>
    </div>
  </div>
  <script src="<?= e(asset('js/app.js') . '?v=20261006-theme2') ?>" defer></script>
</body>
</html>
