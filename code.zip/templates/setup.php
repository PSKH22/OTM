<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>راه‌اندازی اولیه · مدیریت اضافه‌کاری</title>
  <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body>
  <button type="button" class="theme-toggle login-theme" id="themeToggle" aria-label="حالت تاریک" title="حالت تاریک">☾</button>
  <div class="login-page">
    <section class="card login-card" style="max-width:620px">
      <div class="login-brand">
        <div class="brand-text">پارس خودرو</div>
        <h1>راه‌اندازی اولیه</h1>
        <p>ایجاد حساب‌های مدیر از تنظیمات فایل <code>.env</code></p>
      </div>
      <?php if (!empty($error)): ?><div class="notice notice-warning"><?= e($error) ?></div><?php endif; ?>
      <?php if (empty($admins)): ?>
        <div class="notice notice-warning">هیچ حسابی با الگوی <code>ADMIN_1_*</code> در فایل <code>.env</code> پیدا نشد.</div>
      <?php else: ?>
        <div class="notice">پس از ایجاد اولین حساب، این صفحه به‌صورت خودکار قفل می‌شود و دیگر قابل استفاده نخواهد بود.</div>
        <div style="overflow:auto;margin:18px 0">
          <table class="data-table">
            <thead><tr><th>حساب</th><th>نام</th><th>واحد</th></tr></thead>
            <tbody>
            <?php foreach ($admins as $number => $admin): ?>
              <tr>
                <td><?= e($admin['username'] ?? '—') ?></td>
                <td><?= e($admin['display_name'] ?? '—') ?></td>
                <td><?= e($admin['division_id'] ?? '—') ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <form method="post" action="/setup">
          <input type="hidden" name="csrf_token" value="<?= e($csrf ?? '') ?>">
          <button class="btn btn-primary" type="submit">ایجاد حساب‌های مدیر</button>
        </form>
      <?php endif; ?>
      <div class="login-help">این صفحه فقط زمانی فعال است که هنوز هیچ کاربری در پایگاه داده وجود نداشته باشد.</div>
    </section>
  </div>
  <script src="<?= e(asset('js/app.js') . '?v=20261005-setup1') ?>"></script>
</body>
</html>
