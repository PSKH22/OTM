<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#F4EEE2">
  <title>خطای داخلی سرور</title>
  <link rel="stylesheet" href="/assets/css/app.css">
</head>
<body>
  <div id="app">
    <div class="shell">
      <main class="main">
        <section class="card card-pad">
          <h1>خطای داخلی سرور</h1>
          <p class="muted">در پردازش درخواست مشکلی پیش آمد. لطفاً دوباره تلاش کنید.</p>
          <a class="btn btn-primary" href="/">بازگشت به صفحه اصلی</a>
        </section>
      </main>
    </div>
  </div>
</body>
</html>
