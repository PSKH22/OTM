<!doctype html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>ورود · مدیریت اضافه‌کاری</title>
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>

<body><button type="button" class="theme-toggle login-theme" id="themeToggle" aria-label="حالت تاریک"
        title="حالت تاریک">
        <span class="theme-icon theme-icon-sun" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false">
                <circle cx="12" cy="12" r="4"></circle>
                <path
                    d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41">
                </path>
            </svg></span>
        <span class="theme-icon theme-icon-moon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false">
                <path d="M20.5 15.5A8.5 8.5 0 0 1 8.5 3.5 8.7 8.7 0 1 0 20.5 15.5Z"></path>
            </svg></span>
        <span class="theme-switch-thumb" aria-hidden="true"></span>
    </button>
    <div class="login-page">
        <section class="card login-card">
            <div class="login-brand">
                <h1 class="brand-text">مدیریت اضافه کاری</h1>
                <p>ورود به پنل مدیریت</p>
            </div><?php if (!empty($_GET['error'])): ?>
                <div class="notice notice-warning">نام کاربری یا گذرواژه نادرست است.</div><?php endif; ?>
            <form class="login-form" method="post" action="/login"><input type="hidden" name="csrf_token"
                    value="<?= e($csrf ?? '') ?>">
                <div class="field"><label>نام کاربری</label><input class="control" name="username"
                        autocomplete="username" required placeholder="نام کاربری"></div>
                <div class="field"><label>گذرواژه</label><input class="control" name="password" type="password"
                        autocomplete="current-password" required placeholder="گذرواژه"></div><button
                    class="btn btn-primary" type="submit">ورود</button>
            </form>
            <div class="login-help">دسترسی فقط برای کاربران مجاز سازمانی است.</div>
        </section>
    </div>
    <script src="<?= e(asset('js/app.js') . '?v=20261005-db1') ?>"></script>
</body>

</html>