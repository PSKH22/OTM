<?php
return [
    'name' => 'مدیریت اضافه‌کاری',
    'timezone' => $_ENV['APP_TIMEZONE'] ?? 'Asia/Tehran',
    'debug' => ($_ENV['APP_DEBUG'] ?? '0') === '1',
    'hours_cap' => (float)($_ENV['HOURS_CAP'] ?? 8),
    'submission_window_days' => (int)($_ENV['SUBMISSION_WINDOW_DAYS'] ?? 366),
    'report_page_size' => (int)($_ENV['REPORT_PAGE_SIZE'] ?? 50),
    'weekend_days' => [4, 5],
    'db' => [
        'host' => $_ENV['DB_HOST'] ?? '127.0.0.1',
        'port' => (int)($_ENV['DB_PORT'] ?? 3306),
        'name' => $_ENV['DB_NAME'] ?? '',
        'user' => $_ENV['DB_USER'] ?? '',
        'password' => $_ENV['DB_PASSWORD'] ?? '',
    ],
];
