<?php
namespace App\Repositories;
use App\Core\Database;
use PDO;

final class UserRepository
{
    public function findByUsername(string $username): ?array { $s=Database::connection()->prepare('SELECT u.*,d.name division_name FROM users u JOIN divisions d ON d.id=u.division_id WHERE u.username=:u LIMIT 1'); $s->execute(['u'=>$username]); return $s->fetch() ?: null; }
    public function countAll(): int { $s=Database::connection()->query('SELECT COUNT(*) FROM users'); return (int)$s->fetchColumn(); }
    public function find(int $id): ?array { $s=Database::connection()->prepare('SELECT u.*,d.name division_name FROM users u JOIN divisions d ON d.id=u.division_id WHERE u.id=:id LIMIT 1'); $s->execute(['id'=>$id]); return $s->fetch() ?: null; }
    public function touchLogin(int $id): void { $s=Database::connection()->prepare('UPDATE users SET last_login_at=UTC_TIMESTAMP() WHERE id=:id'); $s->execute(['id'=>$id]); }
    public function create(string $username,string $passwordHash,string $displayName,int $divisionId): int { $s=Database::connection()->prepare('INSERT INTO users(username,password_hash,display_name,division_id) VALUES(:u,:p,:n,:d)'); $s->execute(['u'=>$username,'p'=>$passwordHash,'n'=>$displayName,'d'=>$divisionId]); return (int)Database::connection()->lastInsertId(); }
}
