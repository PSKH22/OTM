<?php
namespace App\Repositories;
use PDO;

final class OvertimeRepository
{
    public function __construct(private PDO $pdo) {}
    public function usedPersonnel(int $cycleId,array $ids): array { if(!$ids)return[]; $ph=implode(',',array_fill(0,count($ids),'?')); $s=$this->pdo->prepare("SELECT personnel_id FROM overtime_entries WHERE cycle_id=? AND personnel_id IN ($ph)"); $s->execute(array_merge([$cycleId],$ids)); return array_map('intval',$s->fetchAll(PDO::FETCH_COLUMN)); }
    public function insert(array $r): int { $s=$this->pdo->prepare('INSERT INTO overtime_entries(personnel_id,division_id,overtime_type_id,overtime_date,hours,description,cycle_id,created_by) VALUES(:p,:d,:t,:date,:h,:desc,:c,:u)'); $s->execute($r); return (int)$this->pdo->lastInsertId(); }
    public function findForUpdate(int $id): ?array { $s=$this->pdo->prepare('SELECT e.*,p.personnel_code,p.full_name,d.name division_name,t.name type_name,t.code type_code,c.cycle_number FROM overtime_entries e JOIN personnel p ON p.id=e.personnel_id JOIN divisions d ON d.id=e.division_id JOIN overtime_types t ON t.id=e.overtime_type_id LEFT JOIN cycles c ON c.id=e.cycle_id WHERE e.id=:id FOR UPDATE'); $s->execute(['id'=>$id]); return $s->fetch() ?: null; }
    public function delete(int $id): void { $s=$this->pdo->prepare('DELETE FROM overtime_entries WHERE id=:id'); $s->execute(['id'=>$id]); }
    public function report(array $f): array
    {
        $where=[];$params=[];
        if($f['from']!==''){ $where[]='e.overtime_date >= :from';$params['from']=$f['from']; }
        if($f['to']!==''){ $where[]='e.overtime_date <= :to';$params['to']=$f['to']; }
        if($f['division_id']!==''){ $where[]='e.division_id = :division_id';$params['division_id']=(int)$f['division_id']; }
        if($f['type_id']!==''){ $where[]='e.overtime_type_id = :type_id';$params['type_id']=(int)$f['type_id']; }
        if($f['q']!==''){ $where[]="(LOCATE(:q_name, p.name_search) > 0 OR LOCATE(:q_code, p.personnel_code) > 0)";$q=$f['q'];$params['q_name']=$q;$params['q_code']=$q; }
        $sql='SELECT e.id,e.overtime_date,p.personnel_code,p.full_name,d.name division,e.division_id,t.id type_id,t.code type_code,t.name type,e.hours,c.cycle_number,e.description FROM overtime_entries e JOIN personnel p ON p.id=e.personnel_id JOIN divisions d ON d.id=e.division_id JOIN overtime_types t ON t.id=e.overtime_type_id LEFT JOIN cycles c ON c.id=e.cycle_id'.($where?' WHERE '.implode(' AND ',$where):'').' ORDER BY (e.division_id = :own_division_id) DESC,e.division_id ASC,e.overtime_date DESC,e.personnel_id ASC,e.id DESC';
        $countSql='SELECT COUNT(*),COALESCE(SUM(e.hours),0) FROM overtime_entries e JOIN personnel p ON p.id=e.personnel_id JOIN overtime_types t ON t.id=e.overtime_type_id'.($where?' WHERE '.implode(' AND ',$where):'');
        $c=$this->pdo->prepare($countSql);$c->execute($params);$summary=$c->fetch(PDO::FETCH_NUM);
        $limit=max(1,(int)($f['limit']??50));$offset=max(0,(int)($f['offset']??0));
        $params['own_division_id'] = (int)($f['own_division_id'] ?? 0);$sql.=' LIMIT :limit OFFSET :offset';$s=$this->pdo->prepare($sql);foreach($params as $k=>$v)$s->bindValue(':'.$k,$v);$s->bindValue(':limit',$limit,PDO::PARAM_INT);$s->bindValue(':offset',$offset,PDO::PARAM_INT);$s->execute();
        return ['rows'=>$s->fetchAll(),'total'=>(int)$summary[0],'total_hours'=>(float)$summary[1]];
    }
}
