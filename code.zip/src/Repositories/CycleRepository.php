<?php
namespace App\Repositories;
use PDO;

final class CycleRepository
{
    public function __construct(private PDO $pdo) {}
    public function openForUpdate(int $divisionId): ?array { $s=$this->pdo->prepare('SELECT id,division_id,cycle_number,started_at,closed_at FROM cycles WHERE division_id=:d AND closed_at IS NULL FOR UPDATE'); $s->execute(['d'=>$divisionId]); return $s->fetch() ?: null; }
    public function open(int $divisionId): ?array { $s=$this->pdo->prepare('SELECT id,division_id,cycle_number,started_at,closed_at FROM cycles WHERE division_id=:d AND closed_at IS NULL LIMIT 1'); $s->execute(['d'=>$divisionId]); return $s->fetch() ?: null; }
    public function summary(): array { $sql="SELECT d.id division_id,d.name,c.id cycle_id,c.cycle_number,(SELECT COUNT(*) FROM personnel p WHERE p.division_id=d.id AND p.is_active=1) total_active,(SELECT COUNT(DISTINCT e.personnel_id) FROM overtime_entries e JOIN personnel p2 ON p2.id=e.personnel_id WHERE e.cycle_id=c.id AND p2.division_id=d.id AND p2.is_active=1) done FROM divisions d JOIN cycles c ON c.division_id=d.id AND c.closed_at IS NULL ORDER BY d.id"; return $this->pdo->query($sql)->fetchAll(); }
    public function close(int $id): void { $s=$this->pdo->prepare('UPDATE cycles SET closed_at=UTC_TIMESTAMP() WHERE id=:id'); $s->execute(['id'=>$id]); }
    public function create(int $divisionId,int $number): int { $s=$this->pdo->prepare('INSERT INTO cycles(division_id,cycle_number) VALUES(:d,:n)'); $s->execute(['d'=>$divisionId,'n'=>$number]); return (int)$this->pdo->lastInsertId(); }
    public function latestClosed(int $divisionId): ?array { $s=$this->pdo->prepare('SELECT * FROM cycles WHERE division_id=:d AND closed_at IS NOT NULL ORDER BY cycle_number DESC LIMIT 1'); $s->execute(['d'=>$divisionId]); return $s->fetch() ?: null; }
    public function delete(int $id): void { $s=$this->pdo->prepare('DELETE FROM cycles WHERE id=:id'); $s->execute(['id'=>$id]); }
    public function reopen(int $id): void { $s=$this->pdo->prepare('UPDATE cycles SET closed_at=NULL WHERE id=:id'); $s->execute(['id'=>$id]); }
    public function entriesCount(int $cycleId): int { $s=$this->pdo->prepare('SELECT COUNT(*) FROM overtime_entries WHERE cycle_id=:c'); $s->execute(['c'=>$cycleId]); return (int)$s->fetchColumn(); }
    public function remainingActive(int $divisionId,int $cycleId): int { $s=$this->pdo->prepare('SELECT COUNT(*) FROM personnel p WHERE p.division_id=:d AND p.is_active=1 AND NOT EXISTS(SELECT 1 FROM overtime_entries e WHERE e.personnel_id=p.id AND e.cycle_id=:c)'); $s->execute(['d'=>$divisionId,'c'=>$cycleId]); return (int)$s->fetchColumn(); }
}
