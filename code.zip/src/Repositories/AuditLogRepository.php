<?php
namespace App\Repositories;
use PDO;
final class AuditLogRepository
{
    public function __construct(private PDO $pdo) {}
    public function add(int $userId,string $action,?int $entityId,array $details,?string $ip): void { $s=$this->pdo->prepare('INSERT INTO audit_log(user_id,action,entity_id,details,ip_address) VALUES(:u,:a,:e,:j,INET6_ATON(:ip))');$s->execute(['u'=>$userId,'a'=>$action,'e'=>$entityId,'j'=>json_encode($details,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),'ip'=>$ip]); }
}
