<?php
namespace App\Repositories;
use App\Core\Database;
final class LoginAttemptRepository
{
    public function record(string $username,string $ip,bool $success): void { $s=Database::connection()->prepare('INSERT INTO login_attempts(username,ip_address,was_successful) VALUES(:u,INET6_ATON(:ip),:ok)'); $s->execute(['u'=>$username,'ip'=>$ip,'ok'=>$success?1:0]); }
    public function recentFailures(string $username,string $ip,int $minutes=15): int { $minutes=max(1,min(1440,$minutes)); $s=Database::connection()->prepare("SELECT COUNT(*) FROM login_attempts WHERE username=:u AND ip_address=INET6_ATON(:ip) AND was_successful=0 AND attempted_at >= UTC_TIMESTAMP() - INTERVAL {$minutes} MINUTE"); $s->execute(['u'=>$username,'ip'=>$ip]); return (int)$s->fetchColumn(); }
    public function recentFailuresByIp(string $ip,int $minutes=15): int { $minutes=max(1,min(1440,$minutes)); $s=Database::connection()->prepare("SELECT COUNT(*) FROM login_attempts WHERE ip_address=INET6_ATON(:ip) AND was_successful=0 AND attempted_at >= UTC_TIMESTAMP() - INTERVAL {$minutes} MINUTE"); $s->execute(['ip'=>$ip]); return (int)$s->fetchColumn(); }
}
