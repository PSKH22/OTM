<?php
namespace App\Repositories;
use App\Core\Database;

final class LookupRepository
{
    public function divisions(): array { return Database::connection()->query('SELECT id,name FROM divisions ORDER BY id')->fetchAll(); }
    public function overtimeTypes(): array { return Database::connection()->query('SELECT id,code,name,uses_cycle,day_rule,sort_order FROM overtime_types ORDER BY sort_order,id')->fetchAll(); }
}
