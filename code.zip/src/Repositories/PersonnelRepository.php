<?php
namespace App\Repositories;
use App\Core\Database;
use App\Repositories\AuditLogRepository;
use App\Support\TextNormalizer;

final class PersonnelRepository
{
    public function all(string $q = '', int $ownDivisionId = 0, int $limit = 10, int $offset = 0): array
    {
        $where = [];
        $params = [];
        if ($q !== '') {
            $where[] = '(LOCATE(:q_name, p.name_search) > 0 OR LOCATE(:q_code, p.personnel_code) > 0)';
            $params['q_name'] = $q;
            $params['q_code'] = $q;
        }
        $orderOwn = max(0, $ownDivisionId);
        $limit = max(1, min(100, $limit));
        $offset = max(0, $offset);
        $whereSql = $where ? ' WHERE '.implode(' AND ', $where) : '';
        $pdo = Database::connection();
        $count = $pdo->prepare("SELECT COUNT(*) FROM personnel p JOIN divisions d ON d.id=p.division_id{$whereSql}");
        $count->execute($params);
        $total = (int)$count->fetchColumn();
        $sql = "SELECT p.id,p.personnel_code,p.full_name,p.division_id,d.name division_name,p.is_active,p.created_at
                FROM personnel p JOIN divisions d ON d.id=p.division_id{$whereSql}
                ORDER BY (p.division_id = {$orderOwn}) DESC,p.division_id ASC,p.id ASC
                LIMIT :limit OFFSET :offset";
        $s = $pdo->prepare($sql);
        foreach ($params as $key => $value) $s->bindValue(':'.$key, $value);
        $s->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $s->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $s->execute();
        return ['rows'=>$s->fetchAll(),'total'=>$total];
    }

    public function activeWithCycleStatus(string $q = '', int $ownDivisionId = 0, int $limit = 10, int $offset = 0): array
    {
        $where = ['p.is_active=1'];
        $params = [];
        if ($q !== '') {
            $where[] = '(LOCATE(:q_name, p.name_search) > 0 OR LOCATE(:q_code, p.personnel_code) > 0)';
            $params['q_name'] = $q;
            $params['q_code'] = $q;
        }
        $orderOwn = max(0, $ownDivisionId);
        $limit = max(1, min(100, $limit));
        $offset = max(0, $offset);
        $whereSql = implode(' AND ', $where);
        $pdo = Database::connection();
        $count = $pdo->prepare("SELECT COUNT(*) FROM personnel p JOIN divisions d ON d.id=p.division_id WHERE {$whereSql}");
        $count->execute($params);
        $total = (int)$count->fetchColumn();
        $sql = "SELECT p.id,p.personnel_code,p.full_name,p.division_id,d.name division_name,
                EXISTS(SELECT 1 FROM overtime_entries e JOIN cycles c ON c.id=e.cycle_id AND c.closed_at IS NULL WHERE e.personnel_id=p.id AND c.division_id=p.division_id) used_in_open_cycle
                FROM personnel p JOIN divisions d ON d.id=p.division_id
                WHERE {$whereSql}
                ORDER BY (p.division_id = {$orderOwn}) DESC,p.division_id ASC,p.id ASC
                LIMIT :limit OFFSET :offset";
        $s = $pdo->prepare($sql);
        foreach ($params as $key => $value) $s->bindValue(':'.$key, $value);
        $s->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $s->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $s->execute();
        return ['rows'=>$s->fetchAll(),'total'=>$total];
    }

    public function findActiveByIds(array $ids): array
    {
        if (!$ids) return [];
        $ids=array_values(array_unique(array_map('intval',$ids))); $ph=implode(',',array_fill(0,count($ids),'?'));
        $s=Database::connection()->prepare("SELECT id,personnel_code,full_name,division_id,is_active FROM personnel WHERE id IN ($ph) AND is_active=1");
        $s->execute($ids); return $s->fetchAll();
    }

    public function create(string $code,string $name,int $divisionId): int
    {
        $s=Database::connection()->prepare('INSERT INTO personnel(personnel_code,full_name,name_search,division_id) VALUES(:c,:n,:s,:d)');
        $s->execute(['c'=>$code,'n'=>$name,'s'=>TextNormalizer::normalize($name),'d'=>$divisionId]); return (int)Database::connection()->lastInsertId();
    }
    public function reactivate(int $id, int $divisionId, int $userId, ?string $ip): void
    {
        Database::transaction(function ($pdo) use ($id, $divisionId, $userId, $ip): void {
            $s = $pdo->prepare('SELECT id,personnel_code,full_name,name_search,division_id,is_active,created_at,updated_at FROM personnel WHERE id=:id AND division_id=:division_id FOR UPDATE');
            $s->execute(['id' => $id, 'division_id' => $divisionId]);
            $person = $s->fetch();
            if (!$person) {
                throw new \RuntimeException('not_found');
            }
            if ((int)$person['is_active'] === 1) {
                return;
            }
            $update = $pdo->prepare('UPDATE personnel SET is_active=1 WHERE id=:id');
            $update->execute(['id' => $id]);
            (new AuditLogRepository($pdo))->add($userId, 'personnel_reactivated', $id, ['personnel' => $person], $ip);
        });
    }

    public function remove(int $id, int $divisionId, string $mode, int $userId, ?string $ip): void
    {
        if (!in_array($mode, ['keep_logs', 'delete_logs'], true)) {
            throw new \RuntimeException('invalid_remove_mode');
        }

        Database::transaction(function ($pdo) use ($id, $divisionId, $mode, $userId, $ip): void {
            $s = $pdo->prepare('SELECT p.id,p.personnel_code,p.full_name,p.name_search,p.division_id,p.is_active,p.created_at,p.updated_at,d.name division_name FROM personnel p JOIN divisions d ON d.id=p.division_id WHERE p.id=:id AND p.division_id=:division_id FOR UPDATE');
            $s->execute(['id' => $id, 'division_id' => $divisionId]);
            $person = $s->fetch();
            if (!$person) {
                throw new \RuntimeException('not_found');
            }

            $entryStmt = $pdo->prepare('SELECT e.id,e.personnel_id,e.division_id,e.overtime_type_id,e.overtime_date,e.hours,e.description,e.cycle_id,e.created_by,e.created_at FROM overtime_entries e WHERE e.personnel_id=:id ORDER BY e.id');
            $entryStmt->execute(['id' => $id]);
            $entries = $entryStmt->fetchAll();

            $audit = new AuditLogRepository($pdo);
            $details = [
                'mode' => $mode,
                'personnel' => $person,
                'overtime_entries' => $entries,
            ];

            if ($mode === 'keep_logs') {
                $update = $pdo->prepare('UPDATE personnel SET is_active=0 WHERE id=:id');
                $update->execute(['id' => $id]);
                $audit->add($userId, 'personnel_deactivated', $id, $details, $ip);
                return;
            }

            if ($entries) {
                $deleteEntries = $pdo->prepare('DELETE FROM overtime_entries WHERE personnel_id=:id');
                $deleteEntries->execute(['id' => $id]);
            }
            $deletePerson = $pdo->prepare('DELETE FROM personnel WHERE id=:id');
            $deletePerson->execute(['id' => $id]);
            $audit->add($userId, 'personnel_deleted', $id, $details, $ip);
        });
    }

}
