<?php
namespace App\Http\Controllers;
use App\Core\Request;
use App\Core\View;
use App\Repositories\AuditLogRepository;
use App\Repositories\CycleRepository;
use App\Repositories\LookupRepository;
use App\Repositories\OvertimeRepository;
use App\Repositories\PersonnelRepository;
use App\Services\CycleService;
use App\Services\OvertimeService;
use App\Support\JalaliDate;
use App\Core\Database;
use RuntimeException;

final class OvertimeController
{
    private function service(): OvertimeService { $pdo=Database::connection();return new OvertimeService(new OvertimeRepository($pdo),new PersonnelRepository(),new LookupRepository(),new CycleRepository($pdo),new AuditLogRepository($pdo),new CycleService($pdo,new CycleRepository($pdo))); }
    public function create(Request $request): string
    {
        $user=$_SESSION['user'];$lookups=new LookupRepository();$q=\App\Support\TextNormalizer::normalize((string)$request->input('q',''));$page=max(1,(int)$request->input('page',1));$limit=10;$personnelResult=(new PersonnelRepository())->activeWithCycleStatus($q,(int)$user['division_id'],$limit,($page-1)*$limit);$personnel=$personnelResult['rows'];$totalPersonnel=(int)$personnelResult['total'];$totalPersonnelPages=max(1,(int)ceil($totalPersonnel/$limit));if($page>$totalPersonnelPages){$page=$totalPersonnelPages;$personnelResult=(new PersonnelRepository())->activeWithCycleStatus($q,(int)$user['division_id'],$limit,($page-1)*$limit);$personnel=$personnelResult['rows'];}$cycles=(new CycleRepository(Database::connection()))->summary();
        return View::render('overtime/new',['title'=>'ثبت اضافه‌کاری','user'=>$user,'divisions'=>$lookups->divisions(),'types'=>$lookups->overtimeTypes(),'personnel'=>$personnel,'cycles'=>$cycles,'today'=>JalaliDate::today(),'search'=>$q,'personnelPage'=>$page,'personnelPages'=>$totalPersonnelPages,'personnelTotal'=>$totalPersonnel,'form_nonce'=>\App\Core\Csrf::formNonce()]);
    }
    public function store(Request $request): string
    {
        $user=$_SESSION['user'];
        if (!\App\Core\Csrf::check($request->input('csrf_token'))) {
            http_response_code(419);
            return $this->create($request);
        }
        if (!\App\Core\Csrf::consumeFormNonce($request->input('form_nonce'))) {
            http_response_code(422);
            return $this->create($request);
        }
        $type=(int)$request->input('type_id',$request->input('type',0));$ids=(array)$request->input('personnel_ids',[]);$date=(string)$request->input('date','');$hours=(float)str_replace(['٫','،',','],'.',(string)$request->input('hours','0'));
        try{$this->service()->submitBatch($user,$type,$date,$hours,trim((string)$request->input('description','')),$ids,$_SERVER['REMOTE_ADDR']??null);header('Location: /overtime/new?success=1');exit;}catch(RuntimeException $e){http_response_code(422);return $this->create($request);} }
    public function delete(Request $request): never {
        if (!\App\Core\Csrf::check($request->input('csrf_token',''))) { http_response_code(419); echo 'توکن امنیتی نامعتبر است.'; exit; }
        try {
            $this->service()->delete($_SESSION['user'],(int)$request->input('entry_id'),$_SERVER['REMOTE_ADDR']??null);
            header('Location: '.(str_starts_with((string)$request->input('back',''),'/reports')?$request->input('back'):'/reports'));
        } catch (\RuntimeException $e) {
            http_response_code($e->getMessage()==='forbidden_division'?403:422);
            echo $e->getMessage()==='not_found' ? 'رکورد موردنظر پیدا نشد.' : 'حذف رکورد انجام نشد.';
        }
        exit;
    }
}
