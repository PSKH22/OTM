<?php
namespace App\Http\Controllers;
use App\Core\Database;
use App\Core\Request;
use App\Core\View;
use App\Repositories\LookupRepository;
use App\Repositories\OvertimeRepository;
use App\Services\ReportService;
use App\Support\JalaliDate;

final class ReportController
{
    private function service(): ReportService { return new ReportService(new OvertimeRepository(Database::connection())); }
    public function index(Request $request): string
    {
        [$defaultFrom, $defaultTo] = JalaliDate::currentYearRange();
        $input=['from'=>$request->input('from',$defaultFrom),'to'=>$request->input('to',$defaultTo),'division_id'=>$request->input('division_id',''),'type_id'=>$request->input('type_id',''),'q'=>$request->input('q',''),'own_division_id'=>(int)$_SESSION['user']['division_id'],'page'=>$request->input('page',1),'limit'=>10];
        try{$result=$this->service()->query($input);}catch(\Throwable $e){$result=['rows'=>[],'total'=>0,'total_hours'=>0,'page'=>1,'limit'=>10,'pages'=>1];}
        return View::render('reports/index',['title'=>'گزارش‌ها','divisions'=>(new LookupRepository())->divisions(),'types'=>(new LookupRepository())->overtimeTypes(),'entries'=>$result['rows'],'total_hours'=>number_format($result['total_hours'],1,'.',''),'filters'=>['from'=>$input['from'],'to'=>$input['to'],'division_id'=>$input['division_id'],'type_id'=>$input['type_id'],'q'=>$input['q']],'summary'=>$result]);
    }
}
