<?php
namespace App\Http\Controllers;
use App\Core\Csrf;
use App\Core\Request;
use App\Core\Response;
use App\Core\View;
use App\Repositories\LoginAttemptRepository;
use App\Repositories\UserRepository;
use App\Services\AuthService;
use RuntimeException;

final class AuthController
{
    private function service(): AuthService { return new AuthService(new UserRepository(),new LoginAttemptRepository()); }
    public function showLogin(Request $request): string { if(!empty($_SESSION['user']))Response::redirect('/overtime/new'); return View::render('login',['title'=>'ورود','error'=>null,'csrf'=>Csrf::token()],false); }
    public function login(Request $request): never
    {
        if(!Csrf::check($request->input('csrf_token')))Response::json(['error'=>'csrf'],419);
        try{$user=$this->service()->authenticate((string)$request->input('username',''),(string)$request->input('password',''),$_SERVER['REMOTE_ADDR']??'0.0.0.0');}catch(RuntimeException $e){if($e->getMessage()==='throttle')Response::json(['error'=>'throttle'],429);throw $e;}
        if(!$user){ Response::redirect('/login?error=1'); }
        session_regenerate_id(true);$_SESSION['user']=$user;Response::redirect('/overtime/new');
    }
    public function logout(Request $request): never { if(!Csrf::check($request->input('csrf_token')))Response::json(['error'=>'csrf'],419);$_SESSION=[];session_destroy();Response::redirect('/login'); }
}
