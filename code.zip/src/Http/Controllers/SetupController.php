<?php
namespace App\Http\Controllers;

use App\Core\Csrf;
use App\Core\Database;
use App\Core\Response;
use App\Core\View;
use App\Repositories\UserRepository;
use App\Support\PasswordHasher;
use PDOException;

final class SetupController
{
    public function show(): string
    {
        if ((new UserRepository())->countAll() > 0) {
            Response::redirect('/login');
        }

        return View::render('setup', [
            'title' => 'راه‌اندازی اولیه',
            'csrf' => Csrf::token(),
            'admins' => $this->configuredAdmins(),
        ], false);
    }

    public function store(): string
    {
        if ((new UserRepository())->countAll() > 0) {
            Response::redirect('/login');
        }

        if (!Csrf::check((string)($_POST['csrf_token'] ?? ''))) {
            http_response_code(419);
            return View::render('setup', [
                'title' => 'راه‌اندازی اولیه',
                'csrf' => Csrf::token(),
                'admins' => $this->configuredAdmins(),
                'error' => 'توکن امنیتی نامعتبر است. صفحه را دوباره بارگذاری کنید.',
            ], false);
        }

        $admins = $this->configuredAdmins();
        if (!$admins) {
            return View::render('setup', [
                'title' => 'راه‌اندازی اولیه',
                'csrf' => Csrf::token(),
                'admins' => [],
                'error' => 'هیچ حساب مدیری در فایل .env پیکربندی نشده است.',
            ], false);
        }

        $pdo = Database::connection();
        $users = new UserRepository();
        $errors = [];
        $created = 0;

        foreach ($admins as $number => $admin) {
            try {
                $this->validateAdmin($admin, $number, $pdo);
                if ($users->findByUsername($admin['username'])) {
                    continue;
                }
                $users->create(
                    $admin['username'],
                    PasswordHasher::hash($admin['password']),
                    $admin['display_name'],
                    $admin['division_id']
                );
                $created++;
            } catch (PDOException $e) {
                if ((int)($e->errorInfo[1] ?? 0) === 1062) {
                    continue;
                }
                $errors[] = "حساب شماره {$number}: خطای پایگاه داده هنگام ایجاد حساب.";
            } catch (\InvalidArgumentException $e) {
                $errors[] = "حساب شماره {$number}: {$e->getMessage()}";
            }
        }

        if ($errors) {
            return View::render('setup', [
                'title' => 'راه‌اندازی اولیه',
                'csrf' => Csrf::token(),
                'admins' => $admins,
                'error' => implode(' ', $errors),
            ], false);
        }

        if ($users->countAll() === 0) {
            return View::render('setup', [
                'title' => 'راه‌اندازی اولیه',
                'csrf' => Csrf::token(),
                'admins' => $admins,
                'error' => 'هیچ حساب مدیری ایجاد نشد. تنظیمات ADMIN_n_* در فایل .env را بررسی کنید.',
            ], false);
        }

        Response::redirect('/login?setup=complete&created=' . $created);
    }

    private function configuredAdmins(): array
    {
        $admins = [];
        foreach ($_ENV as $key => $value) {
            if (preg_match('/^ADMIN_(\d+)_USERNAME$/', $key, $m)) {
                $n = (int)$m[1];
                $admins[$n] = [
                    'username' => $this->env("ADMIN_{$n}_USERNAME"),
                    'password' => $this->env("ADMIN_{$n}_PASSWORD"),
                    'display_name' => $this->env("ADMIN_{$n}_DISPLAY_NAME"),
                    'division_id' => $this->env("ADMIN_{$n}_DIVISION_ID"),
                ];
            }
        }
        ksort($admins);
        return $admins;
    }

    private function env(string $key): ?string
    {
        $value = $_ENV[$key] ?? null;
        if ($value === null) return null;
        $value = trim((string)$value);
        return $value === '' ? null : $value;
    }

    private function validateAdmin(array $admin, int $number, \PDO $pdo): void
    {
        foreach (['username', 'password', 'display_name', 'division_id'] as $field) {
            if (empty($admin[$field])) {
                throw new \InvalidArgumentException("فیلد {$field} در تنظیمات .env وجود ندارد.");
            }
        }
        if (strlen($admin['username']) > 64 || !preg_match('/^[A-Za-z0-9._@-]+$/', $admin['username'])) {
            throw new \InvalidArgumentException('نام کاربری نامعتبر است.');
        }
        if (strlen($admin['password']) < 12) {
            throw new \InvalidArgumentException('گذرواژه باید حداقل ۱۲ کاراکتر باشد.');
        }
        if (!ctype_digit($admin['division_id']) || (int)$admin['division_id'] < 1) {
            throw new \InvalidArgumentException('شناسه واحد نامعتبر است.');
        }
        $s = $pdo->prepare('SELECT id FROM divisions WHERE id=:id LIMIT 1');
        $s->execute(['id' => (int)$admin['division_id']]);
        if (!$s->fetchColumn()) {
            throw new \InvalidArgumentException("واحد شماره {$admin['division_id']} در پایگاه داده وجود ندارد. شناسه واحد را در تنظیمات ADMIN_n_DIVISION_ID بررسی کنید.");
        }
    }
}
