<?php
function e(mixed $value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function asset(string $path): string { return '/assets/' . ltrim($path, '/'); }
function num(mixed $value): string { return strtr((string)$value, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']); }
function t(string $key): string { static $lang; $lang ??= require dirname(__DIR__) . '/lang/fa.php'; return $lang[$key] ?? $key; }
