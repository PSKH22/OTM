<?php
namespace App\Support;

final class PasswordHasher
{
    private const ARGON2ID_OPTIONS = [
        'memory_cost' => 19456,
        'time_cost' => 2,
        'threads' => 1,
    ];

    public static function hash(string $password): string
    {
        if (defined('PASSWORD_ARGON2ID')) {
            return password_hash($password, PASSWORD_ARGON2ID, self::ARGON2ID_OPTIONS);
        }

        return password_hash($password, PASSWORD_DEFAULT);
    }

    public static function needsRehash(string $hash): bool
    {
        if (defined('PASSWORD_ARGON2ID')) {
            return password_needs_rehash($hash, PASSWORD_ARGON2ID, self::ARGON2ID_OPTIONS);
        }

        return password_needs_rehash($hash, PASSWORD_DEFAULT);
    }
}
