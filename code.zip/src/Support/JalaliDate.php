<?php
namespace App\Support;

use DateTimeImmutable;
use DateTimeZone;
use IntlCalendar;
use RuntimeException;

final class JalaliDate
{
    private static function requireIntl(): void
    {
        if (!class_exists(IntlCalendar::class)) throw new RuntimeException('PHP intl extension is required for Solar Hijri date handling.');
    }

    public static function parse(string $value): array
    {
        $value = TextNormalizer::normalize($value);
        if (!preg_match('/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})$/', $value, $m)) throw new RuntimeException('Invalid Jalali date.');
        $y=(int)$m[1]; $mo=(int)$m[2]; $d=(int)$m[3];
        if ($mo<1 || $mo>12 || $d<1 || $d>31) throw new RuntimeException('Invalid Jalali date.');
        return [$y,$mo,$d];
    }

    public static function toGregorianDate(string $jalali): string
    {
        self::requireIntl();
        [$y,$m,$d]=self::parse($jalali);
        $cal=IntlCalendar::createInstance(new DateTimeZone('UTC'), 'fa_IR@calendar=persian');
        $cal->setLenient(false); $cal->set($y,$m-1,$d,0,0,0);
        $time=$cal->getTime();
        if ($time === false) throw new RuntimeException('Invalid Jalali date.');
        return gmdate('Y-m-d', (int)round($time/1000));
    }

    public static function fromGregorian(string $gregorian): string
    {
        self::requireIntl();
        $dt=new DateTimeImmutable($gregorian.' 00:00:00', new DateTimeZone('UTC'));
        $cal=IntlCalendar::createInstance(new DateTimeZone('UTC'), 'fa_IR@calendar=persian');
        $cal->setTime($dt->getTimestamp()*1000);
        return sprintf('%04d/%02d/%02d',$cal->get(IntlCalendar::FIELD_YEAR),$cal->get(IntlCalendar::FIELD_MONTH)+1,$cal->get(IntlCalendar::FIELD_DAY_OF_MONTH));
    }

    public static function weekday(string $jalali): int
    {
        $g=self::toGregorianDate($jalali);
        return (int)(new DateTimeImmutable($g.' 00:00:00', new DateTimeZone('UTC')))->format('w');
    }

    public static function today(): string
    {
        return self::fromGregorian((new DateTimeImmutable('now', new DateTimeZone('Asia/Tehran')))->format('Y-m-d'));
    }

    public static function currentYearRange(): array
    {
        [$year] = self::parse(self::today());
        $from = sprintf('%04d/01/01', $year);
        $to = sprintf('%04d/12/30', $year);
        try {
            self::toGregorianDate($to);
        } catch (RuntimeException) {
            $to = sprintf('%04d/12/29', $year);
        }
        return [$from, $to];
    }
}
