<?php
namespace App\Support;

final class TextNormalizer
{
    public static function normalize(string $value): string
    {
        $value = strtr($value, ['ي'=>'ی','ى'=>'ی','ك'=>'ک']);
        $value = strtr($value, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
        $value = preg_replace('/[\x{0640}\x{064B}-\x{065F}\x{0670}\x{200C}]/u', '', $value) ?? $value;
        $value = preg_replace('/\s+/u', ' ', trim($value)) ?? trim($value);
        return mb_strtolower($value, 'UTF-8');
    }
}
