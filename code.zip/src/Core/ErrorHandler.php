<?php
namespace App\Core;

use Throwable;

final class ErrorHandler
{
    public static function register(string $root): void
    {
        set_exception_handler(function (Throwable $e) use ($root): void {
            self::log($root, $e);
            self::respond($e);
        });
        set_error_handler(function (int $severity, string $message, string $file, int $line): bool {
            if (!(error_reporting() & $severity)) return false;
            throw new \ErrorException($message, 0, $severity, $file, $line);
        });
    }

    public static function log(string $root, Throwable $e): void
    {
        $dir = $root . '/storage/logs';
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        $entry = [
            'timestamp' => date(DATE_ATOM),
            'level' => 'ERROR',
            'exception' => get_class($e),
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'request' => [
                'method' => $_SERVER['REQUEST_METHOD'] ?? null,
                'uri' => $_SERVER['REQUEST_URI'] ?? null,
                'ip' => $_SERVER['REMOTE_ADDR'] ?? null,
            ],
            'user_id' => isset($_SESSION['user']['id']) ? (int)$_SESSION['user']['id'] : null,
        ];
        // Never include request bodies, passwords, tokens, or submitted form data.
        @file_put_contents($dir . '/app.log', json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }

    private static function respond(Throwable $e): void
    {
        http_response_code(500);
        $root = dirname(__DIR__, 2);
        $template = $root . '/templates/errors/500.php';
        if (is_file($template)) {
            require $template;
            return;
        }
        echo 'خطای داخلی سرور.';
    }
}
