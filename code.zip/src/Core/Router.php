<?php
namespace App\Core;

final class Router
{
    private array $routes = [];
    public function get(string $path, callable $handler): void { $this->routes['GET'][$path] = $handler; }
    public function post(string $path, callable $handler): void { $this->routes['POST'][$path] = $handler; }
    public function dispatch(Request $request): mixed
    {
        $handler = $this->routes[$request->method][$request->path] ?? null;
        if (!$handler) { http_response_code(404); return View::render('errors/404', ['title' => 'یافت نشد']); }
        return $handler($request);
    }
}
