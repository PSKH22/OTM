<?php
namespace App\Core;

final class View
{
    public static function render(string $template, array $data = [], bool $layout = true): string
    {
        $file = dirname(__DIR__, 2) . '/templates/' . $template . '.php';
        if (!is_file($file)) throw new \RuntimeException("Template not found: {$template}");
        extract($data, EXTR_SKIP);
        ob_start(); require $file; $content = ob_get_clean();
        if (!$layout) return $content;
        ob_start(); require dirname(__DIR__, 2) . '/templates/layout.php'; return ob_get_clean();
    }
}
