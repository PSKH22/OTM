<?php
namespace App\Core;

use PDO;

/**
 * Creates the small set of reference records required by the application.
 * This is intentionally idempotent: existing records are never overwritten.
 */
final class ReferenceData
{
    public static function ensure(PDO $pdo): void
    {
        $pdo->exec("INSERT INTO divisions (name)
            SELECT 'پشتیبانی سخت‌افزار' FROM DUAL
            WHERE NOT EXISTS (SELECT 1 FROM divisions WHERE name = 'پشتیبانی سخت‌افزار')");
        $pdo->exec("INSERT INTO divisions (name)
            SELECT 'شبکه و زیرساخت' FROM DUAL
            WHERE NOT EXISTS (SELECT 1 FROM divisions WHERE name = 'شبکه و زیرساخت')");
        $pdo->exec("INSERT INTO divisions (name)
            SELECT 'پایگاه داده و امنیت اطلاعات' FROM DUAL
            WHERE NOT EXISTS (SELECT 1 FROM divisions WHERE name = 'پایگاه داده و امنیت اطلاعات')");

        $types = [
            ['weekdays', 'روزهای کاری', 1, 'workday', 1],
            ['weekend', 'آخر هفته', 0, 'weekend', 2],
            ['out_of_quota', 'خارج از سهمیه', 0, 'any', 3],
        ];

        $stmt = $pdo->prepare(
            'INSERT INTO overtime_types (code, name, uses_cycle, day_rule, sort_order)
             SELECT :code, :name, :uses_cycle, :day_rule, :sort_order FROM DUAL
             WHERE NOT EXISTS (SELECT 1 FROM overtime_types WHERE code = :code_check)'
        );
        foreach ($types as [$code, $name, $usesCycle, $dayRule, $sortOrder]) {
            $stmt->execute([
                'code' => $code,
                'name' => $name,
                'uses_cycle' => $usesCycle,
                'day_rule' => $dayRule,
                'sort_order' => $sortOrder,
                'code_check' => $code,
            ]);
        }

        // Keep existing reference rows aligned with the application's canonical
        // rules too. Older installations may already contain these codes with
        // stale uses_cycle/day_rule values.
        $update = $pdo->prepare(
            'UPDATE overtime_types
             SET name = :name, uses_cycle = :uses_cycle, day_rule = :day_rule, sort_order = :sort_order
             WHERE code = :code'
        );
        foreach ($types as [$code, $name, $usesCycle, $dayRule, $sortOrder]) {
            $update->execute([
                'code' => $code,
                'name' => $name,
                'uses_cycle' => $usesCycle,
                'day_rule' => $dayRule,
                'sort_order' => $sortOrder,
            ]);
        }

        // Every division starts with cycle 1. Existing cycles are preserved.
        $pdo->exec(
            'INSERT INTO cycles (division_id, cycle_number)
             SELECT d.id, 1
             FROM divisions d
             WHERE NOT EXISTS (
                 SELECT 1 FROM cycles c
                 WHERE c.division_id = d.id AND c.cycle_number = 1
             )'
        );
    }
}
