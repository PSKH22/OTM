<?php
namespace App\Core;

final class Config
{
    private static array $items = [];
    public static function load(string $root): void
    {
        $envFile = $root . '/.env';
        $env = is_file($envFile) ? parse_ini_file($envFile, false, INI_SCANNER_RAW) : [];
        foreach ($env as $key => $value) $_ENV[$key] = $value;
        self::$items['app'] = require $root . '/config/app.php';
    }
    public static function get(string $key, mixed $default = null): mixed
    {
        $value = self::$items;
        foreach (explode('.', $key) as $part) {
            if (!is_array($value) || !array_key_exists($part, $value)) return $default;
            $value = $value[$part];
        }
        return $value;
    }
}
