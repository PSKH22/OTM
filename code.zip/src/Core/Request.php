<?php
namespace App\Core;
final class Request
{
    public function __construct(public readonly string $method, public readonly string $path, public readonly array $query=[], public readonly array $body=[]) {}
    public static function capture(): self
    {
        $path=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/';$body=$_POST;
        $contentType=$_SERVER['CONTENT_TYPE']??'';
        if(str_contains(strtolower($contentType),'application/json')){ $raw=file_get_contents('php://input');$decoded=json_decode($raw?:'[]',true);if(is_array($decoded))$body=$decoded; }
        return new self($_SERVER['REQUEST_METHOD']??'GET',$path,$_GET,$body);
    }
    public function input(string $key,mixed $default=null): mixed{return $this->body[$key]??$this->query[$key]??$default;}
}
