<?php
namespace App\Core;
final class Csrf
{
    public static function token(): string { if(empty($_SESSION['_csrf']))$_SESSION['_csrf']=bin2hex(random_bytes(32)); return $_SESSION['_csrf']; }
    public static function check(?string $token): bool { return is_string($token)&&hash_equals(self::token(),$token); }
    public static function formNonce(): string { return $_SESSION['_overtime_form_nonce'] ??= bin2hex(random_bytes(32)); }
    public static function consumeFormNonce(?string $nonce): bool {
        $expected = $_SESSION['_overtime_form_nonce'] ?? null;
        unset($_SESSION['_overtime_form_nonce']);
        return is_string($nonce) && is_string($expected) && hash_equals($expected, $nonce);
    }
}
