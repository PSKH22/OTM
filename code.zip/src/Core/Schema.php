<?php
namespace App\Core;

use PDO;
use RuntimeException;

final class Schema
{
    private const TABLES = [
        'divisions',
        'overtime_types',
        'users',
        'login_attempts',
        'personnel',
        'cycles',
        'overtime_entries',
        'audit_log',
    ];

    private static bool $initialized = false;

    public static function ensure(PDO $pdo): void
    {
        if (self::$initialized) return;

        $placeholders = implode(',', array_fill(0, count(self::TABLES), '?'));
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name IN (' . $placeholders . ')'
        );
        $stmt->execute(self::TABLES);
        $existing = (int)$stmt->fetchColumn();

        if ($existing < count(self::TABLES)) {
            $root = dirname(__DIR__, 2);
            $file = $root . '/database/schema.sql';
            if (!is_file($file)) {
                throw new RuntimeException('Database schema file not found: ' . $file);
            }

            $sql = file_get_contents($file);
            if ($sql === false || trim($sql) === '') {
                throw new RuntimeException('Database schema file is empty or unreadable.');
            }

            // schema.sql is idempotent (CREATE TABLE IF NOT EXISTS), so missing
            // tables can be added without changing tables that already exist.
            $pdo->exec($sql);
        }

        self::$initialized = true;
    }
}
