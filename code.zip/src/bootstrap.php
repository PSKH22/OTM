<?php
use App\Core\Config;

$root = dirname(__DIR__);
spl_autoload_register(function(string $class) {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = substr($class, strlen($prefix));
    $file = dirname(__DIR__) . '/src/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($file)) require $file;
});
require $root . '/src/helpers.php';
Config::load($root);
\App\Core\ErrorHandler::register($root);

// Argon2id is part of the application's required PHP runtime.
if (!defined('PASSWORD_ARGON2ID') || !in_array('argon2id', password_algos(), true)) {
    http_response_code(500);
    exit('Required PHP password hashing support (Argon2id) is not available.');
}

date_default_timezone_set(Config::get('app.timezone', 'Asia/Tehran'));
if (Config::get('app.debug')) { ini_set('display_errors', '1'); error_reporting(E_ALL); } else { ini_set('display_errors', '0'); }
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
if ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')) {
    header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
}
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');
