<?php
namespace App\Services;
use App\Repositories\CycleRepository;
use PDO;

final class CycleService
{
    public function __construct(private PDO $pdo,private CycleRepository $cycles) {}
    public function open(int $divisionId): array
    {
        $cycle=$this->cycles->openForUpdate($divisionId);
        if(!$cycle){ $this->cycles->create($divisionId,1); return $this->cycles->openForUpdate($divisionId); }
        if($this->cycles->entriesCount((int)$cycle['id'])>0 && $this->cycles->remainingActive($divisionId,(int)$cycle['id'])===0){
            $this->cycles->close((int)$cycle['id']); $this->cycles->create($divisionId,(int)$cycle['cycle_number']+1); $cycle=$this->cycles->openForUpdate($divisionId);
        }
        return $cycle;
    }
}
