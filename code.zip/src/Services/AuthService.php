<?php
namespace App\Services;
use App\Core\Database;
use App\Repositories\LoginAttemptRepository;
use App\Repositories\UserRepository;
use App\Support\TextNormalizer;
use App\Support\PasswordHasher;
use RuntimeException;

final class AuthService
{
    // Used for timing-equalised authentication when the username is unknown or inactive.
    // It is a real Argon2id hash so password_verify() performs comparable work without
    // ever treating the dummy password as valid credentials.
    private const DUMMY_PASSWORD_HASH = '$argon2id$v=19$m=19456,t=2,p=1$YmdqcjQ1UXJSamNJMUxZaw$CgnfE6SA8vixYFihBE0N58wlgSoyZgnagGsQknxPb1g';

    public function __construct(private UserRepository $users, private LoginAttemptRepository $attempts) {}

    public function authenticate(string $username,string $password,string $ip): ?array
    {
        $username=mb_substr(TextNormalizer::normalize($username),0,64);

        // Throttle both a single username/IP pair and the whole source IP. The latter
        // prevents an attacker from bypassing the per-account limit by rotating names.
        if($this->attempts->recentFailures($username,$ip)>=5 || $this->attempts->recentFailuresByIp($ip)>=20) {
            throw new RuntimeException('throttle');
        }

        $user=$this->users->findByUsername($username);
        if ($user && (int)$user['is_active']===1) {
            $ok=password_verify($password,$user['password_hash']);
        } else {
            // Always perform an expensive password verification for unknown/inactive
            // accounts so the response timing does not reveal account existence.
            password_verify($password,self::DUMMY_PASSWORD_HASH);
            $ok=false;
        }

        $this->attempts->record($username,$ip,$ok);
        if(!$ok)return null;

        if(PasswordHasher::needsRehash($user['password_hash'])){ $s=Database::connection()->prepare('UPDATE users SET password_hash=:p WHERE id=:id');$s->execute(['p'=>PasswordHasher::hash($password),'id'=>$user['id']]); }
        $this->users->touchLogin((int)$user['id']);
        return $user;
    }
}
