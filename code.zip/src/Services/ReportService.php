<?php
namespace App\Services;
use App\Repositories\OvertimeRepository;
use App\Support\JalaliDate;
use App\Support\TextNormalizer;
use RuntimeException;

final class ReportService
{
    public function __construct(private OvertimeRepository $repo) {}
    public function query(array $input): array
    {
        $from=trim((string)($input['from']??''));$to=trim((string)($input['to']??''));$q=TextNormalizer::normalize((string)($input['q']??''));
        $gf=$from!==''?JalaliDate::toGregorianDate($from):'';$gt=$to!==''?JalaliDate::toGregorianDate($to):'';if($gf!==''&&$gt!==''&&$gt<$gf)throw new RuntimeException('invalid_range');
        $page=max(1,(int)($input['page']??1));$limit=!empty($input['no_pagination']) ? PHP_INT_MAX : 10;
        $result=$this->repo->report(['from'=>$gf,'to'=>$gt,'division_id'=>trim((string)($input['division_id']??'')),'type_id'=>trim((string)($input['type_id']??'')),'q'=>$q,'own_division_id'=>(int)($input['own_division_id']??0),'limit'=>$limit,'offset'=>!empty($input['no_pagination'])?0:($page-1)*$limit]);
        foreach($result['rows'] as &$r)$r['date']=JalaliDate::fromGregorian($r['overtime_date']);
        return ['rows'=>$result['rows'],'total'=>$result['total'],'total_hours'=>$result['total_hours'],'page'=>$page,'limit'=>$limit,'pages'=>!empty($input['no_pagination'])?1:($result['total']?ceil($result['total']/$limit):1)];
    }
}
