<?php
namespace App\Services;
use App\Core\Database;
use App\Repositories\AuditLogRepository;
use App\Repositories\CycleRepository;
use App\Repositories\OvertimeRepository;
use App\Repositories\PersonnelRepository;
use App\Repositories\LookupRepository;
use App\Support\JalaliDate;
use RuntimeException;
use Throwable;

final class OvertimeService
{
    public function __construct(private OvertimeRepository $entries,private PersonnelRepository $personnel,private LookupRepository $lookups,private CycleRepository $cycles,private AuditLogRepository $audit,private CycleService $cycleService) {}

    public function submitBatch(array $user,int $typeId,string $jalaliDate,float $hours,?string $description,array $personnelIds,string $ip): array
    {
        $types=$this->lookups->overtimeTypes();$type=null;foreach($types as $t)if((int)$t['id']===$typeId)$type=$t;
        if(!$type)throw new RuntimeException('invalid_type');
        $cap=(float)\App\Core\Config::get('app.hours_cap',8); if($hours<0.25||$hours>$cap||abs(($hours*4)-round($hours*4))>1e-9)throw new RuntimeException('invalid_hours');
        // Validate the selected date against the overtime type on the server.
        // The insertion path remains independent: only weekdays uses a cycle;
        // weekend and out-of-quota are both stored without a cycle.
        $weekday=JalaliDate::weekday($jalaliDate);
        $dayRule=(string)($type['day_rule']??'any');
        $isWeekend=in_array($weekday,[4,5],true); // Thursday / Friday
        if($dayRule==='workday' && $isWeekend)throw new RuntimeException('day_rule');
        if($dayRule==='weekend' && !$isWeekend)throw new RuntimeException('day_rule');
        $gdate=JalaliDate::toGregorianDate($jalaliDate); $today=new \DateTimeImmutable('today',new \DateTimeZone('Asia/Tehran')); $submitted=new \DateTimeImmutable($gdate); $window=(int)\App\Core\Config::get('app.submission_window_days',366); if($submitted < $today->modify('-'.$window.' days') || $submitted > $today->modify('+'.$window.' days')) throw new RuntimeException('date_window'); $ids=array_values(array_unique(array_map('intval',$personnelIds)));if(!$ids||count($ids)>500)throw new RuntimeException('no_personnel');
        return Database::transaction(function()use($user,$type,$typeId,$gdate,$hours,$description,$ids,$ip){
            $pdo=Database::connection();$cycle=null;
            if($type['code']==='weekdays'){
                $cycle=$this->cycleService->open((int)$user['division_id']);
                $used=$this->entries->usedPersonnel((int)$cycle['id'],$ids);
                if($used)throw new RuntimeException('already_used');
            }
            $people=$this->personnel->findActiveByIds($ids);if(count($people)!==count($ids))throw new RuntimeException('invalid_personnel');
            foreach($people as $p)if((int)$p['division_id']!==(int)$user['division_id'])throw new RuntimeException('forbidden_division');
            $inserted=[];
            foreach($people as $p){$inserted[]=$this->entries->insert(['p'=>$p['id'],'d'=>$user['division_id'],'t'=>$typeId,'date'=>$gdate,'h'=>$hours,'desc'=>$description?:null,'c'=>$cycle['id']??null,'u'=>$user['id']]);}
            if($cycle && $this->cycles->remainingActive((int)$user['division_id'],(int)$cycle['id'])===0){$this->cycles->close((int)$cycle['id']);$this->cycles->create((int)$user['division_id'],(int)$cycle['cycle_number']+1);}
            return ['ids'=>$inserted,'count'=>count($inserted),'date'=>$jalaliDate,'cycle'=>$cycle['cycle_number']??null];
        });
    }

    public function delete(array $user,int $entryId,string $ip): array
    {
        return Database::transaction(function()use($user,$entryId,$ip){
            $open=$this->cycles->openForUpdate((int)$user['division_id']);$entry=$this->entries->findForUpdate($entryId);if(!$entry)throw new RuntimeException('not_found');
            if((int)$entry['division_id']!==(int)$user['division_id'])throw new RuntimeException('forbidden_division');
            $this->entries->delete($entryId);$undo=false;
            if($entry['cycle_id']!==null && $open && (int)$entry['cycle_id']!==(int)$open['id']){
                $prev=$this->cycles->latestClosed((int)$user['division_id']);
                if($prev && (int)$prev['id']===(int)$entry['cycle_id'] && $this->cycles->entriesCount((int)$open['id'])===0){$this->cycles->delete((int)$open['id']);$this->cycles->reopen((int)$prev['id']);$undo=true;}
            }
            $entry['jalali_date']=JalaliDate::fromGregorian($entry['overtime_date']); $this->audit->add((int)$user['id'],'overtime.delete',$entryId,$entry,$ip);
            return ['deleted'=>true,'undo_close'=>$undo];
        });
    }
}
