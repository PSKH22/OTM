INSERT INTO divisions (name) VALUES
 ('پشتیبانی سخت‌افزار'),
 ('شبکه و زیرساخت'),
 ('پایگاه داده و امنیت اطلاعات');

INSERT INTO overtime_types (code, name, uses_cycle, day_rule, sort_order) VALUES
 ('weekdays','روزهای کاری',1,'workday',1),
 ('weekend','آخر هفته',0,'weekend',2),
 ('out_of_quota','خارج از سهمیه',0,'any',3);

INSERT INTO cycles (division_id, cycle_number)
SELECT id, 1 FROM divisions;
