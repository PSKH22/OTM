SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS divisions (
  id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  PRIMARY KEY (id), UNIQUE KEY uq_divisions_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS overtime_types (
  id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(30) NOT NULL,
  name VARCHAR(60) NOT NULL,
  uses_cycle TINYINT(1) NOT NULL DEFAULT 0,
  day_rule ENUM('workday','weekend','any') NOT NULL DEFAULT 'any',
  sort_order TINYINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id), UNIQUE KEY uq_overtime_types_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username VARCHAR(64) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  display_name VARCHAR(120) NOT NULL,
  division_id TINYINT UNSIGNED NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  last_login_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id), UNIQUE KEY uq_users_username (username),
  CONSTRAINT fk_users_division FOREIGN KEY (division_id) REFERENCES divisions(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS login_attempts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  username VARCHAR(64) NOT NULL,
  ip_address VARBINARY(16) NOT NULL,
  was_successful TINYINT(1) NOT NULL,
  attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_attempts_user_ip_time (username, ip_address, attempted_at),
  KEY idx_attempts_ip_time (ip_address, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS personnel (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  personnel_code VARCHAR(32) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  name_search VARCHAR(160) NOT NULL,
  division_id TINYINT UNSIGNED NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id), UNIQUE KEY uq_personnel_code (personnel_code),
  KEY idx_personnel_division_active (division_id, is_active),
  CONSTRAINT fk_personnel_division FOREIGN KEY (division_id) REFERENCES divisions(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS cycles (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  division_id TINYINT UNSIGNED NOT NULL,
  cycle_number INT UNSIGNED NOT NULL,
  started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  closed_at DATETIME NULL,
  open_marker TINYINT(1) GENERATED ALWAYS AS (IF(closed_at IS NULL, 1, NULL)) STORED,
  PRIMARY KEY (id),
  UNIQUE KEY uq_cycles_division_number (division_id, cycle_number),
  UNIQUE KEY uq_cycles_one_open_per_division (division_id, open_marker),
  CONSTRAINT fk_cycles_division FOREIGN KEY (division_id) REFERENCES divisions(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS overtime_entries (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  personnel_id INT UNSIGNED NOT NULL,
  division_id TINYINT UNSIGNED NOT NULL,
  overtime_type_id TINYINT UNSIGNED NOT NULL,
  overtime_date DATE NOT NULL,
  hours DECIMAL(4,2) NOT NULL,
  description VARCHAR(255) NULL,
  cycle_id INT UNSIGNED NULL,
  created_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_entries_cycle_personnel (cycle_id, personnel_id),
  KEY idx_entries_date (overtime_date),
  KEY idx_entries_personnel_date (personnel_id, overtime_date),
  CONSTRAINT chk_entries_hours CHECK (hours > 0 AND hours <= 24),
  CONSTRAINT fk_entries_personnel FOREIGN KEY (personnel_id) REFERENCES personnel(id),
  CONSTRAINT fk_entries_division FOREIGN KEY (division_id) REFERENCES divisions(id),
  CONSTRAINT fk_entries_type FOREIGN KEY (overtime_type_id) REFERENCES overtime_types(id),
  CONSTRAINT fk_entries_cycle FOREIGN KEY (cycle_id) REFERENCES cycles(id),
  CONSTRAINT fk_entries_user FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS audit_log (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  action VARCHAR(40) NOT NULL,
  entity_id BIGINT UNSIGNED NULL,
  details JSON NOT NULL,
  ip_address VARBINARY(16) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id), KEY idx_audit_created (created_at),
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
