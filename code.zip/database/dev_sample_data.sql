-- Development-only fake personnel. Do not use in production.
INSERT INTO personnel (personnel_code, full_name, name_search, division_id) VALUES
 ('1001','علی کریمی','علی کریمی',2),
 ('1002','سارا احمدی','سارا احمدی',2),
 ('1003','رضا محمدی','رضا محمدی',1),
 ('1004','مریم حسینی','مریم حسینی',3),
 ('1005','امیر رضایی','امیر رضایی',1),
 ('1006','نگار موسوی','نگار موسوی',3);

INSERT INTO users (username,password_hash,display_name,division_id) VALUES
 ('admin_hw','$2y$12$5XGbhMaTA.MooiLyBTrjT.nevL67IxqIvB.lL/yh9dKpEQ2F6ErGG','مدیر پشتیبانی سخت‌افزار',1),
 ('admin_net','$2y$12$5XGbhMaTA.MooiLyBTrjT.nevL67IxqIvB.lL/yh9dKpEQ2F6ErGG','علی کریمی',2),
 ('admin_db','$2y$12$5XGbhMaTA.MooiLyBTrjT.nevL67IxqIvB.lL/yh9dKpEQ2F6ErGG','مدیر پایگاه داده و امنیت',3);
-- Development password for all three demo accounts: admin12345
